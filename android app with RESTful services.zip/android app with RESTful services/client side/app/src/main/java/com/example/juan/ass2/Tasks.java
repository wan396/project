package com.example.juan.ass2;

import android.os.AsyncTask;
import android.widget.ArrayAdapter;

import javax.xml.transform.Result;

/**
 * Created by juan on 24/04/2016.
 */
/*public class Tasks extends AsyncTask<Void,Void,String[]>{

    @Override
    protected String[] doInBackground(Void... params) {

        String[] add = RestClient.findClinicAdd();
        return add;
    }
    @Override
    protected void onPostExecute(String[] result) {
        ArrayAdapter<String> addapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,android.R.id.cadd,result);
        cadd.setAdapter(addapter);
    }

}*/
