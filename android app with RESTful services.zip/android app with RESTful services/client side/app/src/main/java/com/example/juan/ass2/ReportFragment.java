package com.example.juan.ass2;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.view.LineChartView;

/**
 * Created by juan on 24/04/2016.
 */
public class ReportFragment extends Fragment {
    View vDisplayReport;
    private int uid;
    private String sdate, edate, weather;
    List<PointValue> values1 = new ArrayList<PointValue>();
    List<PointValue> values2 = new ArrayList<PointValue>();
    List<AxisValue> axisValuesForX = new ArrayList<AxisValue>();
    List<Line> lines = new ArrayList<Line>();
    Line line;
    private LineChartView chart;
    private LineChartData data;
    private int renum;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        vDisplayReport = inflater.inflate(R.layout.ne_report, container, false);
        uid = getActivity().getIntent().getExtras().getInt("uid");


        return vDisplayReport;
    }
}
