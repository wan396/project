package com.example.juan.ass2;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by juan on 24/04/2016.
 */
public class RestClient {
    private static final String BASE_URI = "http://10.0.2.2:9090/HealthService/webresources";

    public RestClient(){

    }
    public static String findClinicAdd(){
        final String methodPath = "/healthman.doctor/findClinicAdd";
        URL url = null;
        HttpURLConnection conn = null;
        String textResult = "";
        // Making HTTP request
        try {
            url = new URL(BASE_URI + methodPath);
            //open the connection
            conn = (HttpURLConnection) url.openConnection();
            //set the timeout
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);
            //set the connection method to GET
            conn.setRequestMethod("GET");
            //add HTTP headers to set your respond type to json
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            //Read the response
            Scanner inStream = new Scanner(conn.getInputStream());

            //read the inputsteream and store it as string
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
            }
            Log.d("res",textResult);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.disconnect();
        }
    return textResult;
    }

    public static String getDoctorName(String add){
        String address = add.replace(" ","%20");
        final String methodPath = "/healthman.doctor/findDoctorName/"+address;
        URL url = null;
        HttpURLConnection conn = null;
        String textResult = "";
        try {
            url = new URL(BASE_URI + methodPath);
            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            Scanner inStream = new Scanner(conn.getInputStream());
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
            }} catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.disconnect();
        }
        Log.d("client",textResult);
        return textResult;
    }

    public static List<Record> getRecord(int uid){
        final String methodPath = "/healthman.record/findRecord/"+uid;
        URL url = null;
        HttpURLConnection conn = null;
        String textResult = "";
        List<Record> re = new ArrayList<>();
        try {
            url = new URL(BASE_URI + methodPath);
            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            Scanner inStream = new Scanner(conn.getInputStream());
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
                Gson gson = new Gson();
                re = gson.fromJson(textResult, new TypeToken<List<Record>>() {
                }.getType());
            }} catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.disconnect();
        }
        Log.d("client",textResult);
        return re;
    }
    public static List<Record> graphResult(int uid,Date sdate,Date edate,String wea){
        final String methodPath = "healthman.record/findPLevelAndWea/"+uid+"/"+sdate+"/"+edate+"/"+wea;
        URL url = null;
        HttpURLConnection conn = null;
        String textResult = "";
        List<Record> re = new ArrayList<>();
        try {
            url = new URL(BASE_URI + methodPath);
            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            Scanner inStream = new Scanner(conn.getInputStream());
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
                Gson gson = new Gson();
                re = gson.fromJson(textResult, new TypeToken<List<Record>>() {
                }.getType());
            }} catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.disconnect();
        }
        Log.d("client",textResult);
        return re;
    }

    public static String ValidateUser(String uname,String pass, String isLocal){
        final String methodPath = "/healthman.users/valiUser/"+uname+"/"+pass+"/"+isLocal;
        URL url = null;
        HttpURLConnection conn = null;
        String textResult = "";
        try {
            url = new URL(BASE_URI + methodPath);
            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            Scanner inStream = new Scanner(conn.getInputStream());
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
            }


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.disconnect();
        }
        return textResult;
    }
       public static String createUser(String data){
        final String methodPath = "/healthman.users/createUser";
        URL url = null;
        HttpURLConnection conn = null;
        String textResult = "";
        try{
            url = new URL(BASE_URI + methodPath);
            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");

            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
            out.write(data);
            out.flush();

            Scanner inStream = new Scanner(conn.getInputStream());
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
            }

        }catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.disconnect();
        }
           Log.d("clientUser",textResult);
        return textResult;
    }

    public static String register(String data){
        final String methodPath = "/healthman.registration/register";
        URL url = null;
        HttpURLConnection conn = null;
        String textResult = "";
        try{
            url = new URL(BASE_URI + methodPath);
            conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");

            OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
            out.write(data);
            out.flush();

            Scanner inStream = new Scanner(conn.getInputStream());
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
            }

        }catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.disconnect();
        }
        Log.d("client",textResult);
        return textResult;
    }
}
