package com.example.juan.ass2;

import android.app.Fragment;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by juan on 24/04/2016.
 */
public class RecordFragment extends Fragment {
    View vDisplayRecord;
    private int uid;
    private String fname;
    private Spinner sDatetime, sPlocation, sPtrigger;
    private SeekBar skbPlevel, skbMood;
    private TextView tvPlevel, tvMood;
    private Button btnInsert, btnUpdate, btnDelete;
    private List<Record> records = new ArrayList<Record>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        vDisplayRecord = inflater.inflate(R.layout.ne_record, container, false);
        uid = getActivity().getIntent().getExtras().getInt("uid");
        fname = getActivity().getIntent().getExtras().getString("fname");
        Log.d("uid", String.valueOf(uid));

        sDatetime = (Spinner) vDisplayRecord.findViewById(R.id.s_dateandtime);
        sPlocation = (Spinner) vDisplayRecord.findViewById(R.id.s_plocation);
        sPtrigger = (Spinner) vDisplayRecord.findViewById(R.id.s_ptrigger);
        skbPlevel = (SeekBar) vDisplayRecord.findViewById(R.id.sbar_plevel);
        tvPlevel = (TextView) vDisplayRecord.findViewById(R.id.tv_plevelvalue);
        tvMood = (TextView) vDisplayRecord.findViewById(R.id.tv_moodlevelvalue);
        skbMood = (SeekBar) vDisplayRecord.findViewById(R.id.sbar_moodlevel);
        btnInsert = (Button) vDisplayRecord.findViewById(R.id.btnInsert);
        btnUpdate = (Button) vDisplayRecord.findViewById(R.id.btnUpdate);
        btnDelete = (Button) vDisplayRecord.findViewById(R.id.btnDelete);
        uid = getActivity().getIntent().getExtras().getInt("uid");

        new AsyncTask<String, Void, List<Record>>() {
            @Override
            protected List<Record> doInBackground(String... params) {
                return RestClient.getRecord(uid);
            }

            @Override
            protected void onPostExecute(List<Record> re) {
                if (re.size() != 0) {
                    ArrayList<String> dinfo = new ArrayList<String>();
                    for (int i = 0; i < re.size(); i++) {
                        dinfo.add(re.get(i).getRecorddate() + " " + re.get(i).getRecordtime());
                        records.add(re.get(i));
                    }
                    Log.d("record",re.toString());
                    Log.d("date",dinfo.toString());

                    //BUG MAY BE AT HERE!
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, dinfo);
                    sDatetime.setAdapter(adapter);

                    sDatetime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView parent, View view, int position, long id) {
                            skbPlevel.setProgress(records.get(position).getPainlevel());
                            tvPlevel.setText("Plevel: " + records.get(position).getPainlevel());
                            String plocation = records.get(position).getPainlocation();
                            String ptrigger = records.get(position).getPainttrigger();
                            int moodlevel = records.get(position).getMoodlevel();
                            for (int i = 0; i < sPlocation.getCount(); i++) {
                                if (sPlocation.getItemAtPosition(i).toString().equals(plocation)) {
                                    sPlocation.setSelection(i);
                                    break;
                                }
                            }

                            for (int i = 0; i < sPtrigger.getCount(); i++) {
                                if (sPtrigger.getItemAtPosition(i).toString().equals(ptrigger)) {
                                    sPtrigger.setSelection(i);
                                    break;
                                }
                            }

                            String mood;
                            switch (moodlevel) {
                                case 1: mood = "very low"; break;
                                case 2: mood = "low"; break;
                                case 3: mood = "average"; break;
                                case 4: mood = "high"; break;
                                case 5: mood = "very high"; break;
                                default: mood = "very high"; break;
                            }
                            skbMood.setProgress(moodlevel);
                            tvMood.setText("Moodlevel: " + mood);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });
                }
            }
        }.execute(uid + "");

        skbPlevel.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvPlevel.setText("Plevel: " + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        skbMood.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                String s;
                switch (progress) {
                    case 0: s = "very low"; break;
                    case 1: s = "low"; break;
                    case 2: s = "average"; break;
                    case 3: s = "high"; break;
                    case 4: s = "very high"; break;
                    default: s = "very low"; break;
                }
                tvMood.setText("Moodlevel: " + s);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

            return vDisplayRecord;
        }


        }
