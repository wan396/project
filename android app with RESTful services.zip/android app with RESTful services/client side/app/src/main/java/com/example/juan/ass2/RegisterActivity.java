package com.example.juan.ass2;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class RegisterActivity extends AppCompatActivity {
    private Spinner gender,cadd,dname;
    private DatePicker date;
    Calendar cal;
    private int year;
    private int month;
    private int day;
    private Button butt;
    private Button register;
    private int len;
    private String[] value;
    private String[] valueFordname;
    private TextView username,password,conpaword,fname,lname,occ,hei,wei,add,sub,stat;
    private String uname,pass,conpass,firstname,lastname,gen,selecdate,occupation,address,suburb,state,docname,height,weight;
    private int heig,weig;
    private int did;
    private JSONArray dnresponse;
    private Security encry;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        encry = new Security();
        username = (TextView)findViewById(R.id.reuserText);
        password = (TextView)findViewById(R.id.repassText);
        conpaword= (TextView)findViewById(R.id.repassCon);
        fname= (TextView)findViewById(R.id.fnameText);
        lname= (TextView)findViewById(R.id.lnameText);
        hei= (TextView)findViewById(R.id.height);
        wei= (TextView)findViewById(R.id.weight);
        occ= (TextView)findViewById(R.id.occText);
        add= (TextView)findViewById(R.id.addText);
        sub= (TextView)findViewById(R.id.subText);
        stat= (TextView)findViewById(R.id.statText);
        dname = (Spinner)findViewById(R.id.dname);

        gender = (Spinner)findViewById(R.id.regender);
        ArrayAdapter regender = ArrayAdapter.createFromResource(this,R.array.regender,android.R.layout.simple_spinner_item);
        gender.setAdapter(regender);
        gender.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView seText = (TextView) view;
                String s = (String) seText.getText();
                gen = s.substring(0,1);
                Log.d("gen",s);
                Toast.makeText(RegisterActivity.this.getApplication(), (String) seText.getText(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        butt = (Button)findViewById(R.id.datebut);
        cal = Calendar.getInstance();
        year = cal.get(Calendar.YEAR);
        month = cal.get(Calendar.MONTH);
        day = cal.get(Calendar.DAY_OF_MONTH);
        butt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog dpd = new DatePickerDialog(RegisterActivity.this,Datelistener,year,month,day);
                dpd.getDatePicker().setMaxDate(Calendar.getInstance().getTimeInMillis());
                dpd.show();
            }
        });

        cadd = (Spinner)findViewById(R.id.cadd);
        Bundle b = this.getIntent().getExtras();
        String caddre = this.getIntent().getStringExtra("cadd");
        Log.d("register", caddre);
        try{
        JSONArray jsonArray = new JSONArray(caddre);
            len = jsonArray.length();
            value = new String[len];
        for(int i=0;i<jsonArray.length();i++){
            JSONObject object = jsonArray.getJSONObject(i);
            value[i]= object.getString("address");
            Log.d("addArr",value[i]);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,value);
        cadd.setAdapter(adapter);
        }catch(Exception e){}
        cadd.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView seText = (TextView) view;
                String s = (String) seText.getText();

                Log.d("gen",gen);
                //Toast.makeText(RegisterActivity.this.getApplication(), (String) seText.getText(), Toast.LENGTH_SHORT).show();
                final String address = (String) seText.getText();
                Log.d("address",address);
                new AsyncTask<Void, Void, String[]>() {

                    @Override
                    protected String[] doInBackground(Void... params) {
                        String response = RestClient.getDoctorName(address);
                        String result = null;
                        Log.d("dnamere",response);
                        try {
                            dnresponse = new JSONArray(response);
                            int lenth = dnresponse.length();
                            valueFordname = new String[lenth];
                            for (int i=0;i<dnresponse.length();i++){
                                JSONObject object = dnresponse.getJSONObject(i);
                                valueFordname[i] = object.getString("fullname");
                                Log.d("dname",object.toString());
                            }


                        }catch (Exception e){}
                        return valueFordname;
                    }
                    @Override
                    protected void onPostExecute(String[] valueFordname) {
                        ArrayAdapter<String> ada = new ArrayAdapter<String>(RegisterActivity.this,android.R.layout.simple_spinner_item,valueFordname);
                        dname.setAdapter(ada);
                    }
                }.execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        dname.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            TextView seText = (TextView) view;
                            docname = (String) seText.getText();
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
        });
        register = (Button)this.findViewById(R.id.regbutt);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("click","ck");
                uname = username.getText().toString();
                pass = password.getText().toString();
                conpass = conpaword.getText().toString();
                if(!pass.equals(conpass)){
                    Toast.makeText(RegisterActivity.this.getApplication(), "Password not match", Toast.LENGTH_SHORT).show();
                    return;
                }
                firstname = fname.getText().toString();
                lastname= lname.getText().toString();
                //gen
                height = hei.getText().toString();
                heig = Integer.valueOf(height);
                weight = wei.getText().toString();
                weig = Integer.valueOf(weight);
                //selecdate
                occupation = occ.getText().toString();
                address = add.getText().toString();
                suburb = sub.getText().toString();
                state = stat.getText().toString();
                //docname
                did = 0;
                try{
                    for(int i=0;i<dnresponse.length();i++){
                        //dnresponse
                        JSONObject obj = dnresponse.getJSONObject(i);
                        String unameo = obj.getString("fullname");
                        int dido = obj.getInt("did");
                        if(docname.equals(unameo)){
                            did = dido;break;
                        }
                        Log.d("did",String.valueOf(did));

                    }
                }catch (Exception e){}

                new AsyncTask<Void, Void, String>() {
                    @Override
                    protected String doInBackground(Void... params) {
                        Calendar cal = Calendar.getInstance();
                        SimpleDateFormat dayform = new SimpleDateFormat("yyyy-MM-dd");
                        SimpleDateFormat timeform = new SimpleDateFormat("hh:mm:ss");
                        String redate = dayform.format(cal.getTime());
                        String retime = timeform.format(cal.getTime());
                        //insert user
                        JSONObject user = new JSONObject();
                        String regmess = null;
                        try {
                            user.put("fname", firstname);
                            user.put("lname", lastname);
                            user.put("gender", gen);
                            user.put("dob", selecdate);
                            user.put("height",heig);
                            user.put("weight", weig);
                            user.put("occupation", occupation);
                            user.put("address", address);
                            user.put("suburb", suburb);
                            user.put("state", state);
                            String result = RestClient.createUser(user.toString());
                            JSONObject re = new JSONObject(result);
                            int reuid = re.getInt("uid");

                            //insert registeration
                            String ciper = encry.hash(pass);
                            JSONObject regist = new JSONObject();
                            regist.put("uid",reuid);
                            regist.put("username",uname);
                            regist.put("password",ciper);
                            regist.put("redate",redate);
                            regist.put("retime",retime);
                            regist.put("did",did);
                            regmess = RestClient.register(regist.toString());

                        }catch (Exception e){}

                        return regmess;
                    }

                    @Override
                    protected void onPostExecute(String mes) {
                        //Log.d("state",mes);
                        //if (mes.equals("sucess")){
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                        //}
                    }
            }.execute();
            }
        });

    }
    private DatePickerDialog.OnDateSetListener Datelistener = new DatePickerDialog.OnDateSetListener(){

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            cal.set(Calendar.YEAR,year);
            cal.set(Calendar.MONTH,monthOfYear);
            cal.set(Calendar.DAY_OF_MONTH,dayOfMonth);
            updateDate();
        }
    };
    private void updateDate(){
        butt.setText(year+" - "+month+" - "+day);
        selecdate = year+"-"+month+"-"+day;
        Toast.makeText(RegisterActivity.this.getApplication(),"year "+year+"month "+month+"day "+day, Toast.LENGTH_SHORT).show();
    }
}
