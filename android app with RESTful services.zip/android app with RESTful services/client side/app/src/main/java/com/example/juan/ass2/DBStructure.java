package com.example.juan.ass2;

import android.provider.BaseColumns;

/**
 * Created by juan on 23/04/2016.
 */
public class DBStructure {
    public static abstract class tableEntry implements BaseColumns {
        public static final String TABLE_NAME = "usercache";
        public static final String COLUMN_ID = "userid";
        public static final String COLUMN_NAME = "username";
        public static final String COLUMN_ADD = "address";
        public static final String COLUMN_LAT = "latitude";
        public static final String COLUMN_LON = "longitude";
        public static final String COLUMN_DATE = "regdate";
        public static final String COLUMN_TIME = "regtime";
    }
}
