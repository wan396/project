package com.example.juan.ass2;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity{
    protected DBManager dbManager;
    private Button register;
    private Button login;
    private TextView usname,uspass;
    private String uname,upass;
    private String username;
    private boolean isLocal = false;
    private int uid=0;
    private String fname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        findViewById(R.id.rootview).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager in = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                in.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        });
        usname = (TextView)findViewById(R.id.userText);
        uspass =(TextView)findViewById(R.id.pswordText);
        dbManager = new DBManager(this);
        try{
            dbManager.open();
        }catch(Exception e){}

        register  = (Button)findViewById(R.id.RegistButton);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*Intent intent = new Intent(getApplicationContext(),RegisterActivity.class);
                startActivity(intent);*/
                usname.setText("");
                uspass.setText("");
                //load clinic address when click register button
                new AsyncTask<Void, Void, String>() {
                    @Override
                    protected String doInBackground(Void... params) {

                        String add = RestClient.findClinicAdd();

                        return add;
                    }
                    @Override
                    protected void onPostExecute(String result) {
                        Intent intent1 = new Intent(getApplicationContext(),RegisterActivity.class);
                        intent1.putExtra("cadd", result);
                        startActivity(intent1);
                        /*Bundle bundle=new Bundle();
                        bundle.putStringArray("add",result);
                        */

                    }
                }.execute();
            }
        });

        login = (Button)findViewById(R.id.loginButt);
        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                uname = usname.getText().toString();
                upass = uspass.getText().toString();
                if (uname.isEmpty() || upass.isEmpty()){
                    Toast.makeText(MainActivity.this.getApplication(), "Log in first", Toast.LENGTH_SHORT).show();
                }
                else {
                    new AsyncTask<Void, Void, String>() {
                        @Override
                        protected String doInBackground(Void... params) {
                            String islogged = "x";
                            try {
                                /*dbManager.open();
                            Cursor c = dbManager.getOneUser(uname);
                            if (c.getCount() > 0 ) {
                                isLocal = true;
                            }
                            if (c.getCount() == 0) {
                                isLocal = false;
                            }
                            Log.d("isLocal", String.valueOf(isLocal));
                            dbManager.close();
                            String response = RestClient.ValidateUser(uname, upass, String.valueOf(isLocal));
                            Log.d("response", response);

                            String result = null;

                                JSONObject object = new JSONObject(response);
                                result = object.getString("result");
                                uid = object.getInt("uid");

                                /*if (result.equals("unvalid"))
                                    islogged = "x";
                                    //Toast.makeText(MainActivity.this.getApplication(), "Unvalid User", Toast.LENGTH_SHORT).show();
                                else
                                {*/
                                String response = RestClient.ValidateUser(uname, upass, String.valueOf(isLocal));
                                Log.d("response", response);
                                JSONObject object = new JSONObject(response);
                                String result = object.getString("result");
                                uid = object.getInt("uid");
                                if (result.equals("valid")){
                                    islogged = "t";
                                    if (isLocal == false) {
                                        String add = object.getString("add");
                                        double lng = object.getDouble("lng");
                                        double lat = object.getDouble("lat");
                                        fname = object.getString("fname");
                                        String date = object.getString("date");
                                        String time = object.getString("time");
                                        Calendar cal = Calendar.getInstance();
                                        //cal.add(Calendar.DATE, 1);
                                            /*SimpleDateFormat formatDay = new SimpleDateFormat("yyyy-MM-dd");
                                            SimpleDateFormat formatTime = new SimpleDateFormat("hh:mm:ss");
                                            String date = formatDay.format(cal.getTime());
                                            String time = formatTime.format(cal.getTime());
                                            result = date + time;*/
                                        dbManager.open();
                                        Cursor c = dbManager.getOneUser(uname);
                                        if (c.getCount() == 0) {
                                            dbManager.insertUser(uid, uname, add, lat, lng, date, time);
                                            dbManager.close();
                                        }
                                        }

                                }

                            } catch (Exception e) {}


                            return islogged;
                        }

                        @Override
                        protected void onPostExecute(String logged) {
                            Log.d("logged",logged);
                            if (logged.equals("t")) {
                                Intent intent = new Intent(getApplicationContext(), NeActivity.class);
                                intent.putExtra("uid", uid);
                                intent.putExtra("fname", fname);
                                startActivity(intent);
                            }
                            else{
                                Toast.makeText(MainActivity.this.getApplication(), "Log in first", Toast.LENGTH_SHORT).show();
                                return;
                            }

                        }
                    }.execute();
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
