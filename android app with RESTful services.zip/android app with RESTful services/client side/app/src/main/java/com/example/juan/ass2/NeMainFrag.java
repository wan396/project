package com.example.juan.ass2;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by juan on 24/04/2016.
 */
public class NeMainFrag extends Fragment {
    View vMain;
    private int uid;
    private TextView hellfname,currdate;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        vMain = inflater.inflate(R.layout.ne_main, container, false);
        uid = getActivity().getIntent().getExtras().getInt("uid");
        String fname = getActivity().getIntent().getExtras().getString("fname");
        String hello = "Hello,  " + fname;

        hellfname = (TextView)vMain.findViewById(R.id.hello);
        hellfname.setText(hello);

        currdate = (TextView)vMain.findViewById(R.id.date);
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat dayform = new SimpleDateFormat("yyyy-MM-dd");
        String today = dayform.format(cal.getTime());
        String s = "Today is "+today;
        currdate.setText(s);
        return vMain;
    }
}
