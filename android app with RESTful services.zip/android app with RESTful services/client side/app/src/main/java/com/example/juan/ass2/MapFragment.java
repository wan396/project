package com.example.juan.ass2;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by juan on 24/04/2016.
 */
public class MapFragment extends Fragment {
    View vDisplayMap;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        vDisplayMap = inflater.inflate(R.layout.ne_map, container, false);
        return vDisplayMap;
    }
}
