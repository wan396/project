package com.example.juan.ass2;

/**
 * Created by juan on 27/04/2016.
 */
public class Record {
    private int painlevel;
    private String painlocation;
    private int moodlevel;
    private String painttrigger;
    private String redate;
    private String retime;
    private int temperature;
    private int windspeed;
    private int pressure;
    private double humidity;

    public Record(String recorddate,String recordtime,int painlevel,String painlocation,String painttrigger,Short moodlevel) {
        this.redate = recorddate;
        this.retime=recordtime;
        this.painlevel=painlevel;
        this.painlocation=painlocation;
        this.painttrigger=painttrigger;
        this.moodlevel=moodlevel;
    }

    public Record(int painlevel,int temperature,int windspeed,int pressure,double humidity){
        this.painlevel=painlevel;
        this.temperature=temperature;
        this.humidity=humidity;
        this.windspeed=windspeed;
    }

    public void setPainlevel(int painlevel) {
        this.painlevel = painlevel;
    }

    public void setWindspeed(int windspeed) {
        this.windspeed = windspeed;
    }

    public void setHumidity(double humidity) {
        this.humidity = humidity;
    }

    public void setPressure(int pressure) {
        this.pressure = pressure;
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }

    public double getHumidity() {
        return humidity;
    }

    public int getPressure() {
        return pressure;
    }

    public int getWindspeed() {
        return windspeed;
    }

    public int getTemperature() {
        return temperature;
    }

    public int getPainlevel() {
        return painlevel;
    }

    public String getPainttrigger() {
        return painttrigger;
    }

    public String getRecorddate() {
        String date = redate.substring(0,10);
        return date;
    }

    public String getPainlocation() {
        return painlocation;

    }

    public String getRecordtime() {
        String time = retime.substring(11, 19);
        return time;
    }

    public void setRecorddate(String recorddate) {
        this.redate = recorddate;
    }

    public void setRecordtime(String recordtime) {
        this.retime = recordtime;
    }

    public void setPainttrigger(String painttrigger) {
        this.painttrigger = painttrigger;
    }

    public int getMoodlevel() {

        return moodlevel;
    }

    public void setPainlevel(short painlevel) {
        this.painlevel = painlevel;
    }

    public void setMoodlevel(Short moodlevel) {
        this.moodlevel = moodlevel;
    }

    public void setPainlocation(String painlocation) {
        this.painlocation = painlocation;
    }
}
