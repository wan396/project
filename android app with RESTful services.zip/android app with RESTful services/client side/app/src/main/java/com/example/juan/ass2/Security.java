package com.example.juan.ass2;

import java.security.MessageDigest;

/**
 * Created by juan on 25/04/2016.
 */
public class Security {
    public Security(){

    }
    public String hash(String pass){
        String plaintext = pass;
        StringBuffer sb = new StringBuffer();
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(plaintext.getBytes());
            byte byteData[] = md.digest();
            //convert the byte to the hex format

            for (int i = 0; i < byteData.length; i++) {
                sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
            }

            //System.out.println("Hex format : " + sb.toString());
        }catch (Exception e){};
        String ciper = sb.toString();
        return ciper;
    }
}
