package com.example.juan.ass2;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;

/*public class Addrecord extends AppCompatActivity {
    private int uid;
    private String fname;
    private Button submit,cancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addrecord);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        Bundle b = this.getIntent().getExtras();
        uid = b.getInt("uid");
        fname = b.getString("fname");
        Log.d("addname",fname + " "+uid);

        submit = (Button)findViewById(R.id.addrocord);

        cancel = (Button)findViewById(R.id.canceladd);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplication(),NeActivity.class);
                intent.putExtra("uid", uid);
                intent.putExtra("fname", fname);
                startActivity(intent);
            }
        });
    }

}*/
