package com.example.juan.ass2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.SQLException;

/**
 * Created by juan on 23/04/2016.
 */
public class DBManager {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "usercache.db";
    private final Context context;
    private static final String TEXT_TYPE = "TEXT";
    private static final String COMMA_SEP = ",";
    private static final String SQL_CREATE_ENTRIES = "CREATE TABLE " + DBStructure.tableEntry.TABLE_NAME + " " +
            "(" + DBStructure.tableEntry._ID + " INTEGER PRIMARY KEY," + DBStructure.tableEntry.COLUMN_ID + " " + TEXT_TYPE + COMMA_SEP +
            DBStructure.tableEntry.COLUMN_NAME + " " + TEXT_TYPE + COMMA_SEP + DBStructure.tableEntry.COLUMN_ADD + " " + TEXT_TYPE + COMMA_SEP + DBStructure.tableEntry.COLUMN_LAT + " " + TEXT_TYPE + COMMA_SEP +
            DBStructure.tableEntry.COLUMN_LON + " " + TEXT_TYPE + COMMA_SEP + DBStructure.tableEntry.COLUMN_DATE + " " + TEXT_TYPE + COMMA_SEP +
            DBStructure.tableEntry.COLUMN_TIME + " );";
    private static final String SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS " + DBStructure.tableEntry.TABLE_NAME;
    private String[] location = { DBStructure.tableEntry.COLUMN_LAT, DBStructure.tableEntry.COLUMN_LON};

    private static class MySQLiteOpenHelper extends SQLiteOpenHelper {
        public MySQLiteOpenHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
            Log.d("database","db created");
        }
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_ENTRIES);
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // This database is only a cache for online data, so its upgrade policy is
            // to simply to discard the data and start over
            db.execSQL(SQL_DELETE_ENTRIES);
            onCreate(db);
            Log.d("database", "table created");
        }
        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }
    }

    private MySQLiteOpenHelper myDBHelper;
    private SQLiteDatabase db;

    public DBManager(Context ctx) {
        this.context = ctx;
        myDBHelper = new MySQLiteOpenHelper(context);
    }

    // create the database and the table
    public DBManager open() throws SQLException {
        db = myDBHelper.getWritableDatabase();
        return this;
    }
    public void close() {
        myDBHelper.close();
    }

    //insert data
    public long insertUser(int uid,String uname, String add,double lat, double lon, String date,String time) {
        ContentValues values = new ContentValues();
        values.put(DBStructure.tableEntry.COLUMN_ID, uid);
        values.put(DBStructure.tableEntry.COLUMN_NAME, uname);
        values.put(DBStructure.tableEntry.COLUMN_ADD, add);
        values.put(DBStructure.tableEntry.COLUMN_LAT, lat);
        values.put(DBStructure.tableEntry.COLUMN_LON, lon);
        values.put(DBStructure.tableEntry.COLUMN_DATE, date);
        values.put(DBStructure.tableEntry.COLUMN_TIME, time);
        Log.d("database", "1 row created");
        return db.insert(DBStructure.tableEntry.TABLE_NAME, null, values);

    }
    public Cursor getOneUser(String uname){
        String[] column = {DBStructure.tableEntry.COLUMN_ID};
        return db.query(DBStructure.tableEntry.TABLE_NAME,column,DBStructure.tableEntry.COLUMN_NAME + "=?",new String[]{uname},null,null,null);
    }
    public Cursor getOneLoc(int userid){
        return db.query(DBStructure.tableEntry.TABLE_NAME, location, DBStructure.tableEntry.COLUMN_ID + "=?", new String[]{String.valueOf(userid)}, null, null, null);
    }
}
