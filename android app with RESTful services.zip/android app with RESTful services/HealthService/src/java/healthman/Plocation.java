/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author juan
 */
@XmlRootElement

public class Plocation {
    private String painlocation;
    private Number frequency;
    
    public Plocation(){
        
    }
    
    public Plocation(String location, Number fre){
        painlocation = location;
        frequency = fre;
    }

    public String getPainlocation() {
        return painlocation;
    }

    public Number getFrequency() {
        return frequency;
    }

    public void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    public void setPainlocation(String painlocation) {
        this.painlocation = painlocation;
    }
    
}
