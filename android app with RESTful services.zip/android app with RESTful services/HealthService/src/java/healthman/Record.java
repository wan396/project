/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author juan
 */
@Entity
@Table(name = "RECORD")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Record.findAll", query = "SELECT r FROM Record r"),
    @NamedQuery(name = "Record.findByUid", query = "SELECT r FROM Record r WHERE r.recordPK.uid = :uid"),
    @NamedQuery(name = "Record.findByRecorddate", query = "SELECT r FROM Record r WHERE r.recordPK.recorddate = :recorddate"),
    @NamedQuery(name = "Record.findByRecordtime", query = "SELECT r FROM Record r WHERE r.recordPK.recordtime = :recordtime"),
    @NamedQuery(name = "Record.findByPainlevel", query = "SELECT r FROM Record r WHERE r.painlevel = :painlevel"),
    @NamedQuery(name = "Record.findByPainlocation", query = "SELECT r FROM Record r WHERE r.painlocation = :painlocation"),
    @NamedQuery(name = "Record.findByMoodlevel", query = "SELECT r FROM Record r WHERE r.moodlevel = :moodlevel"),
    @NamedQuery(name = "Record.findByPainttrigger", query = "SELECT r FROM Record r WHERE r.painttrigger = :painttrigger"),
    @NamedQuery(name = "Record.findByLatitude", query = "SELECT r FROM Record r WHERE r.latitude = :latitude"),
    @NamedQuery(name = "Record.findByLongitude", query = "SELECT r FROM Record r WHERE r.longitude = :longitude"),
    @NamedQuery(name = "Record.findByTemperature", query = "SELECT r FROM Record r WHERE r.temperature = :temperature"),
    @NamedQuery(name = "Record.findByHumidity", query = "SELECT r FROM Record r WHERE r.humidity = :humidity"),
    @NamedQuery(name = "Record.findByWindspeed", query = "SELECT r FROM Record r WHERE r.windspeed = :windspeed"),
    @NamedQuery(name = "Record.findByPressure", query = "SELECT r FROM Record r WHERE r.pressure = :pressure"),

//task 2
    //find by uid
    @NamedQuery (name = "Record.findByUid", query = "SELECT r FROM Record r WHERE r.recordPK.uid = :uid"),
    //find by recorddate
    @NamedQuery (name = "Record.findByRedate", query = "SELECT r FROM Record r WHERE r.recordPK.recorddate = :recorddate"),
    //find by recordtime
    @NamedQuery (name = "Record.findByRetime", query = "SELECT r FROM Record r WHERE r.recordPK.recordtime = :recordtime"),
    //find by painlevel
    @NamedQuery (name = "Record.findByPLevel", query = "SELECT r FROM Record r WHERE r.painlevel = :painlevel"),
    //find by painlocation
    @NamedQuery (name = "Record.findByPLocation", query = "SELECT r FROM Record r WHERE r.painlocation = :painlocation"),
    //find by moodlevel
    @NamedQuery (name = "Record.findByMLevel", query = "SELECT r FROM Record r WHERE r.moodlevel = :moodlevel"),    
    //find by painttrigger
    @NamedQuery (name = "Record.findByPTrigger", query = "SELECT r FROM Record r WHERE r.painttrigger = :painttrigger"),    
    //find by latitude
    @NamedQuery (name = "Record.findByLatitude", query = "SELECT r FROM Record r WHERE r.latitude = :latitude"),    
    //find by longitude
    @NamedQuery (name = "Record.findByLongitude", query = "SELECT r FROM Record r WHERE r.longitude = :longitude"),
    //find by temperature
    @NamedQuery (name = "Record.findByTemperature", query = "SELECT r FROM Record r WHERE r.temperature = :temperature"),
    //find by humidity
    @NamedQuery (name = "Record.findByHumidity", query = "SELECT r FROM Record r WHERE r.humidity = :humidity"),
    //find by windspeed
    @NamedQuery (name = "Record.findByWspeed", query = "SELECT r FROM Record r WHERE r.windspeed = :windspeed"),
    //find by pressure
    @NamedQuery (name = "Record.findByPressure", query = "SELECT r FROM Record r WHERE r.pressure = :pressure")

        
    //find by period and weather
   // @NamedQuery (name = "Record.findByPeriod", query = "SELECT r FROM Record r WHERE r.recordPK.recorddate BETWEEN :startdate AND :enddate")


})


public class Record implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected RecordPK recordPK;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PAINLEVEL")
    private short painlevel;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "PAINLOCATION")
    private String painlocation;
    @Column(name = "MOODLEVEL")
    private Short moodlevel;
    @Size(max = 30)
    @Column(name = "PAINTTRIGGER")
    private String painttrigger;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "LATITUDE")
    private BigDecimal latitude;
    @Column(name = "LONGITUDE")
    private BigDecimal longitude;
    @Column(name = "TEMPERATURE")
    private Short temperature;
    @Column(name = "HUMIDITY")
    private BigDecimal humidity;
    @Column(name = "WINDSPEED")
    private Short windspeed;
    @Column(name = "PRESSURE")
    private Short pressure;
    @JoinColumn(name = "UID", referencedColumnName = "UID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Users users;
    @Transient private Date redate;
    @Transient private Date retime;
    
    public Record() {
    }

    public Record(RecordPK recordPK) {
        this.recordPK = recordPK;
    }

    public Record(RecordPK recordPK, short painlevel, String painlocation) {
        this.recordPK = recordPK;
        this.painlevel = painlevel;
        this.painlocation = painlocation;
    }

    public Record(int uid, Date recorddate, Date recordtime) {
        this.recordPK = new RecordPK(uid, recorddate, recordtime);
    }
    
    public Record (short painlevel, short temperature, Date recorddate){
        super();
        this.painlevel = painlevel;
        this.temperature = temperature;
        this.redate = recorddate;
    }
    public Record (short painlevel, BigDecimal humidity, Date recorddate){
        super();
        this.painlevel = painlevel;
        this.humidity = humidity;
        this.redate = recorddate;
    }
    public Record (Date recorddate, short painlevel, short windspeed){
        super();
        this.painlevel = painlevel;
        this.windspeed = windspeed;
        this.redate = recorddate;
    }
    public Record (short painlevel, Date recorddate, short pressure){
        super();
        this.painlevel = painlevel;
        this.redate = recorddate;
        this.pressure = pressure;
    }

    public Record(short painlevel, String painlocation, Short moodlevel, String painttrigger, Date redate,Date retime) {
        super();
        this.painlevel = painlevel;
        this.painlocation = painlocation;
        this.moodlevel = moodlevel;
        this.painttrigger = painttrigger;
        this.redate = redate;
        this.retime = retime;
    }

    public void setRetime(Date retime) {
        this.retime = retime;
    }

    public Date getRetime() {
        return retime;
    }
    
    
    
    public Date getRedate() {
        return redate;
    }
    public void setRedate(Date redate) {
        this.redate = redate;
    }
   
    
    public RecordPK getRecordPK() {
        return recordPK;
    }

    public void setRecordPK(RecordPK recordPK) {
        this.recordPK = recordPK;
    }

    public short getPainlevel() {
        return painlevel;
    }

    public void setPainlevel(short painlevel) {
        this.painlevel = painlevel;
    }

    public String getPainlocation() {
        return painlocation;
    }

    public void setPainlocation(String painlocation) {
        this.painlocation = painlocation;
    }

    public Short getMoodlevel() {
        return moodlevel;
    }

    public void setMoodlevel(Short moodlevel) {
        this.moodlevel = moodlevel;
    }

    public String getPainttrigger() {
        return painttrigger;
    }

    public void setPainttrigger(String painttrigger) {
        this.painttrigger = painttrigger;
    }

    public BigDecimal getLatitude() {
        return latitude;
    }

    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }

    public BigDecimal getLongitude() {
        return longitude;
    }

    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }

    public Short getTemperature() {
        return temperature;
    }

    public void setTemperature(Short temperature) {
        this.temperature = temperature;
    }

    public BigDecimal getHumidity() {
        return humidity;
    }

    public void setHumidity(BigDecimal humidity) {
        this.humidity = humidity;
    }

    public Short getWindspeed() {
        return windspeed;
    }

    public void setWindspeed(Short windspeed) {
        this.windspeed = windspeed;
    }

    public Short getPressure() {
        return pressure;
    }

    public void setPressure(Short pressure) {
        this.pressure = pressure;
    }

    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (recordPK != null ? recordPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Record)) {
            return false;
        }
        Record other = (Record) object;
        if ((this.recordPK == null && other.recordPK != null) || (this.recordPK != null && !this.recordPK.equals(other.recordPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "healthman.Record[ recordPK=" + recordPK + " ]";
    }
    
    
}
