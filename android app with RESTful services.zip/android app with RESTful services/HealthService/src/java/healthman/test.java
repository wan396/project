/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author juan
 */
@XmlRootElement
public class test {
    Short v2;
    Short v1;

    public Short getV2() {
        return v2;
    }

    public void setV2(Short v2) {
        this.v2 = v2;
    }

    public Short getV1() {
        return v1;
    }

    public void setV1(Short v1) {
        this.v1 = v1;
    }

    public test() {
    }

    public test(Short v2, Short v1) {
        this.v2 = v2;
        this.v1 = v1;
    }
    
}
