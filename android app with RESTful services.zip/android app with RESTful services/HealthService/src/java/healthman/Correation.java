/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman;

import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author juan
 */

@XmlRootElement
public class Correation {
    private double correation;
    private double pValue;
    
    public Correation(){}
    
    public Correation(double correation, double pValue){
        this.correation = correation;
        this.pValue = pValue;
    }

    public double getCorreation() {
        return correation;
    }

    public double getpValue() {
        return pValue;
    }

    public void setCorreation(double correation) {
        this.correation = correation;
    }

    public void setpValue(double pValue) {
        this.pValue = pValue;
    }   
}
