/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author juan
 */
@Entity
@Table(name = "DOCTOR")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Doctor.findAll", query = "SELECT d FROM Doctor d"),
    @NamedQuery(name = "Doctor.findByDid", query = "SELECT d FROM Doctor d WHERE d.did = :did"),
    @NamedQuery(name = "Doctor.findByFirstname", query = "SELECT d FROM Doctor d WHERE d.firstname = :firstname"),
    @NamedQuery(name = "Doctor.findBySurname", query = "SELECT d FROM Doctor d WHERE d.surname = :surname"),
    @NamedQuery(name = "Doctor.findByDoctorphone", query = "SELECT d FROM Doctor d WHERE d.doctorphone = :doctorphone"),
    @NamedQuery(name = "Doctor.findByClinicadd", query = "SELECT d FROM Doctor d WHERE d.clinicadd = :clinicadd"),
    @NamedQuery(name = "Doctor.findByClinicphone", query = "SELECT d FROM Doctor d WHERE d.clinicphone = :clinicphone"),
    @NamedQuery(name = "Doctor.findByDocAndDate", query = "SELECT new healthman.Doctor(u.firstname,u.surname,d.firstname,d.surname,r.redate) FROM Doctor d LEFT JOIN FETCH d.registrationCollection r INNER JOIN Users u WHERE r.uid = u.uid AND d.firstname= :firstname AND d.surname = :surname AND r.redate BETWEEN :startdate AND :enddate")
})
public class Doctor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "DID")
    private Integer did;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "FIRSTNAME")
    private String firstname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "SURNAME")
    private String surname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "DOCTORPHONE")
    private String doctorphone;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "CLINICADD")
    private String clinicadd;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "CLINICPHONE")
    private String clinicphone;
    @Size(max = 50)
    @Column(name = "SUBURB")
    private String suburb;
    @Size(max = 5)
    @Column(name = "STATE")
    private String state;
    
    @Transient private String doctorname;

    public void setDoctorname(String doctorname) {
        this.doctorname = doctorname;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getDoctorname() {
        return doctorname;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getSuburb() {
        return suburb;
    }

    public String getState() {
        return state;
    }
    @OneToMany(mappedBy = "did")
    private Collection<Registration> registrationCollection;
    @Transient private String userfirstname;
    @Transient private String usersurname;
    @Transient private Date regDate;
    
    public Doctor() {
    }

    public Doctor(Integer did) {
        this.did = did;
    }

    public Doctor(Integer did, String firstname, String surname, String doctorphone, String clinicadd, String clinicphone) {
        this.did = did;
        this.firstname = firstname;
        this.surname = surname;
        this.doctorphone = doctorphone;
        this.clinicadd = clinicadd;
        this.clinicphone = clinicphone;
    }

    public Doctor(String userfirstname, String usersurname, String firstname, String surname, Date regDate){
        this.userfirstname = userfirstname;
        this.usersurname = usersurname;
        this.firstname = firstname;
        this.surname = surname;
        this.regDate = regDate;
    }

    public Doctor(Integer did, String doctorname){
        this.did = did;
        this.doctorname = doctorname;
    }
    
    public Doctor (String clinicadd, String suburb, String state){
        this.clinicadd = clinicadd;
        this.suburb = suburb;
        this.state = state;
    }
    public String getUserfirstname() {
        return userfirstname;
    }

    public void setUserfirstname(String userfirstname) {
        this.userfirstname = userfirstname;
    }

    public void setUsersurname(String usersurname) {
        this.usersurname = usersurname;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }

    public String getUsersurname() {
        return usersurname;
    }

    public Date getRegDate() {
        return regDate;
    }
    
    
    public Integer getDid() {
        return did;
    }

    public void setDid(Integer did) {
        this.did = did;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getDoctorphone() {
        return doctorphone;
    }

    public void setDoctorphone(String doctorphone) {
        this.doctorphone = doctorphone;
    }

    public String getClinicadd() {
        return clinicadd;
    }

    public void setClinicadd(String clinicadd) {
        this.clinicadd = clinicadd;
    }

    public String getClinicphone() {
        return clinicphone;
    }

    public void setClinicphone(String clinicphone) {
        this.clinicphone = clinicphone;
    }

    @XmlTransient
    public Collection<Registration> getRegistrationCollection() {
        return registrationCollection;
    }

    public void setRegistrationCollection(Collection<Registration> registrationCollection) {
        this.registrationCollection = registrationCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (did != null ? did.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Doctor)) {
            return false;
        }
        Doctor other = (Doctor) object;
        if ((this.did == null && other.did != null) || (this.did != null && !this.did.equals(other.did))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "healthman.Doctor[ did=" + did + " ]";
    }
    
}
