/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman.service;

import healthman.Doctor;
import healthman.Registration;
import healthman.Users;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author juan
 */
@Stateless
@Path("healthman.doctor")
public class DoctorFacadeREST extends AbstractFacade<Doctor> {

    @PersistenceContext(unitName = "HealthServicePU")
    private EntityManager em;

    public DoctorFacadeREST() {
        super(Doctor.class);
    }

    @POST
    @Override
    @Consumes(MediaType.APPLICATION_JSON)
    public void create(Doctor entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes( MediaType.APPLICATION_JSON)
    public void edit(@PathParam("id") Integer id, Doctor entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces( MediaType.APPLICATION_JSON)
    public Doctor find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces(MediaType.APPLICATION_JSON)
    public List<Doctor> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Doctor> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    /**
     *
     * @param firstname
     * @param surname
     * @param startdate
     * @param enddate
     * @return
     */
    /*@GET
    @Path("findByDocAndDate/{firstname}/{surname}/{startdate}/{enddate}")
    @Produces({"application/json"})
    public List<Doctor> findByDocAndDate(@PathParam("firstname") String firstname,@PathParam("surname") String surname,@PathParam("startdate") String startdate,@PathParam("enddate") String enddate)
    throws ParseException
    {
        SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
        Date start = format.parse(startdate);
        Date end = format.parse(enddate);
        Query query = em.createNamedQuery("Doctor.findByDocAndDate");
        query.setParameter("firstname", firstname);
        query.setParameter("surname", surname);
        query.setParameter("startdate", start, TemporalType.DATE);
        query.setParameter("enddate", end, TemporalType.DATE);
        return query.getResultList();
    }
        //Collection<Registration> reg = query.getResultList();
        
        /*String string2 = "SELECT u FROM Users u INNER JOIN Registration r ON u.uid = r.uid WHERE r.username = :username";
        TypedQuery<Users> query2 = em.createQuery(string2,Users.class);
        query2.setParameter("username", username);
        List<Users> reUser = query2.getResultList();
        List<Users> result = new ArrayList<>();
        for(Registration r: reg){
            int uidR = r.getUid();
            for(Users u: reUser){
                int uidU = u.getUid();
                if (uidU==uidR){
                    result.add(u);
                }
            }
        }
        return result;*/
    
    //attribute:  firstname
    @GET
    @Path("findByFirstname/{firstname}")
    @Produces({"application/json"})
    public List<Doctor> findByFirstname(@PathParam("firstname") String firstname){
        String string = "SELECT d FROM Doctor d WHERE d.firstname = :firstname";
        TypedQuery<Doctor> query = em.createQuery(string,Doctor.class);
        query.setParameter("firstname", firstname);
        return query.getResultList();
    }
    //attribute:  surname
    @GET
    @Path("findBySurname/{surname}")
    @Produces({"application/json"})
    public List<Doctor> findBySurname(@PathParam("surname") String surname){
        String string = "SELECT d FROM Doctor d WHERE d.surname = :surname";
        TypedQuery<Doctor> query = em.createQuery(string,Doctor.class);
        query.setParameter("surname", surname);
        return query.getResultList();
    }
    //attribute:  doctorphone
    @GET
    @Path("findByDoctorphone/{doctorphone}")
    @Produces({"application/json"})
    public List<Doctor> findByDoctorphone(@PathParam("doctorphone") String doctorphone){
        String string = "SELECT d FROM Doctor d WHERE d.doctorphone = :doctorphone";
        TypedQuery<Doctor> query = em.createQuery(string,Doctor.class);
        query.setParameter("doctorphone", doctorphone);
        return query.getResultList();
    }
    //attribute:  clinicadd
    @GET
    @Path("findByClinicadd/{clinicadd}")
    @Produces({"application/json"})
    public List<Doctor> findByClinicadd(@PathParam("clinicadd") String clinicadd){
        String string = "SELECT d FROM Doctor d WHERE d.clinicadd = :clinicadd";
        TypedQuery<Doctor> query = em.createQuery(string,Doctor.class);
        query.setParameter("clinicadd", clinicadd);
        return query.getResultList();
    }
    //attribute:  clinicphone
    @GET
    @Path("findByClinicphone/{clinicphone}")
    @Produces({"application/json"})
    public List<Doctor> findByClinicphone(@PathParam("clinicphone") String clinicphone){
        String string = "SELECT d FROM Doctor d WHERE d.clinicphone = :clinicphone";
        TypedQuery<Doctor> query = em.createQuery(string,Doctor.class);
        query.setParameter("clinicphone", clinicphone);
        return query.getResultList();
    }
    
    @GET
    @Path("findClinicAdd")
    @Produces({"application/json"})
    public String findClinicAdd(){
        String string = "SELECT new healthman.Doctor(d.clinicadd,d.suburb,d.state) FROM Doctor d";
        TypedQuery<Doctor> query = em.createQuery(string,Doctor.class);
        List<Doctor> re = query.getResultList();
        JSONArray address = new JSONArray();
        try{
            for(int i = 0; i < re.size(); i++){
            Doctor doct = re.get(i);
            String add = doct.getClinicadd();
            String sub = doct.getSuburb();
            String sta = doct.getState();
            String full = add + "," + sub + "," + sta;
            JSONObject obj = new JSONObject();
            obj.put("address", full);
            address.put(obj);
            }
        }catch(Exception e){} 
        return address.toString();
    }
    
    @GET
    @Path("findDoctorName/{address}")
    @Produces({"application/json"})
    public String findDoctorName(@PathParam("address") String address){
        String[] parts = address.split(",");
        String add = parts[0];
        String suburb = parts[1];
        String state = parts[2];
        System.out.println(add);
        System.out.println(suburb);
        System.out.println(state);

        String string = "SELECT d FROM Doctor d WHERE d.clinicadd = :add AND d.suburb=:suburb AND UPPER(d.state)=UPPER(:state)";
        TypedQuery<Doctor> query = em.createQuery(string,Doctor.class);
        query.setParameter("add", add);
        query.setParameter("suburb", suburb);
        query.setParameter("state", state);
        List<Doctor> re = query.getResultList();
        JSONArray fullname = new JSONArray();
        try{
            for(int i = 0; i < re.size(); i++){
            Doctor doct = re.get(i);
            int doid = (int)doct.getDid();
            String fname = doct.getFirstname();
            String sname = doct.getSurname();
            String full = fname + " " + sname;
            JSONObject obj = new JSONObject();
            obj.put("did", doid);
            obj.put("fullname", full);
            fullname.put(obj);
        }
        }catch(Exception e){}
        return fullname.toString();
    }
}
