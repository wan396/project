/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman.service;

import healthman.Correation;
import healthman.Frequency;
import healthman.Plevel;
import healthman.Plocation;
import healthman.Record;
import healthman.RecordPK;
import healthman.Users;
import healthman.test;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.PathSegment;
import java.text.ParseException; 
import static java.util.stream.DoubleStream.builder;
import static java.util.stream.IntStream.builder;
import static java.util.stream.Stream.builder;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.persistence.*;
import javax.persistence.criteria.*;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.netbeans.saas.RestConnection;
import org.netbeans.saas.RestResponse;

/**
 *
 * @author juan
 */
@Stateless
@Path("healthman.record")
public class RecordFacadeREST extends AbstractFacade<Record> {

    PublicAPI pua = new PublicAPI();
    @PersistenceContext(unitName = "HealthServicePU")
    private EntityManager em;

    private RecordPK getPrimaryKey(PathSegment pathSegment) {
        /*
         * pathSemgent represents a URI path segment and any associated matrix parameters.
         * URI path part is supposed to be in form of 'somePath;uid=uidValue;recorddate=recorddateValue;recordtime=recordtimeValue'.
         * Here 'somePath' is a result of getPath() method invocation and
         * it is ignored in the following code.
         * Matrix parameters are used as field names to build a primary key instance.
         */
        healthman.RecordPK key = new healthman.RecordPK();
        javax.ws.rs.core.MultivaluedMap<String, String> map = pathSegment.getMatrixParameters();
        java.util.List<String> uid = map.get("uid");
        if (uid != null && !uid.isEmpty()) {
            key.setUid(new java.lang.Integer(uid.get(0)));
        }
        java.util.List<String> recorddate = map.get("recorddate");
        if (recorddate != null && !recorddate.isEmpty()) {
            key.setRecorddate(new java.util.Date(recorddate.get(0)));
        }
        java.util.List<String> recordtime = map.get("recordtime");
        if (recordtime != null && !recordtime.isEmpty()) {
            key.setRecordtime(new java.util.Date(recordtime.get(0)));
        }
        return key;
    }

    public RecordFacadeREST() {
        super(Record.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Record entity) {
        super.create(entity);
    }
    @POST
    @Path("addRecord")
    @Consumes({"application/json"})
    public void addRecord(String string) {
          
        try{
            JSONObject obj = new JSONObject(string);
            int uid = obj.getInt("uid");
            String date = obj.getString("date");
            String time = obj.getString("time");
            SimpleDateFormat dateformat = new SimpleDateFormat ("yyyy-MM-dd");
            Date recdate = dateformat.parse(date);
            SimpleDateFormat timeformat = new SimpleDateFormat ("hh:mm:ss");
            Date rectime = timeformat.parse(time);
            double lat = obj.getDouble("lat");
            double lng = obj.getDouble("lng");
            BigDecimal latitude = new BigDecimal(lat);
            BigDecimal longe = new BigDecimal(lng);
            JSONObject weather = pua.getWeather(lat, lng);
            Integer temp = weather.getInt("temp");
            short tem = temp.shortValue();
            Integer pressure = weather.getInt("pressure");
            short pre = pressure.shortValue();
            double humidty = weather.getDouble("humidity");
            BigDecimal hum = new BigDecimal(humidty);
            Integer windspeed = weather.getInt("windspeed");
            short ws = windspeed.shortValue();
            String painloc = obj.getString("painloc");
            Integer painlevl = obj.getInt("painlevl");
            short pl = painlevl.shortValue();
            String paintrigg = obj.getString("paintrigg");
            Integer moodlevl = obj.getInt("moodlevl");
            short ml = moodlevl.shortValue();
            RecordPK recordpk = new RecordPK(uid,recdate,rectime);
            Record record = new Record(recordpk);
            record.setPainlevel(pl);
            record.setPainlocation(painloc);
            record.setPainttrigger(paintrigg);
            record.setMoodlevel(ml);
            record.setTemperature(tem);
            record.setHumidity(hum);
            record.setPressure(pre);
            record.setWindspeed(ws);
            record.setLatitude(latitude);
            record.setLongitude(longe);
            em.persist(record);
            em.flush();
//em.find(Record.class, recordpk);
            
            
        }catch(Exception e){
            System.out.println(e);
        }       
    }

    @POST
    @Path("editRecord")
    @Consumes({"application/json"})
    public void editRecord(String string) {
          
        try{
            JSONObject obj = new JSONObject(string);
            int uid = obj.getInt("uid");
            String date = obj.getString("date");
            String time = obj.getString("time");
            SimpleDateFormat dateformat = new SimpleDateFormat ("yyyy-MM-dd");
            Date recdate = dateformat.parse(date);
            SimpleDateFormat timeformat = new SimpleDateFormat ("hh:mm:ss");
            Date rectime = timeformat.parse(time);
            double lat = obj.getDouble("lat");
            double lng = obj.getDouble("lng");
            BigDecimal latitude = new BigDecimal(lat);
            BigDecimal longe = new BigDecimal(lng);
            JSONObject weather = pua.getWeather(lat, lng);
            Integer temp = weather.getInt("temp");
            short tem = temp.shortValue();
            Integer pressure = weather.getInt("pressure");
            short pre = pressure.shortValue();
            double humidty = weather.getDouble("humidity");
            BigDecimal hum = new BigDecimal(humidty);
            Integer windspeed = weather.getInt("windspeed");
            short ws = windspeed.shortValue();
            String painloc = obj.getString("painloc");
            Integer painlevl = obj.getInt("painlevl");
            short pl = painlevl.shortValue();
            String paintrigg = obj.getString("paintrigg");
            Integer moodlevl = obj.getInt("moodlevl");
            short ml = moodlevl.shortValue();
            RecordPK recordpk = new RecordPK(uid,recdate,rectime);

            Record record = em.find(Record.class, recordpk);
            record.setPainlevel(pl);
            record.setPainlocation(painloc);
            record.setPainttrigger(paintrigg);
            record.setMoodlevel(ml);
            em.persist(record);
            em.flush();     
        }catch(Exception e){
            System.out.println(e);
        }       
    }
    
    @POST
    @Path("romoveRecord")
    @Consumes({"application/json"})
    public void romoveRecord(String string) {
        try{
            JSONObject obj = new JSONObject(string);
            int uid = obj.getInt("uid");
            String date = obj.getString("date");
            String time = obj.getString("time");
            SimpleDateFormat dateformat = new SimpleDateFormat ("yyyy-MM-dd");
            Date recdate = dateformat.parse(date);
            SimpleDateFormat timeformat = new SimpleDateFormat ("hh:mm:ss");
            Date rectime = timeformat.parse(time);
            RecordPK recordpk = new RecordPK(uid,recdate,rectime);
            
            Record record = em.find(Record.class, recordpk);
            em.remove(record);
            em.persist(record);
            em.flush(); 
        }catch(Exception e){
            System.out.println(e);
        } 
    }
    
    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") PathSegment id, Record entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") PathSegment id) {
        healthman.RecordPK key = getPrimaryKey(id);
        super.remove(super.find(key));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Record find(@PathParam("id") PathSegment id) {
        healthman.RecordPK key = getPrimaryKey(id);
        return super.find(key);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Record> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Record> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    //find by uid
    @GET
    @Path("findByUid/{uid}")
    @Produces({"application/json"})
    public List<Record> findByUid (@PathParam("uid") Integer uid){
        Query query = em.createNamedQuery("Record.findByUid");
        query.setParameter("uid",uid);
        return query.getResultList();
    }
    //find by recorddate
    @GET
    @Path("findByRedate/{recorddate}")
    @Produces({"application/json"})
    public List<Record> findByRedate(@PathParam("recorddate") String recorddate) throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
        Date reDate = format.parse (recorddate);
        Query query = em.createNamedQuery("Record.findByRedate");
        query.setParameter("recorddate", reDate, TemporalType.DATE);
        return query.getResultList();
    }
    //find by recordtime
    @GET
    @Path("findByRetime/{recordtime}")
    @Produces({"application/json"})
    public List<Record> findByRetime(@PathParam("recordtime") String recordtime) throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat ("hh:mm:ss");
        Date reTime = format.parse (recordtime);
        Query query = em.createNamedQuery("Record.findByRetime");
        query.setParameter("recordtime", reTime, TemporalType.TIME);
        return query.getResultList();
    }
    //find by painlevel
    @GET
    @Path("findByPLevel/{painlevel}")
    @Produces({"application/json"})
    public List<Record> findByPLevel (@PathParam("painlevel") Integer painlevel){
        Query query = em.createNamedQuery("Record.findByPLevel");
        query.setParameter("painlevel",painlevel);
        return query.getResultList();
    }
    //find by painlocation
    @GET
    @Path("findByPLocation/{painlocation}")
    @Produces({"application/json"})
    public List<Record> findByPLocation (@PathParam("painlocation") String painlocation){
        Query query = em.createNamedQuery("Record.findByPLocation");
        query.setParameter("painlocation",painlocation);
        return query.getResultList();
    }
    //find by moodlevel
    @GET
    @Path("findByMLevel/{moodlevel}")
    @Produces({"application/json"})
    public List<Record> findByMLevel (@PathParam("moodlevel") Integer moodlevel){
        Query query = em.createNamedQuery("Record.findByMLevel");
        query.setParameter("moodlevel",moodlevel);
        return query.getResultList();
    }
    //find by painttrigger
    @GET
    @Path("findByPTrigger/{painttrigger}")
    @Produces({"application/json"})
    public List<Record> findByPTrigger (@PathParam("painttrigger") String painttrigger){
        Query query = em.createNamedQuery("Record.findByPTrigger");
        query.setParameter("painttrigger",painttrigger);
        return query.getResultList();
    }
    //find by latitude
    @GET
    @Path("findByLatitude/{latitude}")
    @Produces({"application/json"})
    public List<Record> findByLatitude (@PathParam("latitude") BigDecimal latitude){
        Query query = em.createNamedQuery("Record.findByLatitude");
        query.setParameter("latitude",latitude);
        return query.getResultList();
    }
    //find by longitude
    @GET
    @Path("findByLongitude/{longitude}")
    @Produces({"application/json"})
    public List<Record> findByLongitude (@PathParam("longitude") BigDecimal longitude){
        Query query = em.createNamedQuery("Record.findByLongitude");
        query.setParameter("longitude",longitude);
        return query.getResultList();
    }
    //find by temperature
    @GET
    @Path("findByTemperature/{temperature}")
    @Produces({"application/json"})
    public List<Record> findByTemperature (@PathParam("temperature") Integer temperature){
        Query query = em.createNamedQuery("Record.findByTemperature");
        query.setParameter("temperature",temperature);
        return query.getResultList();
    }
    //find by humidity
    @GET
    @Path("findByHumidity/{humidity}")
    @Produces({"application/json"})
    public List<Record> findByHumidity (@PathParam("humidity") BigDecimal humidity){
        Query query = em.createNamedQuery("Record.findByHumidity");
        query.setParameter("humidity",humidity);
        return query.getResultList();
    }
    //find by windspeed
    @GET
    @Path("findByWspeed/{windspeed}")
    @Produces({"application/json"})
    public List<Record> findByWspeed (@PathParam("windspeed") Integer windspeed){
        Query query = em.createNamedQuery("Record.findByWspeed");
        query.setParameter("windspeed",windspeed);
        return query.getResultList();
    }
    //find by pressure
    @GET
    @Path("findByPressure/{pressure}")
    @Produces({"application/json"})
    public List<Record> findByPressure (@PathParam("pressure") Integer pressure){
        Query query = em.createNamedQuery("Record.findByPressure");
        query.setParameter("pressure",pressure);
        return query.getResultList();
    }
     
    

    
    @GET
    @Path("findByPeriod/{startdate}/{enddate}/{weather}")
    @Produces({"application/json"})
    public List<Record> findByPeriod(@PathParam("startdate") String startdate, @PathParam("enddate") String enddate, @PathParam("weather") String weather) throws ParseException
    {
        SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
        Date start = format.parse (startdate);
        Date end = format.parse (enddate);
        String excute = null;
        switch (weather){
            case "temperature": 
                excute = "SELECT new healthman.Record(r.painlevel, r.temperature, r.recordPK.recorddate) FROM Record r WHERE r.recordPK.recorddate BETWEEN :startdate AND :enddate";
                break;
            case "humidity": 
                excute = "SELECT new healthman.Record(r.painlevel, r.humidity, r.recordPK.recorddate) FROM Record r WHERE r.recordPK.recorddate BETWEEN :startdate AND :enddate";
                break;
            case "windspeed":    
                excute = "SELECT new healthman.Record(r.recordPK.recorddate, r.painlevel, r.windspeed) FROM Record r WHERE r.recordPK.recorddate BETWEEN :startdate AND :enddate";
                break;
            case "pressure":    
                excute = "SELECT new healthman.Record(r.painlevel, r.recordPK.recorddate, r.pressure) FROM Record r WHERE r.recordPK.recorddate BETWEEN :startdate AND :enddate";
                break;
    }
        TypedQuery query = em.createQuery(excute,Record.class);
        query.setParameter("startdate", start, TemporalType.DATE);
        query.setParameter("enddate", end, TemporalType.DATE);
        return query.getResultList();
        //String string = "SELECT r FROM Record r WHERE r.recordPK.recorddate BETWEEN :startdate AND :enddate";
       //return em.createQuery("SELECT new healthman.test(r.painlevel,r.temperature) FROM Record r WHERE r.recordPK.recorddate BETWEEN :startdate AND :enddate",test.class).setParameter("enddate", end, TemporalType.DATE).setParameter("startdate", start, TemporalType.DATE).getResultList();
//        List<test> retList=new ArrayList<>();
//        for(Object[] o :resultList)
//        {
//            retList.add(new test((Short)o[0], (Short)o[1]));
//        }
//        return retList;
//        TypedQuery<Record> query = em.createQuery(string,Record.class);
//        query.setParameter("startdate", start, TemporalType.DATE);
//        query.setParameter("enddate", end, TemporalType.DATE);
//        List<Record> r = query.getResultList();
//        List<String> arr = new ArrayList<String>();
//        //arr.add("123");
//        for(Record re: r)
//        {
//            String pl = Integer.toString(re.getPainlevel());
//            String tm = Integer.toString(re.getTemperature());
//            String da = format.format(re.getRecordPK().getRecorddate());
//            String str = pl + ", " + tm + ", " + da;
//            arr.add(str);           
//        }
//        GenericEntity<List<String>> en = new GenericEntity<List<String>>(arr) {};
//        return Response.ok(en).build();
        
    }
    
    @GET
    @Path("findPainFrequency/{startdate}/{enddate}")
    @Produces({"application/json"})
    public List<Frequency> findPainFrequency(@PathParam("startdate") String startdate, @PathParam("enddate") String enddate) throws ParseException
    {
        SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
        Date start = format.parse (startdate);
        Date end = format.parse (enddate);
        String string = "SELECT new healthman.Frequency(r.painlocation, COUNT(r.painlocation)) FROM Record r WHERE r.recordPK.recorddate BETWEEN :startdate AND :enddate GROUP BY r.painlocation";
        TypedQuery query = em.createQuery(string,Frequency.class);
        query.setParameter("startdate", start, TemporalType.DATE);
        query.setParameter("enddate", end, TemporalType.DATE);
        return query.getResultList();
    }
    
    @GET
    @Path("findCorrelation/{startdate}/{enddate}/{weather}")
    @Produces({"application/json"})
    public Correation findCorrelation(@PathParam("startdate") String startdate, @PathParam("enddate") String enddate, @PathParam("weather") String weather) throws ParseException
    {
        SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
        Date start = format.parse (startdate);
        Date end = format.parse (enddate);
        String string = "SELECT r FROM Record r WHERE r.recordPK.recorddate BETWEEN :startdate AND :enddate";
        TypedQuery query = em.createQuery(string,Frequency.class);
        query.setParameter("startdate", start, TemporalType.DATE);
        query.setParameter("enddate", end, TemporalType.DATE);
        List<Record> listRecord = query.getResultList();
        double[][] array = new double[listRecord.size()][2];
        for(int i = 0; i < listRecord.size(); i++){
            Record re = listRecord.get(i);
            double pLevel = (double) re.getPainlevel();
            array[i][0] = pLevel;
            switch(weather){           
                case "temperature":
                    double temp = (double) re.getTemperature();
                    array[i][1] = temp;break;
                case "humidity": 
                    double hum = re.getHumidity().doubleValue();
                    array[i][1] = hum;break;
                case "windspeed": 
                    double wind = (double) re.getWindspeed();
                    array[i][1] = wind;break;
                case "pressure": 
                    double pre = (double) re.getPressure();
                    array[i][1] = pre;break;
            }
        }
        RealMatrix m = MatrixUtils.createRealMatrix(array);
        PearsonsCorrelation pc = new PearsonsCorrelation(m);
        RealMatrix corM = pc.getCorrelationMatrix();
        RealMatrix pM = pc.getCorrelationPValues();
        double corre = corM.getEntry(0,1);
        double p = pM.getEntry(0, 1);
        return new healthman.Correation(corre,p);       
    }    
    
    @GET
    @Path("findPLevelAndWea/{uid}/{startdate}/{enddate}/{weather}")
    @Produces({"application/json"})
    public List<Plevel> findPLevelAndWea(@PathParam("uid") Integer uid, @PathParam("startdate") String startdate, @PathParam("enddate") String enddate, @PathParam("weather") String weather) 
            throws ParseException
    {
        SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
        Date start = format.parse (startdate);
        Date end = format.parse (enddate);
        String string = null;
        switch (weather){
            case "temperature": 
                string = "SELECT new healthman.Plevel(r.painlevel, r.temperature, r.recordPK.recorddate) FROM Record r WHERE r.recordPK.uid = :uid AND r.recordPK.recorddate BETWEEN :startdate AND :enddate";
                break;
            case "humidity": 
                string = "SELECT new healthman.Plevel(r.painlevel, r.humidity, r.recordPK.recorddate) FROM Record r WHERE r.recordPK.uid = :uid AND r.recordPK.recorddate BETWEEN :startdate AND :enddate";
                break;
            case "windspeed":    
                string = "SELECT new healthman.Plevel(r.painlevel, r.windspeed, r.recordPK.recorddate) FROM Record r WHERE r.recordPK.uid = :uid AND r.recordPK.recorddate BETWEEN :startdate AND :enddate";
                break;
            case "pressure":    
                string = "SELECT new healthman.Plevel(r.painlevel, r.pressure, r.recordPK.recorddate) FROM Record r WHERE r.recordPK.uid = :uid AND r.recordPK.recorddate BETWEEN :startdate AND :enddate";
                break;
    }
        TypedQuery query = em.createQuery(string, Plevel.class);
        query.setParameter("uid", uid);
        query.setParameter("startdate", start, TemporalType.DATE);
        query.setParameter("enddate", end, TemporalType.DATE);       
        return query.getResultList();    
    }
    
    @GET
    @Path("findPLocationByDate/{uid}/{startdate}/{enddate}")
    @Produces({"application/json"})
    public List<Frequency> findPLevelAndWea(@PathParam("uid") Integer uid, @PathParam("startdate") String startdate, @PathParam("enddate") String enddate) 
            throws ParseException, JSONException  {
        SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
        Date start = format.parse (startdate);
        Date end = format.parse (enddate);
        String string = "SELECT new healthman.Frequency(r.painlocation, COUNT(r.painlocation)) FROM Record r WHERE r.recordPK.uid = :uid AND r.recordPK.recorddate BETWEEN :startdate AND :enddate GROUP BY r.painlocation";
        TypedQuery query = em.createQuery(string, Frequency.class);
        query.setParameter("uid", uid);
        query.setParameter("startdate", start, TemporalType.DATE);
        query.setParameter("enddate", end, TemporalType.DATE);
        return query.getResultList();

    }
    
    @GET
    @Path("findByName/{cityname}")
    @Produces({"application/json"})
    public String getByName(@PathParam("cityname") String cityname){
        String API_key = "58694f9b466c1fa61b9fdc7f9de1801a";
        String strResponse="";
        RestConnection conn = new RestConnection ("http://api.openweathermap.org/data/2.5/weather?q="+cityname+"&APPID="+API_key+"&units=metric");
        JSONObject json = new JSONObject();
        try{
            RestResponse response = conn.get();
            strResponse  =response.getDataAsString();
        
        
        System.out.println(strResponse);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        return strResponse;
    }
    
    @GET
    @Path("findRecord/{uid}")
    @Produces({"application/json"})
    public List<Record> findRecord(@PathParam("uid") int uid){
        String string = "SELECT new healthman.Record(r.painlevel,r.painlocation,r.moodlevel,r.painttrigger,r.recordPK.recorddate,r.recordPK.recordtime) FROM Record r WHERE r.recordPK.uid =:uid";
        TypedQuery query = em.createQuery(string,Record.class);
        query.setParameter("uid", uid);
        return query.getResultList();
    }
    

}
