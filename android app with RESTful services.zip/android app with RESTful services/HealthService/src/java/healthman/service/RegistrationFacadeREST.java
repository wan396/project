/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman.service;

import healthman.Doctor;
import healthman.Registration;
import healthman.Users;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.JSONObject;

/**
 *
 * @author juan
 */
@Stateless
@Path("healthman.registration")
public class RegistrationFacadeREST extends AbstractFacade<Registration> {

    @PersistenceContext(unitName = "HealthServicePU")
    private EntityManager em;

    public RegistrationFacadeREST() {
        super(Registration.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Registration entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Registration entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Registration find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Registration> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Registration> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Path("findDoctor/{firstname}")
    @Produces({"application/json"})
    public List<Registration> findDoctor(@PathParam("firstname") String firstname){
        String string = "SELECT r FROM Registration r WHERE r.did.firstname = :firstname";
        TypedQuery<Registration> query = em.createQuery(string,Registration.class);
        query.setParameter("firstname", firstname);
        return query.getResultList();
    }
    
    @GET
    @Path("findByDocAndDate")
    @Produces({"application/json"})
    public List<Registration> findByDocAndDate(){
        String string = "SELECT r FROM Registration r join r.uid u where u.uid=1";
        TypedQuery<Registration> query = em.createQuery(string,Registration.class);
        //query.setParameter("firstname", firstname);
        return query.getResultList();
    }
    
    @GET
    @Path("findByGenderAndOcc/{gender}/{occupation}")
    @Produces({"application/json"})
    public List<Registration> findByGenderAndDate(@PathParam("gender") String gender,@PathParam("occupation") String occupation)
    {
        String string = "SELECT r FROM Registration r,Users u WHERE r.uid = u.uid and UPPER(u.gender) = UPPER(:gender) AND u.occupation = :occupation";
        TypedQuery<Registration> query = em.createQuery(string,Registration.class);
        query.setParameter("gender", gender);
        query.setParameter("occupation",occupation);
        return query.getResultList();

    }
    
//attribute:  username
    @GET
    @Path("findByUsername/{username}")
    @Produces({"application/json"})
    public List<Registration> findByUsername(@PathParam("username") String username){
        String string = "SELECT r FROM Registration r WHERE r.username = :username";
        TypedQuery<Registration> query = em.createQuery(string,Registration.class);
        query.setParameter("username", username);
        return query.getResultList();
    }
//attribute:  password
    @GET
    @Path("findByPassword/{password}")
    @Produces({"application/json"})
    public List<Registration> findByPassword(@PathParam("password") String password){
        String string = "SELECT r FROM Registration r WHERE r.password = :password";
        TypedQuery<Registration> query = em.createQuery(string,Registration.class);
        query.setParameter("password", password);
        return query.getResultList();
    }
//attribute:  redate
    @GET
    @Path("findByRedate/{redate}")
    @Produces({"application/json"})
    public List<Registration> findByRedate(@PathParam("redate") String redate) throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
        Date date = format.parse(redate);
        String string = "SELECT r FROM Registration r WHERE r.redate = :redate";
        TypedQuery<Registration> query = em.createQuery(string,Registration.class);
        query.setParameter("redate", date, TemporalType.DATE);
        return query.getResultList();
    }
//attribute:  retime
    @GET
    @Path("findByRetime/{retime}")
    @Produces({"application/json"})
    public List<Registration> findByRetime(@PathParam("retime") String retime) throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat ("hh:mm:ss");
        Date date = format.parse(retime);
        String string = "SELECT r FROM Registration r WHERE r.retime = :retime";
        TypedQuery<Registration> query = em.createQuery(string,Registration.class);
        query.setParameter("retime", date, TemporalType.TIME);
        return query.getResultList();
    }
//attribute:  did
    @GET
    @Path("findByDid/{did}")
    @Produces({"application/json"})
    public List<Registration> findByDid(@PathParam("did") short did){
        String string = "SELECT r FROM Registration r WHERE r.did.did = :did";
        TypedQuery<Registration> query = em.createQuery(string,Registration.class);
        query.setParameter("did", did);
        return query.getResultList();
    }

    @GET
    @Path("valiUser/{username}/{password}/{isLocal}")
    @Produces({"application/json"})
    public List<Registration> valifyUser(@PathParam("username") String username,@PathParam("password") String password,@PathParam("isLocal") String isLocal) {
        boolean isMatch = false;
        int userid = 0;
        JSONObject obj = new JSONObject();
        String string = "select r from Registration r where r.username=:username";
        TypedQuery<Registration> query = em.createQuery(string, Registration.class);
        query.setParameter("username", username);
        List<Registration> result = query.getResultList();
            Registration reg = result.get(0);
            String getpass = reg.getPassword();
            userid = reg.getUid();
            System.out.println(getpass);
            System.out.println(userid);

        return query.getResultList();
    }
    
    @POST
    @Path("register")
    @Consumes({"application/json"})
    public Response register(String string) {
        
        try{
            JSONObject request= new JSONObject(string);
            int uid = request.getInt("uid");
            String username = request.getString("username");
            String password = request.getString("password");
            String redate = request.getString("redate");
            String retime = request.getString("retime");
            SimpleDateFormat dateformat = new SimpleDateFormat ("yyyy-MM-dd");
            Date redateForm = dateformat.parse(redate);
            SimpleDateFormat timeformat = new SimpleDateFormat ("hh:mm:ss");
            Date retimeForm = timeformat.parse(retime);
            int did = request.getInt("did");
            
            Doctor d = em.getReference(Doctor.class, did);
            Users u = em.getReference(Users.class, uid);
            Registration regs = new Registration(uid);
            regs.setUsers(u);
            regs.setUsername(username);
            regs.setPassword(password);
            regs.setRedate(redateForm);
            regs.setRetime(retimeForm);
            regs.setDid(d);
            em.persist(regs);
            em.flush();
        //super.create(regs);
        }catch(Exception e){}
        return Response.ok("success",MediaType.TEXT_PLAIN).build();
    }
}
