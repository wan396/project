/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman.service;

import healthman.Doctor;
import healthman.Registration;
import healthman.Users;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.JSONObject;

/**
 *
 * @author juan
 */
@Stateless
@Path("healthman.users")
public class UsersFacadeREST extends AbstractFacade<Users> {

    PublicAPI papi = new PublicAPI();
    @PersistenceContext(unitName = "HealthServicePU")
    private EntityManager em;

    public UsersFacadeREST() {
        super(Users.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Users entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Users entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Users find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Users> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Path("findFemale/{gender}/{weight}/{height}")
    @Produces({"application/json"})
    public List<Users> findFemale(@PathParam("gender") String gender,@PathParam("weight") int weight,@PathParam("height") int height){
        TypedQuery<Users> query = em.createQuery("SELECT u FROM Users u WHERE UPPER(u.gender)= UPPER(:gender) and u.weight= :weight and u.height= :height", 
                Users.class);
        query.setParameter("gender",gender);
        query.setParameter("weight",weight);
        query.setParameter("height",height);
        return query.getResultList();
    }
    
    @GET
    @Path("findByPain/{painlevel}/{painlocation}")
    @Produces({"application/json"})
    public List<Users> findByPain(@PathParam("painlevel") short painlevel,@PathParam("painlocation") String painlocation){
        String string = "SELECT u FROM Users u,Record r WHERE u.uid = r.recordPK.uid and r.painlevel = :painlevel and r.painlocation = :painlocation";
        TypedQuery<Users> query = em.createQuery(string,Users.class);
        query.setParameter("painlevel", painlevel);
        query.setParameter("painlocation", painlocation);
        return query.getResultList();
    }
    
    @GET
    @Path("findByGenderAndDate/{gender}/{startdate}/{enddate}")
    @Produces({"application/json"})
    public List<Users> findByGenderAndDate(@PathParam("gender") String gender,@PathParam("startdate") String startdate,@PathParam("enddate") String enddate)
    throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
        Date start = format.parse(startdate);
        Date end = format.parse(enddate);
        String string = "SELECT u FROM Users u WHERE UPPER(u.gender) = UPPER(:gender) AND u.uid.redate BETWEEN :startdate AND :enddate";
        TypedQuery<Users> query = em.createQuery(string,Users.class);
        query.setParameter("gender", gender);
        query.setParameter("startdate", start, TemporalType.DATE);
        query.setParameter("enddate", end, TemporalType.DATE);
        return query.getResultList();

    }
    
//attribute:  firstname
    @GET
    @Path("findByFistname/{firstname}")
    @Produces({"application/json"})
    public List<Users> findByFistname(@PathParam("firstname") String firstname){
        Query query = em.createNamedQuery("Users.findByFistname");
        query.setParameter("firstname", firstname);
        return query.getResultList();
    }
//attribute:  surname
    @GET
    @Path("findBySurname/{surname}")
    @Produces({"application/json"})
    public List<Users> findBySurname(@PathParam("surname") String surname){
        Query query = em.createNamedQuery("Users.findBySurname");
        query.setParameter("surname", surname);
        return query.getResultList();
    }
//attribute:  dob
    @GET
    @Path("findByBOD/{dob}")
    @Produces({"application/json"})
    public List<Users> findByBOD(@PathParam("dob") String dob) throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat ("yyyy-MM-dd");
        Date birth = format.parse(dob);
        Query query = em.createNamedQuery("Users.findByBOD");
        query.setParameter("dob", birth,TemporalType.DATE);
        return query.getResultList();
    }
//attribute:  height
    @GET
    @Path("findByHeight/{height}")
    @Produces({"application/json"})
    public List<Users> findByHeight(@PathParam("height") short height) {
        Query query = em.createNamedQuery("Users.findByHeight");
        query.setParameter("height", height);
        return query.getResultList();
    }
//attribute:  weight
    @GET
    @Path("findByWeight/{weight}")
    @Produces({"application/json"})
    public List<Users> findByWeight(@PathParam("weight") short weight) {
        Query query = em.createNamedQuery("Users.findByWeight");
        query.setParameter("weight", weight);
        return query.getResultList();
    }
//attribute:  gender
    @GET
    @Path("findByGender/{gender}")
    @Produces({"application/json"})
    public List<Users> findByGender(@PathParam("gender") String gender) {
        Query query = em.createNamedQuery("Users.findByGender");
        query.setParameter("gender", gender);
        return query.getResultList();
    }
//attribute:  occupation
    @GET
    @Path("findByOccupation/{occupation}")
    @Produces({"application/json"})
    public List<Users> findByOccupation(@PathParam("occupation") String occupation) {
        Query query = em.createNamedQuery("Users.findByOccupation");
        query.setParameter("occupation", occupation);
        return query.getResultList();
    }
//attribute:  address
    @GET
    @Path("findByAddress/{address}")
    @Produces({"application/json"})
    public List<Users> findByAddress(@PathParam("address") String address) {
        Query query = em.createNamedQuery("Users.findByAddress");
        query.setParameter("address", address);
        return query.getResultList();
    }
    
//validate user
    @GET
    @Path("valiUser/{username}/{pass}/{isLocal}")
    @Produces({"application/json"})
    public String valifyUser(@PathParam("username") String username,@PathParam("pass") String pass,@PathParam("isLocal") String isLocal) {
        boolean isMatch = false;
        int userid = 0;
        JSONObject obj = new JSONObject();
        try{
        String string = "select new healthman.Users(u.uid,u.firstname,u.address,u.suburb,u.states,r.password,r.redate,r.retime) from Users u, Registration r where u.uid=r.uid and r.username=:username";
        TypedQuery<Users> query = em.createQuery(string, Users.class);
        query.setParameter("username", username);
        List<Users> result = query.getResultList();
        System.out.println(result.size());
        if(result.size()==0){
            obj.put("result", "unvalid");
            System.out.println(obj.toString());
        }
        else{
            Users us = result.get(0);
            String getpass = us.getPassword();
            userid = us.getUid();
            String add = us.getAddress();
            String sub = us.getSuburb();
            String sta = us.getStates();
            String fname = us.getFirstname();
            Date redate = us.getRegdate();
            Date retime = us.getRegtime();
            SimpleDateFormat formatDay = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat formatTime = new SimpleDateFormat("hh:mm:ss");
            String date = formatDay.format(redate);
            String time = formatTime.format(retime);
            if(getpass.equals(pass)){
                isMatch = true;
            }
            
            if (isMatch == false){
                obj.put("result", "unvalid");
                }
            else{
                if(isLocal.equals("true")){
                    obj.put("result", "valid");
                }
                else{
                    JSONObject loc = papi.getGeocode(add, sub, sta);
                    
                    double lng = loc.getDouble("lng");
                    double lat = loc.getDouble("lat");
                    obj.put("result", "valid");
                    obj.put("uid", userid);
                    obj.put("lng", lng);
                    obj.put("lat", lat);
                    obj.put("add", add);
                    obj.put("fname", fname);
                    obj.put("date", date);
                    obj.put("time", time);
                    System.out.println(obj);
                }
            
            }
        }
        }catch(Exception e){}
        return obj.toString();
    }
    
    @GET
    @Path("test/{username}")
    @Produces({"application/json"})
    public List<Users> test(@PathParam("username") String username){
        
        String string = "select new healthman.Users(u.uid,u.address,u.suburb,u.states,r.password) from Users u, Registration r where u.uid=r.uid and r.username=:username";
        TypedQuery<Users> query = em.createQuery(string, Users.class);
        query.setParameter("username", username);
        Users u=new Users(200);
        u.setDob(new Date());
        u.setFirstname("ali");
        u.setSurname("qwe");
        em.persist(u);
        em.flush();     
        return query.getResultList();
        
    }
    
    @POST
    //@Transactional
    @Path("createUser")
    @Consumes({"application/json"})
    public Response createUser(String string) {
        System.out.println(string);
        int i =0;
        JSONObject resp = new JSONObject();
        try{
            JSONObject request= new JSONObject(string);
            String fname="";
            if(request.has("fname"))
            {
            fname = request.getString("fname");
            }
            String lname = request.getString("lname");
            String gender = request.getString("gender");
            String dob = request.getString("dob");
            Integer height = request.getInt("height");
            Integer weight = request.getInt("weight");
            //Integer height = Integer.parseInt(reheight);
            //Integer weight = Integer.parseInt(reweight);
            String occupation = request.getString("occupation");
            String address = request.getString("address");
            String suburb = request.getString("suburb");
            String state = request.getString("state");
            SimpleDateFormat dateformat = new SimpleDateFormat ("yyyy-MM-dd");
            Date bdate = dateformat.parse(dob);
            short hei = height.shortValue();
            short wei = weight.shortValue();
            i = super.getID("user");
            Users users = new Users(i);
            users.setFirstname(fname);
            users.setSurname(lname);
            users.setDob(bdate);
            users.setGender(gender);
            users.setHeight(hei);
            users.setWeight(wei);
            users.setOccupation(occupation);
            users.setAddress(address);
            users.setSuburb(suburb);
            users.setStates(state);
        
            em.persist(users);
            //super.create(users);
            em.flush();
        resp.put("uid", i);
        }catch(Exception e){
        System.out.println(e);
        }
        String s = resp.toString();
        return Response.ok(s,MediaType.APPLICATION_JSON).build();
    }
    
    
}
