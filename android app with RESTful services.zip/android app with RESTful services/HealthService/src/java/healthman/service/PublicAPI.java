/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman.service;

import org.json.JSONArray;
import org.json.JSONObject;
import org.netbeans.saas.RestConnection;
import org.netbeans.saas.RestResponse;

/**
 *
 * @author juan
 */
public class PublicAPI {
    PublicAPI(){
    }
    public static void main(String[] args) {
        PublicAPI pb = new PublicAPI();
        pb.getGeocode("30 Atherton Rd", "Oakleigh ", "vic");
        //pb.getWeather("37.4224497", "-122.0840329");
    }
    public JSONObject getWeather(double lat, double lng){
        final String API_key = "58694f9b466c1fa61b9fdc7f9de1801a";
        int lattitude = (int)lat;
        int longitude = (int)lng;
        String strResponse="";
        RestConnection conn = new RestConnection ("http://api.openweathermap.org/data/2.5/weather?lat="+lattitude+"&lon="+longitude+"&units=metric&APPID="+API_key);
        JSONObject result = new JSONObject();
        try{
            RestResponse response = conn.get();
            strResponse  =response.getDataAsString();
            JSONObject jsonRes = new JSONObject(strResponse);
            JSONObject main = new JSONObject();
            JSONObject windRes = new JSONObject();
            main = jsonRes.getJSONObject("main");
            windRes = jsonRes.getJSONObject("wind");
            int temp = (int)main.getDouble("temp");
            int pres = main.getInt("pressure");
            int hum = main.getInt("humidity");
            double humidity = (double)hum/100;
            double wind = windRes.getDouble("speed");
            int wspeed = (int)(wind * 3.6);
            result.put("temp", temp);
            result.put("pressure", pres);
            result.put("humidity", humidity);
            result.put("windspeed", wspeed);
        System.out.println(result);

        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        return result;
    }
    
    public JSONObject getGeocode(String add, String suburb, String state){
        add = add.replace(" ", "+");
        suburb = suburb.replace(" ", "+");
        String strResponse="";
        double lng = 0;
        double lat = 0;
        RestConnection conn = new RestConnection ("https://maps.googleapis.com/maps/api/geocode/json?address="+ add + "," + suburb + "+" + state);
        JSONObject loc = new JSONObject();
        try{
            RestResponse response = conn.get();
            strResponse  =response.getDataAsString();
            JSONObject jsonRes = new JSONObject(strResponse);
            JSONArray meta = new JSONArray();
            meta = jsonRes.getJSONArray("results");
            JSONObject result = new JSONObject();
            result = meta.getJSONObject(0);
            JSONObject geo = new JSONObject();
            geo = result.getJSONObject("geometry");
            loc = geo.getJSONObject("location");
                    lng = loc.getDouble("lng");
                    lat = loc.getDouble("lat");
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        System.out.println(loc + " " + lng +" " + lat);
        return loc;
    }
}
