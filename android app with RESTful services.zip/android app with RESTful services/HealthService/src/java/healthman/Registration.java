/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author juan
 */
@Entity
@Table(name = "REGISTRATION")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Registration.findAll", query = "SELECT r FROM Registration r"),
    @NamedQuery(name = "Registration.findByUid", query = "SELECT r FROM Registration r WHERE r.uid = :uid"),
    @NamedQuery(name = "Registration.findByUsername", query = "SELECT r FROM Registration r WHERE r.username = :username"),
    @NamedQuery(name = "Registration.findByPassword", query = "SELECT r FROM Registration r WHERE r.password = :password"),
    @NamedQuery(name = "Registration.findByRedate", query = "SELECT r FROM Registration r WHERE r.redate = :redate"),
    @NamedQuery(name = "Registration.findByRetime", query = "SELECT r FROM Registration r WHERE r.retime = :retime"),
    //@NamedQuery(name = "Registration.findUserByReg", query = "SELECT ")
})

    
public class Registration implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "UID")
    private Integer uid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "USERNAME")
    private String username;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 150)
    @Column(name = "PASSWORD")
    private String password;
    @Column(name = "REDATE")
    @Temporal(TemporalType.DATE)
    private Date redate;
    @Column(name = "RETIME")
    @Temporal(TemporalType.TIME)
    private Date retime;
    @JoinColumn(name = "DID", referencedColumnName = "DID")
    @ManyToOne
    private Doctor did;
    @JoinColumn(name = "UID", referencedColumnName = "UID", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Users users;

    public Registration() {
    }

    public Registration(Integer uid) {
        this.uid = uid;
    }

    public Registration(Integer uid, String username, String password) {
        this.uid = uid;
        this.username = username;
        this.password = password;
    }
    
    public Registration(Integer uid, String password) {
        this.uid = uid;
        this.password = password;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Date getRedate() {
        return redate;
    }

    public void setRedate(Date redate) {
        this.redate = redate;
    }

    public Date getRetime() {
        return retime;
    }

    public void setRetime(Date retime) {
        this.retime = retime;
    }

    public Doctor getDid() {
        return did;
    }

    public void setDid(Doctor did) {
        this.did = did;
    }
    
   
    @XmlTransient //only return the filed not the whole objectx
    public Users getUsers() {
        return users;
    }

    public void setUsers(Users users) {
        this.users = users;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uid != null ? uid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Registration)) {
            return false;
        }
        Registration other = (Registration) object;
        if ((this.uid == null && other.uid != null) || (this.uid != null && !this.uid.equals(other.uid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "healthman.Registration[ uid=" + uid + " ]";
    }
    
    
}
