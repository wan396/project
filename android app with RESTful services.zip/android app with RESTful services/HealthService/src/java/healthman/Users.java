/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author juan
 */
@Entity
@Table(name = "USERS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Users.findAll", query = "SELECT u FROM Users u"),
    @NamedQuery(name = "Users.findByUid", query = "SELECT u FROM Users u WHERE u.uid = :uid"),
    /*@NamedQuery(name = "Users.findByFirstname", query = "SELECT u FROM Users u WHERE u.firstname = :firstname"),
    @NamedQuery(name = "Users.findBySurname", query = "SELECT u FROM Users u WHERE u.surname = :surname"),
    @NamedQuery(name = "Users.findByDob", query = "SELECT u FROM Users u WHERE u.dob = :dob"),
    @NamedQuery(name = "Users.findByHeight", query = "SELECT u FROM Users u WHERE u.height = :height"),
    @NamedQuery(name = "Users.findByWeight", query = "SELECT u FROM Users u WHERE u.weight = :weight"),
    @NamedQuery(name = "Users.findByGender", query = "SELECT u FROM Users u WHERE u.gender = :gender"),
    @NamedQuery(name = "Users.findByOccupation", query = "SELECT u FROM Users u WHERE u.occupation = :occupation"),
    @NamedQuery(name = "Users.findByAddress", query = "SELECT u FROM Users u WHERE u.address = :address"),*/
//attribute:  firstname
    @NamedQuery(name = "Users.findByFistname", query = "SELECT u FROM Users u WHERE u.firstname = :firstname"),
//attribute:  surname
    @NamedQuery(name = "Users.findBySurname", query = "SELECT u FROM Users u WHERE u.surname = :surname"),
//attribute:  dob
    @NamedQuery(name = "Users.findByBOD", query = "SELECT u FROM Users u WHERE u.dob = :dob"),
//attribute:  height
    @NamedQuery(name = "Users.findByHeight", query = "SELECT u FROM Users u WHERE u.height = :height"),
//attribute:  weight
    @NamedQuery(name = "Users.findByWeight", query = "SELECT u FROM Users u WHERE u.weight = :weight"),
//attribute:  gender
    @NamedQuery(name = "Users.findByGender", query = "SELECT u FROM Users u WHERE UPPER(u.gender) = UPPER(:gender)"),
//attribute:  occupation
    @NamedQuery(name = "Users.findByOccupation", query = "SELECT u FROM Users u WHERE u.occupation = :occupation"),
//attribute:  address
    @NamedQuery(name = "Users.findByAddress", query = "SELECT u FROM Users u WHERE u.address = :address")

})
public class Users implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "UID")
    private Integer uid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "FIRSTNAME")
    private String firstname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "SURNAME")
    private String surname;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DOB")
    @Temporal(TemporalType.DATE)
    private Date dob;
    @Column(name = "HEIGHT")
    private Short height;
    @Column(name = "WEIGHT")
    private Short weight;
    @Column(name = "GENDER")
    @Size(min = 1, max = 1)
    private String gender;
    @Size(max = 15)
    @Column(name = "OCCUPATION")
    private String occupation;
    @Size(max = 50)
    @Column(name = "ADDRESS")
    private String address;
    @Size(max = 50)
    @Column(name = "SUBURB")
    private String suburb;
    @Size(max = 5)
    @Column(name = "STATES")
    private String states;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "users")
    private Collection<Record> recordCollection;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "users")
    private Registration registration;
    @Transient private String password;
    @Transient private Date regdate;
    @Transient private Date regtime;
    
    public Users() {
    }

    public Users(Integer uid, String firstname, String address, String suburb, String states, String password, Date regdate, Date regtime) {
        this.uid = uid;
        this.firstname = firstname;
        this.address = address;
        this.suburb = suburb;
        this.states = states;
        this.password = password;
        this.regdate = regdate;
        this.regtime = regtime;
    }

    public void setStates(String states) {
        this.states = states;
    }

    public void setRegdate(Date regdate) {
        this.regdate = regdate;
    }

    public void setRegtime(Date regtime) {
        this.regtime = regtime;
    }

    public Date getRegdate() {
        return regdate;
    }

    public Date getRegtime() {
        return regtime;
    }

    public Users(Integer uid) {
        this.uid = uid;
    }

    public Users(Integer uid, String firstname, String surname, Date dob) {
        this.uid = uid;
        this.firstname = firstname;
        this.surname = surname;
        this.dob = dob;
    }

    public Users(Integer uid, String firstname, String surname, Date dob, Short height, Short weight, String gender, String occupation, String address, String suburb, String states) {
        this.uid = uid;
        this.firstname = firstname;
        this.surname = surname;
        this.dob = dob;
        this.height = height;
        this.weight = weight;
        this.gender = gender;
        this.occupation = occupation;
        this.address = address;
        this.suburb = suburb;
        this.states = states;
    }

    public Users(Integer uid, String address, String suburb, String states, String password) {
        this.uid = uid;
        this.address = address;
        this.suburb = suburb;
        this.states = states;
        this.password = password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setStateS(String states) {
        this.states = states;
    }

    public String getStates() {
        return states;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public Short getHeight() {
        return height;
    }

    public void setHeight(Short height) {
        this.height = height;
    }

    public Short getWeight() {
        return weight;
    }

    public void setWeight(Short weight) {
        this.weight = weight;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getSuburb() {
        return suburb;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @XmlTransient
    public Collection<Record> getRecordCollection() {
        return recordCollection;
    }

    public void setRecordCollection(Collection<Record> recordCollection) {
        this.recordCollection = recordCollection;
    }

    @XmlTransient
    public Registration getRegistration() {
        return registration;
    }

    public void setRegistration(Registration registration) {
        this.registration = registration;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uid != null ? uid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Users)) {
            return false;
        }
        Users other = (Users) object;
        if ((this.uid == null && other.uid != null) || (this.uid != null && !this.uid.equals(other.uid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "healthman.Users[ uid=" + uid + " ]";
    }
    
}
