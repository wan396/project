/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 *
 * @author juan
 */
@Embeddable
public class RecordPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "UID")
    private int uid;
    @Basic(optional = false)
    @NotNull
    @Column(name = "RECORDDATE")
    @Temporal(TemporalType.DATE)
    private Date recorddate;
    @Basic(optional = false)
    @NotNull
    @Column(name = "RECORDTIME")
    @Temporal(TemporalType.TIME)
    private Date recordtime;

    public RecordPK() {
    }

    public RecordPK(int uid, Date recorddate, Date recordtime) {
        this.uid = uid;
        this.recorddate = recorddate;
        this.recordtime = recordtime;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public Date getRecorddate() {
        return recorddate;
    }

    public void setRecorddate(Date recorddate) {
        this.recorddate = recorddate;
    }

    public Date getRecordtime() {
        return recordtime;
    }

    public void setRecordtime(Date recordtime) {
        this.recordtime = recordtime;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) uid;
        hash += (recorddate != null ? recorddate.hashCode() : 0);
        hash += (recordtime != null ? recordtime.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RecordPK)) {
            return false;
        }
        RecordPK other = (RecordPK) object;
        if (this.uid != other.uid) {
            return false;
        }
        if ((this.recorddate == null && other.recorddate != null) || (this.recorddate != null && !this.recorddate.equals(other.recorddate))) {
            return false;
        }
        if ((this.recordtime == null && other.recordtime != null) || (this.recordtime != null && !this.recordtime.equals(other.recordtime))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "healthman.RecordPK[ uid=" + uid + ", recorddate=" + recorddate + ", recordtime=" + recordtime + " ]";
    }
    
}
