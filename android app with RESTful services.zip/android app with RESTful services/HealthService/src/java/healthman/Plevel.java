/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthman;

import java.math.BigDecimal;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author juan
 */
@XmlRootElement
public class Plevel {
    private short painlevel;
    private short weather;
    private BigDecimal humidity;
    private Date recorddate;


public Plevel(){
    
}   

public Plevel(short painl,short wea,Date redate){
    this.painlevel = painl;
    this.weather = wea;
    this.recorddate = redate;
}
public Plevel(short painl, BigDecimal hum,Date redate){
    this.painlevel = painl;
    this.humidity = hum;
    this.recorddate = redate;
}

    public void setRecorddate(Date recorddate) {
        this.recorddate = recorddate;
    }


    public short getPainlevel() {
        return painlevel;
    }

    public Date getRecorddate() {
        return recorddate;
    }

        public BigDecimal getHumidity() {
        return humidity;
    }

    public void setPainlevel(short painlevel) {
        this.painlevel = painlevel;
    }

    public void setWeather(short weather) {
        this.weather = weather;
    }

    public short getWeather() {
        return weather;
    }
    
    public void setHumidity(BigDecimal humidity) {
        this.humidity = humidity;
    }

}
