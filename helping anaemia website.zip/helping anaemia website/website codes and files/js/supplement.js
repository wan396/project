/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(function () {
    $("div[name='displayResultChart']").css("display", "none");
    $('#ageSelect').change(function () {

        var age = $("#ageSelect").val();

        $("input[name='age']").attr("value", age);
        $("div[name='displayResultChart']").css("display", "none");

    })
    $('#genderSelect').change(function () {
        var gender = $("#genderSelect").val();

        $("input[name='gender']").attr("value", gender);
        $("div[name='displayResultChart']").css("display", "none");

    })

    $('#foodTypeSelect').change(function () {
        $('#foodPreviousPage').hide();
        $('#foodNextPage').hide();
        var foodTable = document.getElementById("displayFoodTable");
        foodTable.innerHTML = "";
        $("input[name='foodCurrentPage']").attr("value", 1);
        $("input[name='foodMaxPage']").attr("value", 1);
        $("div[name='displayResultChart']").css("display", "none");
        getFoodSubType();

    })

    $('#foodSubTypeSelect').change(function () {
        $('#foodPreviousPage').hide();
        $('#foodNextPage').hide();
        var foodTable = document.getElementById("displayFoodTable");
        foodTable.innerHTML = "";
        $("input[name='foodCurrentPage']").attr("value", 1);
        $("input[name='foodMaxPage']").attr("value", 1);
        $("div[name='displayResultChart']").css("display", "none");

    })

    $('#supplementBrandSelect').change(function () {
        $('#supplementPreviousPage').hide();
        $('#supplementNextPage').hide();
        var supplementTable = document.getElementById("displaySupplementTable");
        supplementTable.innerHTML = "";
        $("input[name='supplementCurrentPage']").attr("value", 1);
        $("input[name='supplementMaxPage']").attr("value", 1);
        $("div[name='displayResultChart']").css("display", "none");
    })
    /*select tab*/
    $('#tabFood').addClass('active');
    $('#content .tabs li').on('click', function () {
        var panel = $(this).closest('#content');
        //determine which panel to show
        var panelToShow = $(this).attr('data-panel');
        //alert(panelToShow);
        //hide active li
        panel.find('.tabs li.active').removeClass('active');
        //hide current panel
        panel.find('.panel.active').removeClass('active');
        //add active to selected li
        $(this).addClass('active');
        //show new panel
        $('#' + panelToShow).addClass('active');
    });

    initilizeAgeSelOptions();
    $('#foodPreviousPage').hide();
    $('#supplementPreviousPage').hide();
    $('#foodNextPage').hide();
    $('#supplementNextPage').hide();

});

function initilizeAgeSelOptions() {

    var age = $('#ageInput').val();
    var gender = $('#genderInput').val();
    if (age === null) {
        age = "";
    }
    if (gender === null) {
        gender = "";
    }
    xmlhttprequest.open("POST", "getSearchConditions.action", false);

    xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

    xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');

    var paras = "period=" + age
            + "&gender=" + gender;
    xmlhttprequest.send(paras);
    var rtnStr = xmlhttprequest.responseText;
    var jsonArr = eval("(" + rtnStr + ")");
    var ages = jsonArr[0].value;
    var sel1 = document.getElementById("ageSelect");
    if (ages === null
            || ages === '') {

    } else {
        sel1.innerHTML = "";
        if (age === null
                || age === '') {
            sel1.innerHTML += "<option value=''><--select--></option>";
        }

        var agesArray = ages.split("#");
        for (var i = 0; i < agesArray.length; i++) {
            var ageArr = agesArray[i].split("@");
            sel1.innerHTML += "<option value='" + ageArr[0] + "'>" + ageArr[1] + "</option>";
        }
    }

}


function getSearchFood(pageNum, pageContentNum) {
    var foodName = $('#foodNameInput').val();
    var foodType = $('#foodTypeSelect').val();
    var foodSubType = $('#foodSubTypeSelect').val();
    if (foodName === null) {
        foodName = "";
    }
    if (foodType === null) {
        foodType = "";
    }
    if (foodSubType === null) {
        foodSubType = "";
    }
    xmlhttprequest.open("POST", "searchFood.action", false);

    xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

    xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');

    var paras = "foodType=" + foodType
            + "&foodSubType=" + foodSubType
            + "&foodName=" + foodName
            + "&pageNum=" + pageNum
            + "&pageContentNum=" + pageContentNum;
    xmlhttprequest.send(paras);
    var jsonStr = xmlhttprequest.responseText;
    var foodTable = document.getElementById("displayFoodTable");
    foodTable.innerHTML = "";

    var jsonArr = eval("(" + jsonStr + ")");
    if (jsonArr.length > 1) {
        foodTable.innerHTML += "<tr><td>Name</td><td>Iron(mg/100g)</td><td>Vitamin C(mg/100g)</td><td>Image</td></tr>";
        $('#foodPreviousPage').show();
        $('#foodNextPage').show();
    } else {
        foodTable.innerHTML += "No records found!";
        $('#foodPreviousPage').hide();
        $('#foodNextPage').hide();
    }
    for (var i = 0; i < jsonArr.length - 1; i++) {
        // var combox = "<input id='foodCb" + i + "' type='checkbox'>";
        var imageUrl = jsonArr[i].image.substring(1);
        var image = "<img style=' height: 50px; width: 50px' id='foodImage" + i + "' src='" + imageUrl + "' />";
        foodTable.innerHTML += "<tr><td>" + jsonArr[i].name + "</td><td>" + jsonArr[i].iron + "mg</td><td>" + jsonArr[i].vitamin_c + "mg</td><td>" + image + "</td>"
                + "</tr>";
    }
    var pageObj = jsonArr[jsonArr.length - 1 ];
    //alert(pageObj.name + "," + pageObj.iron + "," + pageObj.vitamin_c);
    var maxPageNum = pageObj.vitamin_c;
    if (maxPageNum <= 1) {
        $('#foodPreviousPage').hide();
        $('#foodNextPage').hide();
    }
    $("input[name='foodMaxPage']").attr("value", maxPageNum);

    $('#displayFoodTable tr').hover(function () {
        $(this).children('td').css('background-color', '#ffc');
    }, function () {
        $(this).children('td').css('background-color', '#fff');
    });

    $("#displayFoodTable tr").dblclick(function () {
        var pickedRecordTable = document.getElementById("pickedRecordTable");
        if (pickedRecordTable.innerHTML === null
                || pickedRecordTable.innerHTML === '') {
            pickedRecordTable.innerHTML += "<tr>"
                    + "<td>Name</td>"
                    + "<td>Iron(mg/ 100g)</td>"
                    + "<td>Vitamin C(mg/ 100g)</td>"
                    + "<td>Quantity(unit:100g)</td>"
                    + "</tr>";
        }
        var isPicked = false;
        var foodName;
        var lengthRows = pickedRecordTable.rows.length;
        var me = $(this),
                tds = me.find("td");
        var j = 0;
        var row = "";
        row += "<tr>";
        tds.each(function (i, dom) {
            if (j > 2) {

            } else {
                if( j === 0){
                    foodName = $(this).text();
                }
                row += "<td>" + $(this).text() + "</td>";
            }
            j = j + 1;
        });
        var quantityInputId = "pickedItemQuantity" + lengthRows;
        lengthRows = lengthRows + 1;
        var input = "<input" + " id='" + quantityInputId + "' type='number' class='form-control' style='width:65px' value='1' min='1' max='99' step='1'>";
        row += " <td>" + input + "</td>";
        row += "</tr>";
        isPicked = pickedAlready(foodName);
        if(isPicked){
            
        }else{
             pickedRecordTable.innerHTML += row;
        }


    });

}

/*function pickFood() {
 var selected = false;
 $("#displayFoodTable tr:gt(0)").each(function (i) {
 
 var comboxId = "foodCb" + i;
 
 var checked = document.getElementById(comboxId).checked;
 if (checked) {
 selected = true;
 }
 });
 
 if (selected) {
 var pickedRecordTable = document.getElementById("pickedRecordTable");
 if (pickedRecordTable.innerHTML === null
 || pickedRecordTable.innerHTML === '') {
 pickedRecordTable.innerHTML += "<tr>"
 + "<td>Name</td>"
 + "<td>Iron(mg/ 100g)</td>"
 + "<td>Vitamin C(mg/ 100g)</td>"
 + "<td>Quantity(unit:100g)</td>"
 + "</tr>";
 }
 var pickedTable = document.getElementById("pickedRecordTable");
 var lengthRows = pickedTable.rows.length;
 $("#displayFoodTable tr:gt(0)").each(function (i) {
 var comboxId = "foodCb" + i;
 var checked = document.getElementById(comboxId).checked;
 if (checked) {
 var j = 0;
 var row = "";
 row += "<tr>"
 $(this).children("td").each(function (i) {
 
 if (j > 2) {
 
 } else {
 
 row += "<td>" + $(this).text() + "</td>";
 }
 j = j + 1;
 });
 var quantityInputId = "pickedItemQuantity" + lengthRows;
 lengthRows = lengthRows + 1;
 var input = "<input" + " id='" + quantityInputId + "' type='number' class='form-control' style='width:65px' value='1' min='1' max='99' step='1'>";
 row += " <td>" + input + "</td>";
 row += "</tr>";
 pickedRecordTable.innerHTML += row;
 }
 });
 } else {
 alert("You have not slected any record!");
 }
 }
 
 */

function getSearchSupplement(pageNum, pageContentNum) {

    var supplementName = $('#supplementNameInput').val();
    var supplementBrand = $('#supplementBrandSelect').val();
    if (supplementName === null) {
        supplementName = "";
    }
    if (supplementBrand === null) {
        supplementBrand = "";
    }
    xmlhttprequest.open("POST", "searchSupplement.action", false);
    xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');
    var paras = "name=" + supplementName
            + "&brand=" + supplementBrand
            + "&pageNum=" + pageNum
            + "&pageContentNum=" + pageContentNum;
    xmlhttprequest.send(paras);
    var jsonStr = xmlhttprequest.responseText;
    ;
    var supplementTable = document.getElementById("displaySupplementTable");
    supplementTable.innerHTML = "";
    var jsonArr = eval("(" + jsonStr + ")");
    if (jsonArr.length > 1) {
        supplementTable.innerHTML += "<tr><td>Name</td><td>Brand</td><td>Iron(mg/100g)</td><td>Vitamin C(mg/100g)</td></tr>";
        $('#supplementPreviousPage').show();
        $('#supplementNextPage').show();
    } else {
        supplementTable.innerHTML += "No records found!";
        $('#supplementPreviousPage').hide();
        $('#supplementNextPage').hide();
    }
    for (var i = 0; i < jsonArr.length - 1; i++) {
        //var combox = "<input id='supplementCb" + i + "' type='checkbox'>";
        supplementTable.innerHTML += "<tr><td>" + jsonArr[i].name + "</td><td>" + jsonArr[i].brand + "</td><td>" + jsonArr[i].iron + "mg</td><td>" + jsonArr[i].vitamin_c + "mg</td>"
                + "</tr>";
    }

    var pageObj = jsonArr[jsonArr.length - 1 ];
    //alert(pageObj.name + "," + pageObj.iron + "," + pageObj.vitamin_c);
    var maxPageNum = pageObj.vitamin_c;
    if (maxPageNum <= 1) {
        $('#foodPreviousPage').hide();
        $('#foodNextPage').hide();
    }
    $("input[name='supplementMaxPage']").attr("value", maxPageNum);
    $('#displaySupplementTable tr').hover(function () {
        $(this).children('td').css('background-color', '#ffc');
    }, function () {
        $(this).children('td').css('background-color', '#fff');
    });
    $("#displaySupplementTable tr").dblclick(function () {
        var pickedRecordTable = document.getElementById("pickedRecordTable");
        if (pickedRecordTable.innerHTML === null
                || pickedRecordTable.innerHTML === '') {
            pickedRecordTable.innerHTML += "<tr>"
                    + "<td>Name</td>"
                    + "<td>Iron(mg/ 100g)</td>"
                    + "<td>Vitamin C(mg/ 100g)</td>"
                    + "<td>Quantity(unit:100g)</td>"
                    + "</tr>";
        }
        var supplementName;
        var isPicked =false;
        var lengthRows = pickedRecordTable.rows.length;
        var me = $(this),
                tds = me.find("td");
        var j = 0;
        var row = "";
        row += "<tr>"
        tds.each(function (i, dom) {
            
            if (j === 1
                    || j > 3) {

            } else {
                if(j === 0 ){
                    supplementName = $(this).text();
                }
                row += "<td>" + $(this).text() + "</td>";
            }
            j = j + 1;
        });
        var quantityInputId = "pickedItemQuantity" + lengthRows;
        lengthRows = lengthRows + 1;
        var input = "<input" + " id='" + quantityInputId + "' type='number' class='form-control' style='width:65px' value='1' min='1' max='99' step='1'>";
        row += " <td>" + input + "</td>";
        row += "</tr>";
        isPicked = pickedAlready(supplementName);
        if(isPicked){
            
        }else{
             pickedRecordTable.innerHTML += row;
        }
    });
}

/*
 function pickSupplement() {
 var selected = false;
 $("#displaySupplementTable tr:gt(0)").each(function (i) {
 
 
 //alert("这是第"+i+"行内容"); 
 var comboxId = "supplementCb" + i;
 var checked = document.getElementById(comboxId).checked;
 if (checked) {
 selected = true;
 }
 });
 if (selected) {
 var pickedRecordTable = document.getElementById("pickedRecordTable");
 if (pickedRecordTable.innerHTML === null
 || pickedRecordTable.innerHTML === '') {
 pickedRecordTable.innerHTML += "<tr>"
 + "<td>Name</td>"
 + "<td>Iron(mg/ 100g)</td>"
 + "<td>Vitamin C(mg/ 100g)</td>"
 + "<td>Quantity(unit:100g)</td>"
 + "</tr>";
 }
 var pickedTable = document.getElementById("pickedRecordTable");
 var lengthRows = pickedTable.rows.length;
 $("#displaySupplementTable tr:gt(0)").each(function (i) {
 //alert("Tis is No."+i+" row content!"); 
 var comboxId = "supplementCb" + i;
 var checked = document.getElementById(comboxId).checked;
 if (checked) {
 var j = 0;
 var row = "";
 row += "<tr>"
 $(this).children("td").each(function (i) {
 
 if (j === 1
 || j > 3) {
 
 } else {
 //alert("This is No." + i + "td content：" + $(this).text());
 row += "<td>" + $(this).text() + "</td>";
 }
 j = j + 1;
 });
 var quantityInputId = "pickedItemQuantity" + lengthRows;
 lengthRows = lengthRows + 1;
 var input = "<input" + " id='" + quantityInputId + "' type='number' class='form-control' style='width:65px' value='1' min='1' max='99' step='1'>";
 row += " <td>" + input + "</td>";
 row += "</tr>";
 pickedRecordTable.innerHTML += row;
 }
 });
 } else {
 alert("You have not slected any record!");
 }
 }
 */
function analysis() {
    var pickedTable = document.getElementById("pickedRecordTable");
    var lengthRows = pickedTable.rows.length;
    if (lengthRows <= 1) {
        alert("Yuu haven't choose any food or supplement record!");
        return;
    }
    var age = $('#ageSelect').val();
    var gender = $('#genderSelect').val();
    if (age === null
            || age === ''
            || gender === null
            || gender === '') {
        alert("Please select the Age and Gender!");
    } else {
        xmlhttprequest.open("POST", "calDailyIntake.action", false);
        xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');
        var paras = "gender=" + gender
                + "&age=" + age;
        xmlhttprequest.send(paras);
        var rtn = xmlhttprequest.responseText;
        var strs = new Array();
        if ("" === rtn) {
            alert("no records!");
        } else {
            strs = rtn.split(",");
        }
        var ironMin = strs[1];
        var ironMax = strs[0];
        var vcMin = strs[3];
        var vcMax = strs[2];
        var iron = 0.0;
        var vc = 0.0;
        $("#pickedRecordTable tr:gt(0)").each(function (i) {
            var rowQuantityInputId = "pickedItemQuantity" + (i + 1);
            // alert(rowQuantityInputId);
            //alert($('#' +rowQuantityInputId).val());
            var ironRow = 0.0;
            var vcRow = 0.0;
            var quantity = $('#' + rowQuantityInputId).val();
            $(this).children("td").each(function (i) {
                if (i === 1) {
                    ironRow = parseFloat($(this).text());
                }
                if (i === 2) {
                    vcRow = parseFloat($(this).text());
                }

            });
            // alert(ironRow + "," + vcRow + "," + quantity);
            iron = iron + (ironRow * quantity);
            vc = vc + (vcRow * quantity);
        });
         iron = parseFloat(iron).toFixed(2);
         vc = parseFloat(vc).toFixed(2);
        $("div[name='displayResultChart']").css("display", "block");
        /*alert(iron);
         alert(vc);
         alert(ironMin + "@" + ironMax + "@" + vcMin + "@" + vcMax);*/
        //$("rectIron1").attr("width",ironMax);
        // svg.selectAll("rectIron").attr("width",ironMax);
        var ironTakePercentage = (iron / ironMin).toFixed(2) * 100;
        var ironMaxPercentage = (iron / ironMax).toFixed(2) * 100;
        var vcTakePercentage = (vc / vcMin).toFixed(2) * 100;
        var vcMaxPercentage = (vc / vcMax).toFixed(2) * 100;
        $('#fillgauge1').html("");
        $('#fillgauge2').html("");
        $('#fillgauge3').html("");
        $('#fillgauge4').html("");
        /*var gauge1 = loadLiquidFillGauge("fillgauge1", ironTakePercentage);
         var gauge2 = loadLiquidFillGauge("fillgauge2", ironMaxPercentage);
         var gauge3 = loadLiquidFillGauge("fillgauge3", vcTakePercentage);
         var gauge4 = loadLiquidFillGauge("fillgauge4", vcMaxPercentage);*/
        var gauge1 = loadLiquidFillGauge("fillgauge1", ironTakePercentage);
        var config1 = liquidFillGaugeDefaultSettings();
        config1.circleColor = "#5D177F";
        config1.textColor = "#71177F";
        config1.waveTextColor = "#71177F";
        config1.waveColor = "#9C7CB0";
        config1.circleThickness = 0.15;
        config1.textVertPosition = 0.5;
        config1.waveAnimateTime = 1000;
        var gauge2 = loadLiquidFillGauge("fillgauge2", ironMaxPercentage, config1);
        var config2 = liquidFillGaugeDefaultSettings();
        config2.circleColor = "#FFC900";
        config2.circleThickness = 0.05;
        config2.circleFillGap = 0.05;
        config2.textColor = "#FFC900";
        config2.waveTextColor = "#FFC900";
        config2.waveColor = "#FFF1AD";
        var gauge3 = loadLiquidFillGauge("fillgauge3", vcTakePercentage, config2);
        var config3 = liquidFillGaugeDefaultSettings();
        config3.circleColor = "#FFC900";
        config3.textColor = "#FFC900";
        config3.waveTextColor = "#FFC900";
        config3.waveColor = "#FFF1AD";
        config3.circleThickness = 0.15;
        config3.textVertPosition = 0.5;
        config3.waveAnimateTime = 1000;
        var gauge4 = loadLiquidFillGauge("fillgauge4", vcMaxPercentage, config3);
        var config4 = liquidFillGaugeDefaultSettings();
        $('#actualIron').html(iron);
        $('#essentialIron').html(ironMin);
        $('#maxIron').html(ironMax);
        $('#actualVC').html(vc);
        $('#essentialVC').html(vcMin);
        $('#maxVC').html(vcMax);
        if (iron < ironMin) {
            $('#ironTips').html("Too low iron intake this might lead feeling weakness headaches, depression, sore tongue and sensitivity to cold");
        } else if (iron > ironMax) {
            $('#ironTips').html("Be careful taken large amount of iron or supplements that contain iron it might lead to Iron poisoning your body and Hereditary hemochromatosis");
        } else {
            $('#ironTips').html("Keep it in this level and don’t forget to check your daily intake with us");

        }

        if (vc < vcMin) {
            $('#vcTips').html("Too low vitamin c intake this might lead to weakness, muscle and joint pains and dry skin");
        } else if (vc > vcMax) {
            $('#vcTips').html("Taken large amount of Vitamin c will not harm your body it will simply be flushed out of your body in your urine");
        } else {
            $('#vcTips').html("Keep it in this level and don’t forget to check your daily intake with us");

        }

    }
}

function getFoodSubType() {
    var foodType = $('#foodTypeSelect').val();
    if (foodType === null
            || foodType === '') {
        foodType = "";
    }
    xmlhttprequest.open("POST", "getSubTypeList.action", false);
    xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');
    var paras = "foodType=" + foodType;
    xmlhttprequest.send(paras);
    var jsonstr = xmlhttprequest.responseText;
    var jsonArr = eval("(" + jsonstr + ")");
    var sel = document.getElementById("foodSubTypeSelect");
    // alert(jsonArr[0].period)
    sel.innerHTML = "";
    sel.innerHTML += "<option value=''><--select--></option>";
    for (var i = 0; i < jsonArr.length; i++) {
        sel.innerHTML += "<option value='" + jsonArr[i].value + "'>" + jsonArr[i].name + "</option>";
    }
}

function resetSearchCondition() {
//clear hidden input information
    $("input[name='age']").attr("value", "");
    $("input[name='gender']").attr("value", "");
    $("#ageSelect").val("");
    $("#genderSelect").val("");
    $("div[name='displayResultChart']").css("display", "none");
}

function clearPickedRecord() {
    var pickedTable = document.getElementById("pickedRecordTable");
    pickedTable.innerHTML = "";
    pickedTable.innerHTML += "<tr>"
            + "<td>Name</td>"
            + "<td>Iron(mg/ 100g)</td>"
            + "<td>Vitamin C(mg/ 100g)</td>"
            + "<td>Quantity(unit:100g)</td>"
            + "</tr>";
    //clear hidden input information
    $("input[name='age']").attr("value", "");
    $("input[name='gender']").attr("value", "");
    $("#ageSelect").val("");
    $("#genderSelect").val("");
    $("div[name='displayResultChart']").css("display", "none");
}

function foodPreviousPage() {
    var currentPageNum = $('#foodCurrentPageInput').val();
    //var maxPageNum = $('#foodMaxPageInput').val();
    /*alert(currentPageNum);
     alert(maxPageNum);*/
    if (currentPageNum === '1') {
        alert("It is already the 1st page!");
    } else {
        var newCurrentPageNum = currentPageNum - 1;
        $("input[name='foodCurrentPage']").attr("value", newCurrentPageNum);
        getSearchFood(newCurrentPageNum, 10);
    }
}

function foodNextPage() {
    var currentPageNum = $('#foodCurrentPageInput').val();
    var maxPageNum = $('#foodMaxPageInput').val();
    // alert(currentPageNum);
    //alert(maxPageNum);
    if (currentPageNum === maxPageNum) {
        alert("It is already the last page!");
    } else {

        var newCurrentPageNum = parseInt(currentPageNum) + 1;
        // alert(newCurrentPageNum);
        $("input[name='foodCurrentPage']").attr("value", newCurrentPageNum);
        getSearchFood(newCurrentPageNum, 10);
    }
}


function supplementPreviousPage() {
    var currentPageNum = $('#supplementCurrentPageInput').val();
    // alert(currentPageNum);
    if (currentPageNum === '1') {
        alert("It is already the 1st page!");
    } else {
        var newCurrentPageNum = currentPageNum - 1;
        // alert(newCurrentPageNum);
        $("input[name='supplementCurrentPage']").attr("value", newCurrentPageNum);
        getSearchSupplement(newCurrentPageNum, 10);
    }
}

function supplementNextPage() {
    var currentPageNum = $('#supplementCurrentPageInput').val();
    var maxPageNum = $('#supplementMaxPageInput').val();
    // alert(currentPageNum);
    // alert(maxPageNum);
    if (currentPageNum === maxPageNum) {
        alert("It is already the last page!");
    } else {

        var newCurrentPageNum = parseInt(currentPageNum) + 1;
        // alert(newCurrentPageNum);
        $("input[name='supplementCurrentPage']").attr("value", newCurrentPageNum);
        getSearchSupplement(newCurrentPageNum, 10);
    }
}

function  pickedAlready(name) {
    var picked = false;
    $("#pickedRecordTable tr:gt(0)").each(function (i) {
        var j = 0;
        $(this).children("td").each(function (i) {
               var tdStr = $(this).text();
               if (name === tdStr
                       && j === 0){
                    picked = true;
               
               }
               j = j + 1;
            
        });
        
    });
    return picked;
}