/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {
    /* $(".irclick").css("background-color", "#d670c1");
     $("input[name='ironOrVc']").attr("value", "iron");
     $(".irclick").mouseenter(function () {
     $(".irclick").css("background-color", "#862572");
     $(".irclick").css("font-weight", "700");
     $(".irclick").css("cursor", "pointer");
     });
     $(".irclick").mouseleave(function () {
     var tt = $(".vcclick").css("background-color");
     if (tt === 'rgb(136, 136, 136)') {
     $(".irclick").css("background-color", "#d670c1");
     $(".irclick").css("font-weight", "400");
     } else {
     $(".irclick").css("background-color", "#888888");
     $(".irclick").css("font-weight", "400");
     }
     })
     
     $(".irclick").click(function () {
     $(".irclick").css("background-color", "	#d670c1");
     $(".irclick").css("font-weight", "400");
     $(".vcclick").css("background-color", "#888888");
     $("input[name='ironOrVc']").attr("value", "iron");
     var divR = document.getElementById("displayResult");
     divR.innerHTML = "";
     });
     
     
     $(".vcclick").mouseenter(function () {
     $(".vcclick").css("background-color", "	#eb530a");
     $(".vcclick").css("font-weight", "700");
     $(".vcclick").css("cursor", "pointer");
     });
     
     $(".vcclick").mouseleave(function () {
     var tt = $(".irclick").css("background-color");
     if (tt === 'rgb(136, 136, 136)') {
     $(".vcclick").css("background-color", "#ff9b2d");
     $(".vcclick").css("font-weight", "400");
     } else {
     $(".vcclick").css("background-color", "#888888");
     $(".vcclick").css("font-weight", "400");
     }
     })
     
     $(".vcclick").click(function () {
     $(".vcclick").css("background-color", "#ff9b2d");
     $(".vcclick").css("font-weight", "400");
     $(".irclick").css("background-color", "#888888");
     $("input[name='ironOrVc']").attr("value", "vitamin_c");
     var divR = document.getElementById("displayResult");
     divR.innerHTML = "";
     });
     */
    $('#m').addClass('active');
    //  $('#infant').addClass('active');
    //  $("#pOrFDiv").css("display", "none");

    $("#m").click(function () {
        $("input[name='gender']").attr("value", "male");
        $(this).closest('.form-inline').find('.gender.active').removeClass('active');
        $(this).addClass("active");
        // $("#pOrFDiv").css("display", "none");
        // $("input[name='addition']").attr("value", "");        
        /*var divR = document.getElementById("displayResult");
         divR.innerHTML = "";*/
        clearCalculationResult();
    })
    $("#f").click(function () {
        $("input[name='gender']").attr("value", "female");
        $(this).closest('.form-inline').find('.gender.active').removeClass('active');
        $(this).addClass("active");
        /*$("#m").css("background-color", "#FFF");
         $("#f").css("background-color", "yellow");*/
        /*  if ($('#lifeStageInput').val() === 'adolescent' || $('#lifeStageInput').val() === 'adult'){
         $("#pOrFDiv").css("display", "block");
         }
         */

        clearCalculationResult();
    })

    /* $("#infant").click(function () {
     $("input[name='lifeStage']").attr("value", "infant");
     $('.form-inline').find('.stage.active').removeClass('active');
     $(this).addClass("active");
     $("#pOrFDiv").css("display", "none");
     $("input[name='addition']").attr("value", "");
     clearCalculationResult();
     getPeriodsPost('infant');
     
     })
     $("#child").click(function () {
     $("input[name='lifeStage']").attr("value", "child");
     $('.form-inline').find('.stage.active').removeClass('active');
     $(this).addClass("active");
     $("#pOrFDiv").css("display", "none");
     $("input[name='addition']").attr("value", "");
     clearCalculationResult();
     getPeriodsPost('child');
     });
     $("#ado").click(function () {
     $("input[name='lifeStage']").attr("value", "adolescent");
     $('.form-inline').find('.stage.active').removeClass('active');
     $(this).addClass("active");
     if ($('#genderInput').val() === 'female'){
     $("#pOrFDiv").css("display", "block");
     }
     $("input[name='addition']").attr("value", "");
     clearCalculationResult();
     getPeriodsPost('adolescent');
     })
     $("#adult").click(function () {
     
     $("input[name='lifeStage']").attr("value", "adult");
     $('.form-inline').find('.stage.active').removeClass('active');
     $(this).addClass("active");
     if ($('#genderInput').val() === 'female'){
     $("#pOrFDiv").css("display", "block");
     }
     $("input[name='addition']").attr("value", "");
     clearCalculationResult();
     getPeriodsPost('adult');
     });
     
     $("#p").click(function () {
     
     $("input[name='addition']").attr("value", "pregnancy");
     $("input[name='lifeStage']").attr("value", "");
     $('.form-inline').find('.stage.active').removeClass('active');
     $(this).addClass("active");
     getPeriodsPost('pregnancy');
     clearCalculationResult();
     })
     $("#bf").click(function () {
     
     $("input[name='addition']").attr("value", "breast-feeding");
     $("input[name='lifeStage']").attr("value", "");
     $('.form-inline').find('.stage.active').removeClass('active');
     $(this).addClass("active");
     clearCalculationResult();
     getPeriodsPost('breast-feeding');
     })*/

    $('#ageSelect').change(function () {

        clearCalculationResult();

    })

    $("input[name='gender']").attr("value", "male");
    //$("input[name='lifeStage']").attr("value", "infant");
    //getPeriodsPost('');
    initilizeAgeSelOptions();
})
function initilizeAgeSelOptions() {
    var age = "";
    var gender = "";
    xmlhttprequest.open("POST", "getSearchConditions.action", false);

    xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

    xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');
    var paras = "period=" + age
            + "&gender=" + gender;
    xmlhttprequest.send(paras);
    var rtnStr = xmlhttprequest.responseText;
    var jsonArr = eval("(" + rtnStr + ")");
    var ages = jsonArr[0].value;
    var sel1 = document.getElementById("ageSelect");
    sel1.innerHTML = "";

    sel1.innerHTML += "<option value=''><--select--></option>";


    var agesArray = ages.split("#");
    for (var i = 0; i < agesArray.length; i++) {
        var ageArr = agesArray[i].split("@");
        sel1.innerHTML += "<option value='" + ageArr[0] + "'>" + ageArr[1] + "</option>";
    }


}
function showCondition() {
    if (isAdult == 1 && isFemale == 1) {
        $('pOrFDiv').removeClass('.hide');
    } else {
        $('pOrFDiv').addClass('.hide');
    }
}

/*function getPeriodsPost(lifeStage) {
 //alert(lifeStage);
 var sel = document.getElementById("ageSelect");
 xmlhttprequest.open("POST", "getPeriods.action", false);
 
 xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
 
 xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');
 
 var paras = "lifeStage=" + lifeStage;
 xmlhttprequest.send(paras);
 var jsonstr = xmlhttprequest.responseText;
 var jsonArr = eval("(" + jsonstr + ")");
 // alert(jsonArr[0].period)
 sel.innerHTML = "";
 for (var i = 0; i < jsonArr.length; i++) {
 sel.innerHTML += "<option value='" + jsonArr[i].value + "'>" + jsonArr[i].name + "</option>";
 }
 }*/

function calculateDI() {

    var age = $("#ageSelect").val();
    // var lifeStage = $('#lifeStageInput').val();
    var gender = $('#genderInput').val();
    // var addition = $('#additionInput').val();

    if (age === null
            || age === ""
            || gender === null
            || gender === "") {
        alert("Make sure you select age and gender!")
    } else {
        xmlhttprequest.open("POST", "calDailyIntake.action", false);

        xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

        xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');

        var paras ="gender=" + gender
                + "&age=" + age;
        xmlhttprequest.send(paras);
        var rtn = xmlhttprequest.responseText;
        var strs = new Array();
        if ("" === rtn) {
            alert("no records!");
        } else {
            strs = rtn.split(",");
        }
        var label1 = document.getElementById("displayAdeIron");
        var label2 = document.getElementById("displayTolIron");
        var label3 = document.getElementById("displayAdeVC");
        var label4 = document.getElementById("displayTolVC");
        label1.innerHTML = strs[1] + "mg";
        label2.innerHTML = strs[0] + "mg";
        label3.innerHTML = strs[3] + "mg";
        label4.innerHTML = strs[2] + "mg";
    }

}

function dailyCalculate() {
    var age = $("#ageSelect").val();
    var gender = $('#genderInput').val();
    window.location.href = 'nutritioncalculator.action';
}

function clearCalculationResult() {
    var label1 = document.getElementById("displayAdeIron");
    var label2 = document.getElementById("displayTolIron");
    var label3 = document.getElementById("displayAdeVC");
    var label4 = document.getElementById("displayTolVC");
    label1.innerHTML = "";
    label2.innerHTML = "";
    label3.innerHTML = "";
    label4.innerHTML = "";
}