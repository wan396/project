/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(function () {

    $('#foodPreviousPage').hide();
    $('#foodNextPage').hide();
    clsDisplayDiv();

    $('#foodTypeSelect').change(function () {
        $('#foodPreviousPage').hide();
        $('#foodNextPage').hide();
        $("input[name='foodCurrentPage']").attr("value", 1);
        $("input[name='foodMaxPage']").attr("value", 1);
        clsDisplayDiv();
        getFoodSubType();


    })

    $('#foodSubTypeSelect').change(function () {
        $('#foodPreviousPage').hide();
        $('#foodNextPage').hide();
        $("input[name='foodCurrentPage']").attr("value", 1);
        $("input[name='foodMaxPage']").attr("value", 1);
        clsDisplayDiv();
    })
});


function getSearchFood(pageNum, pageContentNum) {
    clsDisplayDiv();
    var foodType = $('#foodTypeSelect').val();
    var foodSubType = $('#foodSubTypeSelect').val();

    xmlhttprequest.open("POST", "searchFood.action", false);

    xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

    xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');

    var paras = "foodType=" + foodType
            + "&foodSubType=" + foodSubType
            + "&pageNum=" + pageNum
            + "&pageContentNum=" + pageContentNum;
    xmlhttprequest.send(paras);
    var jsonStr = xmlhttprequest.responseText;
    var jsonArr = eval("(" + jsonStr + ")");
    $('#foodPreviousPage').show();
    $('#foodNextPage').show();
    for (var i = 0; i < jsonArr.length - 1; i++) {
        var divName = "displayFoodDiv" + (i + 1);
        var ironLbl = "displayIron" + (i + 1);
        var vcLbl = "displayVC" + (i + 1);
        var img = "displayFoodImg" + (i + 1);
        var nameLbl = "displayName" + (i + 1);
        $("div[name=" + divName + "]").css("display", "block");
        var imageUrl = jsonArr[i].image.substring(1);
        // var imageUrl = jsonArr[i].image;
        var ironLabel = document.getElementById(ironLbl);
        var vcLabel = document.getElementById(vcLbl);
        var nameLabel = document.getElementById(nameLbl);
        ironLabel.innerHTML = jsonArr[i].iron + "mg";
        vcLabel.innerHTML = jsonArr[i].vitamin_c + "mg";
        nameLabel.innerHTML = jsonArr[i].name;
        $('#' + img).attr("src", imageUrl);
        // ui.innerHTML +="<li class='item1'>" + jsonArr[i].name + "<br/>"+image +"iron:" + jsonArr[i].iron + "mg vitamin C:" + jsonArr[i].vitamin_c + "mg</li>"
    }
    var pageObj = jsonArr[jsonArr.length - 1 ];
    //alert(pageObj.name + "," + pageObj.iron + "," + pageObj.vitamin_c);
    var maxPageNum = pageObj.vitamin_c;
    if (maxPageNum <= 1) {
        $('#foodPreviousPage').hide();
        $('#foodNextPage').hide();
    }
    $("input[name='foodMaxPage']").attr("value", maxPageNum);
    //alert(maxPageNum);
}

function getFoodSubType() {
    var foodType = $('#foodTypeSelect').val();
    if (foodType === null
            || foodType === '') {
        foodType = "";
    }
    xmlhttprequest.open("POST", "getSubTypeList.action", false);

    xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

    xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');

    var paras = "foodType=" + foodType;
    xmlhttprequest.send(paras);
    var jsonstr = xmlhttprequest.responseText;
    var jsonArr = eval("(" + jsonstr + ")");
    var sel = document.getElementById("foodSubTypeSelect");
    // alert(jsonArr[0].period)
    sel.innerHTML = "";
    sel.innerHTML += "<option value=''><--select--></option>";
    for (var i = 0; i < jsonArr.length; i++) {
        sel.innerHTML += "<option value='" + jsonArr[i].value + "'>" + jsonArr[i].name + "</option>";
    }
}


function foodPreviousPage() {
    var currentPageNum = $('#foodCurrentPageInput').val();
    //var maxPageNum = $('#foodMaxPageInput').val();
    /*alert(currentPageNum);
     alert(maxPageNum);*/
    if (currentPageNum === '1') {
        alert("It is already the 1st page!");
    } else {
        var newCurrentPageNum = currentPageNum - 1;
        $("input[name='foodCurrentPage']").attr("value", newCurrentPageNum);
        getSearchFood(newCurrentPageNum, 8);

    }
}

function foodNextPage() {
    var currentPageNum = $('#foodCurrentPageInput').val();
    var maxPageNum = $('#foodMaxPageInput').val();
    // alert(currentPageNum);
    //alert(maxPageNum);
    if (currentPageNum === maxPageNum) {
        alert("It is already the last page!");
    } else {

        var newCurrentPageNum = parseInt(currentPageNum) + 1;
        // alert(newCurrentPageNum);
        $("input[name='foodCurrentPage']").attr("value", newCurrentPageNum);
        getSearchFood(newCurrentPageNum, 8);
    }
}

function clsDisplayDiv() {
    $("div[name='displayFoodDiv1']").css("display", "none");
    $("div[name='displayFoodDiv2']").css("display", "none");
    $("div[name='displayFoodDiv3']").css("display", "none");
    $("div[name='displayFoodDiv4']").css("display", "none");
    $("div[name='displayFoodDiv5']").css("display", "none");
    $("div[name='displayFoodDiv6']").css("display", "none");
    $("div[name='displayFoodDiv7']").css("display", "none");
    $("div[name='displayFoodDiv8']").css("display", "none");
}

function getRecipes(item) {

    var component = $('#' + item).text();
    component = component.trim();
    component = component.replace(' ', '+');
    var url = "nutrition/recipe.jsp?component=" + component;
    window.location.href = url;
}