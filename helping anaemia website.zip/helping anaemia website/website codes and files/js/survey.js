/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {
     $("#dislayResultDiv").css("display", "none");
    $("#qestionbgDiv1").css("display", "none");
    $("#qestionbgDiv2").css("display", "none");
    $("#qestionbgDiv3").css("display", "none");
    $("#qestionbgDiv4").css("display", "none");
    $("#qestionbgDiv5").css("display", "none");
    $("#qestionbgDiv6").css("display", "none");
})


function startSurvey() {

    $("#startPageDiv").css("display", "none")
    $("#qestionbgDiv1").css("display", "block");
    $("#qestionbgDiv2").css("display", "none");
    $("#qestionbgDiv3").css("display", "none");
    $("#qestionbgDiv4").css("display", "none");
    $("#qestionbgDiv5").css("display", "none");
    $("#qestionbgDiv6").css("display", "none");
}

function nextPage(questionIndex) {
   // alert(questionIndex);
    var radioYesId = "radiobutton" + questionIndex + "1";
    var radioNoId = "radiobutton" + questionIndex + "2";
    var yesRadio = document.getElementById(radioYesId).checked;
    var noRadio = document.getElementById(radioNoId).checked;

    if (yesRadio
            || noRadio) {
        if (questionIndex === 6) {
            $("#qestionbgDiv6").css("display", "none");
            $("#dislayResultDiv").css("display", "block");
            var radioYesId1 = "radiobutton11"; 
            var radioYesId2 = "radiobutton21"; 
            var radioYesId3 = "radiobutton31"; 
            var radioYesId4 = "radiobutton41"; 
            var radioYesId5 = "radiobutton51"; 
            var radioYesId6 = "radiobutton61"; 
            var totalPoint = 0;
            if(document.getElementById(radioYesId1).checked){
                $('#exhaustedLabelChoice').html("YES");
                $('#exhaustedLabelPoint').html("2");
                totalPoint = totalPoint + 2;
            }else{
                $('#exhaustedLabelChoice').html("NO");
                $('#exhaustedLabelPoint').html("0");
            }
            
            if(document.getElementById(radioYesId2).checked){
                $('#breathLabelChoice').html("YES");
                $('#breathLabelPoint').html("2");
                totalPoint = totalPoint + 2;
            }else{
                $('#breathLabelChoice').html("NO");
                $('#breathLabelPoint').html("0");
            }
             if(document.getElementById(radioYesId3).checked){
                $('#heartPoundingLabelChoice').html("YES");
                $('#heartPoundingLabelPoint').html("2");
                totalPoint = totalPoint + 2;
            }else{
                $('#heartPoundingLabelChoice').html("NO");
                $('#heartPoundingLabelPoint').html("0");
            }
            if(document.getElementById(radioYesId4).checked){
                $('#legSyndromeLabelChoice').html("YES");
                $('#legSyndromeLabelPoint').html("2");
                totalPoint = totalPoint + 2;
            }else{
                $('#legSyndromeLabelChoice').html("NO");
                $('#legSyndromeLabelPoint').html("0");
            }
            
            if(document.getElementById(radioYesId5).checked){
                $('#headHurtLabelChoice').html("YES");
                $('#headHurtLabelPoint').html("2");
                totalPoint = totalPoint + 2;
            }else{
                $('#headHurtLabelChoice').html("NO");
                $('#headHurtLabelPoint').html("0");
            }
            if(document.getElementById(radioYesId6).checked){
                $('#hairLabelChoice').html("YES");
                $('#hairLabelPoint').html("2");
                totalPoint = totalPoint + 2;
            }else{
                $('#hairLabelChoice').html("NO");
                $('#hairLabelPoint').html("0");
            }
            
            $('#totalLabel').html(totalPoint);
        } else {
            loadNextPage(questionIndex + 1);
        }

    } else {
        alert('Please make a choice!');
    }
}

function loadNextPage(nextPageNum) {
    for (var i = 1; i <= 6; i++) {
        var radiobuttonId = "#qestionbgDiv" + i;
        if (i === nextPageNum) {

            $(radiobuttonId).css("display", "block")
        } else {
            $(radiobuttonId).css("display", "none")
        }
    }
}

function showGPs(){
    var url = "showingGPs.jsp";
    window.location.href = url;
}