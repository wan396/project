/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(function () {
    clsDisplayDiv();
    var urlParas = GetRequest();
    var component = "";
    if (urlParas != null) {
        component = urlParas['component'];
    }
    if (component === undefined
            || component === null) {
        component = "";
    }
//alert(component);
    var foodName = "";
    if (component.indexOf("+") != -1) {
        var arr = component.split("+");
        foodName = arr[0] + " " + arr[1];
    } else {
        foodName = component;
    }
    var rawFoodLabel = document.getElementById("rawfoodName");
    rawFoodLabel.innerHTML = foodName;
   // alert(component);
    getRecipes(component);
})

function GetRequest() {

    var url = location.search; //get the string after symbol '?'

    var theRequest = new Object();
    if (url.indexOf("?") != -1) {

        var str = url.substr(1);
        strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {

            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
        }

    }

    return theRequest;
}

function searchRecipes(){
    clsDisplayDiv();
    var dietLabel = $('#dietSelect').val();
    var healthLabel = $('#healthSelect').val();
    if(dietLabel === undefined
            || dietLabel === null){
        dietLabel = "";
    }
    if(healthLabel === undefined
            || healthLabel === null){
        healthLabel = "";
    }
    var component = $('#rawfoodName').text();
    component = component.replace(' ','+');
    xmlhttprequest.open("POST", "getRecipes.action", false);
    xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');
    var paras = "component=" + component
                + "&diet=" + dietLabel
                + "&health=" + healthLabel;
    xmlhttprequest.send(paras);
    var jsonStr = xmlhttprequest.responseText;
    var jsonArr = eval("(" + jsonStr + ")");
    // alert(jsonArr.length);
    loadRecipes(jsonArr);
}


function getRecipes(component) {
    xmlhttprequest.open("POST", "getRecipes.action", false);
    xmlhttprequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xmlhttprequest.setRequestHeader('User-Agent', 'XMLHTTP');
    var paras = "component=" + component;
    xmlhttprequest.send(paras);
    var jsonStr = xmlhttprequest.responseText;
    var jsonArr = eval("(" + jsonStr + ")");
    // alert(jsonArr.length);
    loadRecipes(jsonArr);

}

function loadRecipes(recipesArr) {
    if (recipesArr != null
            && recipesArr.length > 0) {
        for (var i = 0; i < recipesArr.length; i++) {
           
           var recipeObj = recipesArr[i].recipe;
           var imageUrl = recipeObj.image;
           var title = recipeObj.label;
           var url = recipeObj.url;
           $('#')
           var detaileUrlId = "detailUrl" + (i + 1);
           $('#' + detaileUrlId).attr("href",url);
           var recipeTitleId = "recipHead" + (i + 1);
           $('#' + recipeTitleId).html(title);
           var imageId = "recipImage" + (i + 1);
           $('#' + imageId).attr("src",imageUrl);
           var totalNutritions = recipeObj.totalNutrients;
           var ironIngredient = totalNutritions.FE;
           var vcIngredient = totalNutritions.VITC;
           var sugarIngredient = totalNutritions.SUGAR;
           var energyIngredient = totalNutritions.ENERC_KCAL;
           var fatIngredient = totalNutritions.FAT;
           var fiberIngredient = totalNutritions.FIBTG;
           var proteinIngredient = totalNutritions.PROCNT;
           var calciumIngredient = totalNutritions.CA;
           var ironNo = ironIngredient.quantity.toFixed(2) + ironIngredient.unit;
           var vcNo = "0.0mg";
           if(vcIngredient != undefined){
              vcNo= vcIngredient.quantity.toFixed(2) + vcIngredient.unit;
           }
           
           var ironId = "ironLabel" + (i + 1);
           var vcId = "vcLabel" + (i + 1);
           $('#' + ironId).html(ironNo);
           $('#' + vcId).html(vcNo);
           var sugarNo = sugarIngredient.quantity.toFixed(2) + sugarIngredient.unit;
           var energyNo = energyIngredient.quantity.toFixed(2) + energyIngredient.unit;
           var fatNo = fatIngredient.quantity.toFixed(2) + fatIngredient.unit;
           var fiberNo = fiberIngredient.quantity.toFixed(2) + fiberIngredient.unit;
           var proteinNo = proteinIngredient.quantity.toFixed(2) + proteinIngredient.unit;
           var calciumNo = calciumIngredient.quantity.toFixed(2) + calciumIngredient.unit;
           var nutritionTableId = "nutritionTable" + (i + 1);
           var tableContent = "<tr>"
                            +  "<h4 class='head4'>Other nutrition</h4>"
                            +  "</tr>"
                            +  "<tr>"
                            +  "<td>Energy</td>"
                            +  "<td>" + energyNo+ "</td>"
                            +  "<td>Fat</td>"
                            +  "<td>" + fatNo + "</td>"
                            +  "</tr>"
                            +  "<tr>"
                            +  "<td>Fiber</td>"
                            +  "<td>" + fiberNo + "</td>"
                            +  "<td>Protein</td>"
                            +  "<td>" +proteinNo + "</td>"
                            +  "</tr>"
                            +  "<tr>"
                            +  "<td>Sugars</td>"
                            +  "<td>" + sugarNo + "</td>"
                            +  "<td>Calcium</td>"
                            +  "<td>" + calciumNo + "</td>"
                            +  "</tr>"
           $('#' + nutritionTableId).html(tableContent);
           
           var ingredients = recipeObj.ingredients;
           var ingredientDesc = "";
           if(ingredients != null
                   && ingredients.length > 0){
               for(var j =0; j< ingredients.length; j++){
                   var ingredientObj = ingredients[j];
                   ingredientDesc += "" + ingredientObj.text + "(" + ingredientObj.weight.toFixed(2) + "g)<br>"
               }
           }
           ingredientDesc = ingredientDesc.substring(1);
           var ingredientId = "ingredientDesc" + (i + 1);
           $('#' + ingredientId).html(ingredientDesc);
           var recipeDivId = "recipeDiv" + (i + 1);
           $('#' + recipeDivId).css('display', 'block');
        }
    }
}

function clsDisplayDiv(){
    $("#recipeDiv1").css("display", "none");
    $("#recipeDiv2").css("display", "none");
    $("#recipeDiv3").css("display", "none");
    $("#recipeDiv4").css("display", "none");
    $("#recipeDiv5").css("display", "none");
}