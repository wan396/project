/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookclient;

import java.io.*;
import java.net.*;

/**
 *
 * @author juan
 */
public class Bookclient {

    /**
     * @param args the command line arguments
     */
    protected Socket sock;
    protected BufferedReader reader;
    protected PrintStream writer;
    public static final int PORT = 18889;
    public String request;
    
    public Bookclient() {
	sock = null;
	InputStream in = null;
	OutputStream out = null;

	try{
            InetAddress address = InetAddress.getByName("localhost");
            sock = new Socket(address, PORT); 
            in = sock.getInputStream();
            out = sock.getOutputStream();
            reader = new BufferedReader(new InputStreamReader(in));
            writer = new PrintStream(out);   
            System.out.println("client running");
        }
        catch( Exception e){
            System.out.println("connection fail");
        }    
    }
    public Bookclient(int hotelPort) {
        sock = null;
	InputStream in = null;
	OutputStream out = null;
        try{
            InetAddress address = InetAddress.getByName("localhost");
            sock = new Socket(address, hotelPort); 
            in = sock.getInputStream();
            out = sock.getOutputStream();
            reader = new BufferedReader(new InputStreamReader(in));
            writer = new PrintStream(out);   
            System.out.println("client running");
        }
        catch( Exception e){
            System.out.println("connection fail");
        }  
    }

    public void sendRequest(String request) throws IOException{
        writer.println(request);
    }
    public String getResponse() throws IOException{

            String line = reader.readLine();
            return line;
    }
    
    public void quit() {
	try {
	    reader.close();
	    writer.close();
	    sock.close();
	} catch(Exception e) {
	    // ignore
	}
    }
}
