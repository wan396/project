/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookclient;

import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JDayChooser;
import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.table.*;
import org.json.*;


/**
 *
 * @author juan
 */
public class Ui extends JFrame implements WindowListener
{
    final  CardLayout cards = new CardLayout();
    final  JPanel container = new JPanel();
    private JPanel homePage = new JPanel();
    private JPanel hotelPage = new JPanel();
    private JPanel logPage = new JPanel();
    private JPanel roomPage = new JPanel();
    private JPanel bookPage = new JPanel();
    private JPanel regPage = new JPanel();
    private JPanel accountPage = new JPanel();
    private String response = null;
    private Bookclient client = null;
    //components 
    private JComboBox cityName;
    private JTable hotelList;
    private DefaultTableModel hoteltableModel;
    private JDateChooser checkinDate, checkoutDate;
    private JLabel afterReg;
    private JLabel afterLogin;
    private JButton login, logout, account;
    private JLabel welcome;
    private JButton view;
    private JTable roomList;        
    private DefaultTableModel roomtableModel;
    private JTable bookList;        
    private DefaultTableModel booktableModel;
    
    //list of variables for recording the current client
    private boolean isLogged = false;
    private int loggedUid = 0;
    private int selectedCityId = 0;
    private int selectedHotelId = 0;
    private String inDate;
    private String outDate;
    private String sur;
    private String address;
    private JLabel hotelNameRoom,surburb,addRoom;
    private String selectedCity;
    private JLabel bookHName, bookAdd, bookCity, bookSur, bookIn, bookOut, bookRType, bookRPrice, bookTip;
    private JTextField nameField, cardField;
    private JLabel bookRes;
    
    //list of variables for making request
    private JTextField SearchContent;
    private JTextField rename, repassword;
    private JTextField name, password;
    private JLabel hotelName, city;
    private String roomtype = "";
    private String roomprice;
    private String hname;
    private int bookid = 0;
    private String roomstatus = null;
    //encryption
    private Encryption encry = new Encryption();
    private JSONArray serPort = new JSONArray();
    private int hotelPort = 0;
    
    public static void main(String[] args) {
        Ui ui = new Ui();
        ui.setVisible(true);
        Ui ui2 = new Ui();
        ui2.setVisible(true);
    }
    
    public Ui(){
        // set the frame
        this.setSize(600, 400);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Hotel Booking System");  
        container.setLayout(cards);
        this.add(container);
        container.add(homePage,"home");
        container.add(hotelPage,"hotel");
        container.add(roomPage,"room");
        container.add(bookPage,"book");
        container.add(logPage,"log");
        container.add(regPage,"reg"); 
        container.add(accountPage,"account"); 
        displayHome();
        displayLogin();
        displayHotel();
        displayRoom();
        displayBook();
        displayRegistration();
        displayAccount();
        cards.show(container, "home");
        this.addWindowListener(new WindowAdapter() { 
            public void windowClosing(WindowEvent windowEvent){
                JSONObject quit = new JSONObject();
                try{
                    quit.put("behavior", "quit");
                    String re = quit.toString();
                    sendReq(re);
                }catch(JSONException je){};
                client.quit();
                System.out.println("socket close");
                System.exit(0);
            } 
        });

    }
    
    public JSONArray handleRes(){
        String resp = null;
        JSONArray array = null;
        try{
            resp = client.getResponse();
            array = new JSONArray(resp);
        }catch(IOException ioe){}
        catch(JSONException je){};
        return array;
    }
    public void sendReq(String request){
        try{
            client.sendRequest(request);
        }catch(IOException ioe){}
    }
    public void displayHome(){
        JPanel topHome, centralHome, checkDate, bottom;
        JButton searchHotel;
        JLabel city, checkin, checkout;

        //the top area of the frame, only login button at home page
        topHome = new JPanel();
        topHome.setLayout(new FlowLayout(FlowLayout.RIGHT,60,15));
        login = new JButton("log in");
        login.setPreferredSize(new Dimension(100,25));
        welcome = new JLabel("     ");
        account = new JButton("My account");
        logout = new JButton("log out");
        topHome.add(welcome);
        topHome.add(account);
        topHome.add(login);
        logout.setPreferredSize(new Dimension(100,25));
        topHome.add(logout);
        
        logout.setVisible(false);
        account.setVisible(false);
        //centre area of home page, including cities, checkin date and checkout date
        city =  new JLabel("Target City: ");
        city.setFont(new Font("Times New Roman", Font.BOLD,16));
        cityName =  new JComboBox();
        cityName.setPreferredSize(new Dimension(300,25));
        Box cityBox = Box.createHorizontalBox();
        cityBox.add(city);
        cityBox.add(cityName);
        checkin = new JLabel("Date of checkin: ");
        checkin.setFont(new Font("Times New Roman", Font.BOLD,16));
        checkout = new JLabel("Date of checkout: ");
        checkout.setFont(new Font("Times New Roman", Font.BOLD,16));
        checkinDate =  new JDateChooser();
        checkinDate.setDateFormatString("dd-MM-yyyy");
        Date defulIn = new Date();
        checkinDate.setDate(defulIn);
        checkinDate.setMinSelectableDate(defulIn);
        checkoutDate = new JDateChooser();
        checkoutDate.setDateFormatString("dd-MM-yyyy");
        //Date settedIn = checkinDate.getDate();
        Calendar cal = new GregorianCalendar();
        cal.setTime(defulIn);
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Date defulOut = cal.getTime();
        checkoutDate.setDate(defulOut);
        JTextField jtf = (JTextField)checkinDate.getDateEditor().getUiComponent();
        jtf.setEditable(false);
        JTextField jtf2 = (JTextField)checkoutDate.getDateEditor().getUiComponent();
        jtf2.setEditable(false);
        Box checkinBox = Box.createVerticalBox();
        checkinBox.add(Box.createVerticalStrut(25));
        checkinBox.add(checkin);
        checkinBox.add(Box.createVerticalStrut(20));
        checkinBox.add(checkinDate);
        Box checkoutBox = Box.createVerticalBox();
        checkoutBox.add(Box.createVerticalStrut(25));
        checkoutBox.add(checkout);
        checkoutBox.add(Box.createVerticalStrut(20));
        checkoutBox.add(checkoutDate);
        checkDate = new JPanel();
        checkDate.setLayout(new FlowLayout(FlowLayout.CENTER, 60,5));
        checkDate.add(checkinBox);
        checkDate.add(checkoutBox);        
        centralHome = new JPanel();
        centralHome.setLayout(new FlowLayout(FlowLayout.CENTER));
        centralHome.add(cityBox);
        centralHome.add(checkDate);
        // bottom button
        searchHotel = new JButton("Search");
        searchHotel.setPreferredSize(new Dimension(280,25));
        bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.add(searchHotel);
        Box buttonBox = Box.createVerticalBox();
        buttonBox.add(bottom);
        buttonBox.add(Box.createVerticalStrut(100));
        //home page itself
        homePage.setLayout(new BorderLayout());
        homePage.add(topHome, BorderLayout.NORTH);
        homePage.add(centralHome, BorderLayout.CENTER);
        homePage.add(buttonBox, BorderLayout.SOUTH);
      
      /*display the city name
        connecting to the server and get the response
        dispaly the city name to combobox
        */
        client = new Bookclient(); 
        
        try{
            String server = client.getResponse();
            System.out.println(server);
            JSONObject getcity = new JSONObject();
            getcity.put("behavior", "getcity");
            String re = getcity.toString();
            sendReq(re);       
            JSONArray respCity = handleRes();
            serPort = handleRes();
            System.out.println(serPort);
            for (int i = 0; i < respCity.length(); i++){
            JSONObject obj = respCity.getJSONObject(i);
            String item = obj.getString("cityname");
            cityName.addItem(item);
        }
        }catch(JSONException je){}
        catch(IOException ie){};
        
      //event for click  on log in button
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });
        account.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accountActionPerformed(evt);
            }
        });
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });
      //event for click on check button
        searchHotel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hotelActionPerformed(evt);
            }
        });
      //event for JCalendar inside checkin date
        JCalendar jca = checkinDate.getJCalendar();
        JDayChooser jdc = jca.getDayChooser();
        jdc.addPropertyChangeListener("day", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                //Date select = checkinDate.getDate();
                Date settedIn = checkinDate.getDate();
                Calendar cal = new GregorianCalendar();
                cal.setTime(settedIn);
                cal.add(Calendar.DAY_OF_MONTH, 1);
                Date defulOut = cal.getTime();
                checkoutDate.setDate(defulOut);
                checkoutDate.setMinSelectableDate(defulOut);
            }
        });
    }
    public void displayHotel(){
        JPanel top, submitCity;
        JScrollPane hotelPane; 
        JButton back, search; 
        
        back = new JButton(" < < ");
        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        search = new JButton("Search");
        SearchContent = new JTextField();
        SearchContent.setPreferredSize(new Dimension(280,25));
        top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.X_AXIS));
        top.add(Box.createHorizontalGlue());
        top.add(back);
        top.add(Box.createHorizontalStrut(120));
        top.add(SearchContent);
        top.add(Box.createHorizontalStrut(20));
        top.add(search);
        top.add(Box.createHorizontalGlue());
        
        hotelList = new JTable(); 
        hotelPane = new JScrollPane(hotelList);       
        hotelName = new JLabel();
        hotelName.setFont(new Font("Times New Roman", Font.BOLD,16));        
        view = new JButton("View");
        submitCity = new JPanel();
        submitCity.setLayout(new BoxLayout(submitCity, BoxLayout.X_AXIS));
        submitCity.add(Box.createHorizontalGlue());
        submitCity.add(hotelName);
        submitCity.add(Box.createHorizontalStrut(30));
        submitCity.add(view);
        submitCity.add(Box.createHorizontalStrut(25));
        
        hotelPage.setLayout(new BoxLayout(hotelPage, BoxLayout.Y_AXIS));
        hotelPage.add(Box.createVerticalStrut(5));
        hotelPage.add(top);
        hotelPage.add(Box.createVerticalStrut(20));
        hotelPage.add(hotelPane);
        hotelPage.add(Box.createVerticalStrut(5));
        hotelPage.add(submitCity);
        hotelPage.add(Box.createVerticalStrut(10));
        
        //click on the back button to go back the home page
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hotelName.setText(" ");
                cards.show(container, "home");
                container.validate();
            }
        });
        //click on search button
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchHotelActionPerformed(evt);
            }
        });
        hotelList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hotelMouseClicked(evt);
            }
        });
        view.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewRoomActionPerformed(evt);
            }
        });
    }    
    public void displayRoom(){
        JPanel top, hotelPane, choseRoom;
        JScrollPane roomPane;
        
        JLabel roomType, hotel,addTitle,surTitle, cityTitle;
        JButton book, back;

        hotel = new JLabel("Hotel");
        hotel.setFont(new Font("Times New Roman", Font.BOLD,18));
        hotelNameRoom = new JLabel();
        hotelNameRoom.setFont(new Font("Times New Roman", Font.BOLD,16));
        JPanel hotelTitle = new JPanel();
        hotelTitle.setLayout(new FlowLayout(FlowLayout.LEFT));
        hotelTitle.add(hotel);
        hotelTitle.add(Box.createHorizontalStrut(30));
        hotelTitle.add(hotelNameRoom);
        addTitle = new JLabel("Address: ");
        addTitle.setFont(new Font("Times New Roman", Font.BOLD,14));
        addRoom = new JLabel();
        addRoom.setFont(new Font("Times New Roman", Font.BOLD,14));
        surTitle = new JLabel("Surburb: ");
        surTitle.setFont(new Font("Times New Roman", Font.BOLD,14));
        surburb = new JLabel();
        surburb.setFont(new Font("Times New Roman", Font.BOLD,14));
        cityTitle = new JLabel("City: ");
        cityTitle.setFont(new Font("Times New Roman", Font.BOLD,14));
        city = new JLabel();
        city.setFont(new Font("Times New Roman", Font.BOLD,14));

        JPanel hotelInfor = new JPanel();
        hotelInfor.setLayout(new FlowLayout(FlowLayout.LEFT));
        hotelInfor.add(addTitle);
        hotelInfor.add(addRoom);
        hotelInfor.add(Box.createHorizontalStrut(15));
        hotelInfor.add(surTitle);
        hotelInfor.add(surburb);
        hotelInfor.add(Box.createHorizontalStrut(15));
        hotelInfor.add(cityTitle);
        hotelInfor.add(city);
        hotelPane = new JPanel();
        hotelPane.setLayout(new BoxLayout(hotelPane, BoxLayout.Y_AXIS));
        hotelPane.add(hotelTitle);
        hotelPane.add(hotelInfor);
        back = new JButton(" < < ");
        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.X_AXIS));
        top.add(Box.createHorizontalStrut(10));
        top.add(back);
        top.add(Box.createHorizontalStrut(5));
        top.add(hotelPane);
        roomList = new JTable();
        roomPane = new JScrollPane(roomList);
        
        bookTip = new JLabel();
        bookTip.setFont(new Font("Times New Roman", Font.BOLD,16));
        book = new JButton("Book");
        choseRoom = new JPanel();
        choseRoom.setLayout(new BoxLayout(choseRoom, BoxLayout.X_AXIS));
        choseRoom.add(Box.createHorizontalGlue());
        choseRoom.add(bookTip);
        choseRoom.add(Box.createHorizontalStrut(30));
        choseRoom.add(book);
        choseRoom.add(Box.createHorizontalStrut(25));
        
        roomPage.setLayout(new BoxLayout(roomPage, BoxLayout.Y_AXIS));
        roomPage.add(Box.createVerticalStrut(5));
        roomPage.add(top);
        roomPage.add(Box.createVerticalStrut(5));
        roomPage.add(roomPane);
        roomPage.add(Box.createVerticalStrut(5));
        roomPage.add(choseRoom);
        roomPage.add(Box.createVerticalStrut(10));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            try{    
                bookTip.setText(" ");
                JSONObject quit = new JSONObject();
                quit.put("behavior", "quit");
                String re2 = quit.toString();
                sendReq(re2);
                client.quit();
                client = new Bookclient();
                String server = client.getResponse();
                System.out.println(server);
                cards.show(container, "hotel");
                container.validate();
            }catch(Exception e){}
            }
        });
        roomList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                roomMouseClicked(evt);
            }
        });
        book.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookRoomActionPerformed(evt);
            }
        });
    }
    public void displayBook(){
        JPanel top, roomPane, cusInfor, subBook;
        JLabel hotel, addTitle, address, surTitle, surburb, in, cityTitle, city, out, rtTitle, pTitle;
        JButton submit, back;
        JLabel custTitle, name, card;
        
        
        hotel = new JLabel("Hotel");
        bookHName = new JLabel();
        JPanel hotelTitle = new JPanel();
        hotelTitle.setLayout(new FlowLayout(FlowLayout.LEFT));
        hotelTitle.add(hotel);
        hotelTitle.add(Box.createHorizontalStrut(30));
        hotelTitle.add(bookHName);
        addTitle = new JLabel("Address: ");
        bookAdd = new JLabel();
        surTitle = new JLabel("Surburb: ");
        bookSur = new JLabel();
        cityTitle = new JLabel("City: ");
        bookCity = new JLabel();
        JPanel hotelInfor = new JPanel();
        hotelInfor.setLayout(new FlowLayout(FlowLayout.LEFT));
        hotelInfor.add(addTitle);
        hotelInfor.add(bookAdd);
        hotelInfor.add(Box.createHorizontalStrut(15));
        hotelInfor.add(surTitle);
        hotelInfor.add(bookSur);
        hotelInfor.add(Box.createHorizontalStrut(15));
        hotelInfor.add(cityTitle);
        hotelInfor.add(bookCity);
        
        in = new JLabel("Check in Date: ");
        bookIn = new JLabel();
        out = new JLabel("Check out Date: ");
        bookOut = new JLabel();
        JPanel datePane = new JPanel();
        datePane.setLayout(new FlowLayout(FlowLayout.LEFT));
        datePane.add(in);
        datePane.add(bookIn);
        datePane.add(Box.createHorizontalStrut(15));
        datePane.add(out);
        datePane.add(bookOut);
        
        rtTitle = new JLabel("Room type: ");
        bookRType = new JLabel();
        pTitle = new JLabel("Price: ");
        bookRPrice = new JLabel();
        JPanel pricePane = new JPanel();
        pricePane.setLayout(new FlowLayout(FlowLayout.LEFT));
        pricePane.add(rtTitle);
        pricePane.add(bookRType);
        pricePane.add(Box.createHorizontalStrut(15));
        pricePane.add(pTitle);
        pricePane.add(bookRPrice);
        
        roomPane = new JPanel();
        roomPane.setLayout(new BoxLayout(roomPane, BoxLayout.Y_AXIS));
        roomPane.add(hotelTitle);
        roomPane.add(hotelInfor);
        roomPane.add(datePane);
        roomPane.add(pricePane);
        
        back = new JButton(" < < ");
        back.setBorderPainted(false);
        back.setContentAreaFilled(false);
        top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.X_AXIS));
        top.add(Box.createHorizontalStrut(10));
        top.add(back);
        top.add(Box.createHorizontalStrut(5));
        top.add(roomPane);
               
        custTitle = new JLabel("Customer information");
        custTitle.setFont(new Font("Times New Roman", Font.BOLD,14));
        name = new JLabel("Customer name: ");
        name.setFont(new Font("Times New Roman", Font.BOLD,14));
        nameField = new JTextField();
        nameField.setPreferredSize(new Dimension(100,25));
        JPanel namePane = new JPanel();
        namePane.setLayout(new FlowLayout(FlowLayout.LEFT));
        namePane.add(Box.createRigidArea(new Dimension(80,20)));
        namePane.add(name);
        namePane.add(Box.createHorizontalStrut(10));
        namePane.add(nameField);
        card= new JLabel("Credit card: ");
        card.setFont(new Font("Times New Roman", Font.BOLD,14));
        cardField = new JTextField();
        cardField.setPreferredSize(new Dimension(100,25));
        
        
        JPanel cardPane = new JPanel();
        cardPane.setLayout(new FlowLayout(FlowLayout.LEFT));
        cardPane.add(Box.createRigidArea(new Dimension(80,20)));
        cardPane.add(card);
        cardPane.add(Box.createHorizontalStrut(40));
        cardPane.add(cardField);
        cusInfor = new JPanel();
        cusInfor.setPreferredSize(new Dimension(600,300));
        cusInfor.setLayout(new BoxLayout(cusInfor, BoxLayout.Y_AXIS));
        cusInfor.add(custTitle);
        cusInfor.add(Box.createVerticalStrut(25));
        cusInfor.add(namePane);
        cusInfor.add(cardPane);
        cusInfor.add(Box.createVerticalGlue());

        
        submit = new JButton("Submit");
        subBook = new JPanel();
        bookRes = new JLabel();
        subBook.setLayout(new BoxLayout(subBook, BoxLayout.X_AXIS));
        subBook.add(Box.createHorizontalGlue());
        subBook.add(bookRes);
        subBook.add(Box.createHorizontalStrut(35));
        subBook.add(submit);
        subBook.add(Box.createHorizontalStrut(25));
        
        bookPage.setLayout(new BoxLayout(bookPage, BoxLayout.Y_AXIS));
        bookPage.add(Box.createVerticalStrut(5));
        bookPage.add(top);
        bookPage.add(Box.createVerticalStrut(20));
        bookPage.add(cusInfor);
        bookPage.add(Box.createVerticalStrut(5));
        bookPage.add(Box.createVerticalStrut(5));
        bookPage.add(subBook);
        bookPage.add(Box.createVerticalStrut(10));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameField.setText(" ");
                cardField.setText(" ");
                bookRes.setText(" ");
                cards.show(container, "room");
                container.validate();
                bookTip.setText(" ");
            }
        });
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });
    }
    public void displayLogin(){        
        JLabel custTitle, nameTitle, passTitle;
        JButton registration, login, back;
        
        custTitle = new JLabel("Customer information");
        custTitle.setFont(new Font("Times New Roman", Font.BOLD,14));
        back = new JButton("X");
        back.setContentAreaFilled(false);
        back.setBorderPainted(false);
        JPanel infoPane = new JPanel();
        infoPane.setLayout(new FlowLayout(FlowLayout.LEFT));
        infoPane.add(Box.createHorizontalStrut(35));
        infoPane.add(custTitle);
        infoPane.add(Box.createHorizontalStrut(315));
        infoPane.add(back);
        infoPane.add(Box.createHorizontalStrut(5));
        nameTitle = new JLabel("User name (phone number): ");
        nameTitle.setFont(new Font("Times New Roman", Font.BOLD,14));
        name = new JTextField();
        name.setPreferredSize(new Dimension(130,25));
        JPanel namePane = new JPanel();
        namePane.setLayout(new FlowLayout(FlowLayout.LEFT));
        namePane.add(Box.createRigidArea(new Dimension(80,20)));
        namePane.add(nameTitle);
        namePane.add(Box.createHorizontalStrut(10));
        namePane.add(name);
        passTitle = new JLabel("Password: ");
        passTitle.setFont(new Font("Times New Roman", Font.BOLD,14));
        password = new JTextField();
        password.setPreferredSize(new Dimension(200,25));
        JPanel passPane = new JPanel();
        passPane.setLayout(new FlowLayout(FlowLayout.LEFT));
        passPane.add(Box.createRigidArea(new Dimension(80,20)));
        passPane.add(passTitle);
        passPane.add(Box.createHorizontalStrut(55));
        passPane.add(password);
        afterLogin = new JLabel(" ");
        JPanel logText = new JPanel();
        logText.setLayout(new FlowLayout(FlowLayout.LEFT));
        logText.add(Box.createHorizontalStrut(150));
        logText.add(afterLogin);
        JPanel centre = new JPanel();
        centre.setLayout(new BoxLayout(centre, BoxLayout.Y_AXIS));
        centre.add(Box.createVerticalStrut(25));
        centre.add(namePane);
        centre.add(passPane);
        centre.add(logText);
        registration = new JButton("Registration");
        login = new JButton("Log in");
        JPanel but = new JPanel();
        but.setLayout(new FlowLayout(FlowLayout.LEFT));
        but.add(Box.createHorizontalStrut(120));
        but.add(registration);
        but.add(Box.createHorizontalStrut(120));
        but.add(login);
        
        logPage.setPreferredSize(new Dimension(600,300));
        logPage.setLayout(new BoxLayout(logPage, BoxLayout.Y_AXIS));
        logPage.add(Box.createVerticalStrut(5));
        logPage.add(infoPane);
        logPage.add(Box.createVerticalStrut(15));
        logPage.add(centre);
        logPage.add(but);
        logPage.add(Box.createVerticalStrut(55));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toHomeActionPerformed(evt);
            }
        });
        
        registration.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cards.show(container, "reg");
                container.validate();
            }
        });
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logActionPerformed(evt);
            }
        });
    } 
    public void displayRegistration(){
        
        JLabel custTitle, nameTitle, passTitle;
        
        JButton registration, back;
        
        custTitle = new JLabel("Customer information");
        custTitle.setFont(new Font("Times New Roman", Font.BOLD,14));
        back = new JButton("X");
        back.setContentAreaFilled(false);
        back.setBorderPainted(false);
        JPanel infoPane = new JPanel();
        infoPane.setLayout(new FlowLayout(FlowLayout.LEFT));
        infoPane.add(Box.createHorizontalStrut(35));
        infoPane.add(custTitle);
        infoPane.add(Box.createHorizontalStrut(315));
        infoPane.add(back);
        infoPane.add(Box.createHorizontalStrut(5));
        nameTitle = new JLabel("User name (phone number): ");
        nameTitle.setFont(new Font("Times New Roman", Font.BOLD,14));
        rename = new JTextField();
        rename.setPreferredSize(new Dimension(130,25));
        JPanel namePane = new JPanel();
        namePane.setLayout(new FlowLayout(FlowLayout.LEFT));
        namePane.add(Box.createRigidArea(new Dimension(80,20)));
        namePane.add(nameTitle);
        namePane.add(Box.createHorizontalStrut(10));
        namePane.add(rename);
        passTitle = new JLabel("Password: ");
        passTitle.setFont(new Font("Times New Roman", Font.BOLD,14));
        repassword = new JTextField();
        repassword.setPreferredSize(new Dimension(200,25));
        JPanel passPane = new JPanel();
        passPane.setLayout(new FlowLayout(FlowLayout.LEFT));
        passPane.add(Box.createRigidArea(new Dimension(80,20)));
        passPane.add(passTitle);
        passPane.add(Box.createHorizontalStrut(65));
        passPane.add(repassword);
        JPanel centre = new JPanel();
        centre.setLayout(new BoxLayout(centre, BoxLayout.Y_AXIS));
        centre.add(Box.createVerticalStrut(25));
        centre.add(namePane);
        centre.add(passPane);
        centre.add(Box.createVerticalStrut(15));
        registration = new JButton("Registration");
        afterReg = new JLabel();
        JPanel but = new JPanel();
        but.setLayout(new FlowLayout(FlowLayout.RIGHT));
        but.add(Box.createHorizontalGlue());
        but.add(afterReg);
        but.add(Box.createHorizontalStrut(40));
        but.add(registration);
        but.add(Box.createHorizontalStrut(80));
        
        regPage.setPreferredSize(new Dimension(600,300));
        regPage.setLayout(new BoxLayout(regPage, BoxLayout.Y_AXIS));
        regPage.add(Box.createVerticalStrut(5));
        regPage.add(infoPane);
        regPage.add(Box.createVerticalStrut(15));
        regPage.add(centre);
        regPage.add(but);
        regPage.add(Box.createVerticalStrut(80));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cards.show(container, "log");
                container.validate();
            }
        });
        registration.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regsActionPerformed(evt);
            }
        });
    }
    public void displayAccount(){
        JPanel forButt;
        JScrollPane bookPane;
        JButton cancel,back;
        bookList = new JTable();
        bookPane = new JScrollPane(bookList);
        cancel = new JButton("Cancel");
        back = new JButton("< <");
        forButt = new JPanel();
        forButt.setLayout(new FlowLayout(FlowLayout.RIGHT));
        forButt.add(back);
        forButt.add(Box.createHorizontalStrut(400));
        forButt.add(cancel);
        accountPage.setLayout(new BoxLayout(accountPage, BoxLayout.Y_AXIS));
        accountPage.add(Box.createVerticalStrut(5));
        accountPage.add(bookPane);
        accountPage.add(forButt);
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cards.show(container, "home");
                container.validate();
            }
        });
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelBookActionPerformed(evt);
            }
        });
        bookList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookMouseClicked(evt);
            }
        });
    }
    
    private void loginActionPerformed(java.awt.event.ActionEvent evt) {
        cards.show(container, "log");
        container.validate();
    }
    public void validateUser(String uname, String pass){
        JSONObject obj = new JSONObject();
        try{
            obj.put("behavior","validateUser");
            obj.put("peruname", uname);
            obj.put("perpass", pass);
            String request = obj.toString();
            sendReq(request);
            name.setText(null);
            password.setText(null);
            String resp = client.getResponse();
            JSONObject response = new JSONObject(resp);
            String res = response.getString("result");
            afterLogin.setText(res);
            if (afterLogin.getText().equals("Succesful logged in")){
                int uid = response.getInt("uid");
                cards.show(container, "home");
                container.validate();
                logout.setVisible(true);
                account.setVisible(true);
                login.setVisible(false);
                welcome.setText("Welcome: ");
                isLogged = true;
                loggedUid = uid;
                
            }
            }catch (JSONException je){}
        catch (IOException je){};
    }
    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {
        login.setVisible(true);
        logout.setVisible(false);
        welcome.setText(" ");
        isLogged = false;
        loggedUid = 0;
    }        
   //when click the search button on home page to get the hotel for city
    private void hotelActionPerformed(java.awt.event.ActionEvent evt) {
        selectedCity = cityName.getSelectedItem().toString();
        Date in = checkinDate.getDate();
        Date out = checkoutDate.getDate();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        inDate = format.format(in);
        outDate = format.format(out);
        JSONObject obj = new JSONObject();
        try{
            
            obj.put("behavior","gethotel");
            obj.put("percname", selectedCity);
            String request = obj.toString();
            sendReq(request);
            JSONArray respHotel = handleRes();
            JSONObject cid = respHotel.getJSONObject(0);
            selectedCityId = cid.getInt("cid");
            Vector columnName = new Vector();
            columnName.add("Hotel name");
            columnName.add("Hotel Address");
            columnName.add("Phone number");
            columnName.add("Surburb");
            Vector data = new Vector();
            for (int i = 1; i < respHotel.length(); i++)
            {
                JSONObject hotel = respHotel.getJSONObject(i);
                String name = hotel.getString("hotelname");
                String add = hotel.getString("hadd");
                String phone = hotel.getString("hotelphone");
                String surb = hotel.getString("surburb");
                Vector v = new Vector();
                v.add(name);
                v.add(add);
                v.add(phone);
                v.add(surb);
                data.add(v);
            }
            hoteltableModel = new DefaultTableModel(data, columnName);
            hotelList.setModel(hoteltableModel);
            cards.show(container, "hotel");
            container.validate();
        }catch (JSONException je){}
        
    }
    private void toHomeActionPerformed(java.awt.event.ActionEvent evt){
        cards.show(container, "home");
        container.validate();
    }
    private void searchHotelActionPerformed(java.awt.event.ActionEvent evt){
        String patten = SearchContent.getText();
        JSONObject obj = new JSONObject();
        try{
            
            obj.put("behavior","searchhotel");
            obj.put("percid", selectedCityId);
            obj.put("perpetten", patten);
            String request = obj.toString();
            sendReq(request);
            JSONArray respHotel = handleRes();
            Vector columnName = new Vector();
            columnName.add("Hotel name");
            columnName.add("Hotel Address");
            columnName.add("Phone number");
            columnName.add("Surburb");
            Vector data = new Vector();
            for (int i = 0; i < respHotel.length(); i++)
            {
                JSONObject hotel = respHotel.getJSONObject(i);
                String name = hotel.getString("hotelname");
                String add = hotel.getString("hadd");
                String phone = hotel.getString("hotelphone");
                String surb = hotel.getString("surburb");
                Vector v = new Vector();
                v.add(name);
                v.add(add);
                v.add(phone);
                v.add(surb);
                data.add(v);
            }
            hoteltableModel = new DefaultTableModel(data, columnName);
            hotelList.setModel(hoteltableModel);
        }catch (JSONException je){};
        SearchContent.setText("");
    }
    private void regsActionPerformed(java.awt.event.ActionEvent evt){
        String uname = rename.getText();
        String inpass = repassword.getText();
        String upass = encry.hash(inpass);
        JSONObject obj = new JSONObject();
        try{
            if (uname.isEmpty() && inpass.isEmpty()){
                afterReg.setText("Phone number and password cannot be empty");
            }else{
                if (uname.isEmpty()){
                afterReg.setText("Phone number cannot be empty");
                }else{
                    if (inpass.isEmpty()){
                    afterReg.setText("Password cannot be empty");
                    }else{
                        obj.put("behavior","insertUser");
                        obj.put("peruname", uname);
                        obj.put("perpass", upass);
                        String request = obj.toString();
                        sendReq(request);
                        rename.setText(null);
                        repassword.setText(null);
                        String resp = client.getResponse();
                        afterReg.setText(resp);
                        if (resp.equals("Thank you for your registration")){
                        cards.show(container, "log");
                        container.validate();
            }
                    }
                }
            }  
        }catch (JSONException je){}
        catch (IOException je){};
        
    }
    private void logActionPerformed(java.awt.event.ActionEvent evt){
        String uname = name.getText();
        String inpass = password.getText();
        if (uname.isEmpty() && inpass.isEmpty()){
            afterLogin.setText("Phone number and password cannot be empty");
        }else{
            if (uname.isEmpty()){
                afterLogin.setText("Phone number cannot be empty");
            }else{
                if (inpass.isEmpty()){
                    afterLogin.setText("Password cannot be empty");
                }else{
                        String upass = encry.hash(inpass);
                        validateUser(uname,upass);
                    }
                }
            }
    }
    
    private void hotelMouseClicked(java.awt.event.MouseEvent evt){
        int row = hotelList.getSelectedRow();
        String hotel = (hotelList.getModel().getValueAt(row, 0).toString());
        address = (hotelList.getModel().getValueAt(row, 1).toString());
        sur = (hotelList.getModel().getValueAt(row, 3).toString());
        hotelName.setText(hotel);
    }
    private void viewRoomActionPerformed(java.awt.event.ActionEvent evt){
        hname = hotelName.getText();
        if (hname.isEmpty() || hname.equals("Please choose a hotel")){
            hotelName.setText("Please choose a hotel");
        }else{
            JSONObject obj = new JSONObject();
            try{
            JSONObject quit = new JSONObject();
            quit.put("behavior", "quit");
            String re2 = quit.toString();
            sendReq(re2);
            client.quit();
            for (int i=0; i<serPort.length();i++){
                String hotelname = serPort.getJSONObject(i).getString("hotelname");
                if (hname.equals(hotelname)){
                        hotelPort = serPort.getJSONObject(i).getInt("port");
                }
            }
            System.out.println(hname + hotelPort);
            client = new Bookclient(hotelPort);
            String server = client.getResponse();
            System.out.println(server);
            obj.put("behavior","getroom");
            obj.put("percid", selectedCityId);
            obj.put("perhname", hname);
            obj.put("indate", inDate);
            obj.put("outdate", outDate);
            String request = obj.toString();

            sendReq(request);
            JSONArray respRoom = handleRes();
            JSONObject hid = respRoom.getJSONObject(0);
            selectedHotelId = hid.getInt("hid");;
            Vector columnName = new Vector();
            columnName.add("Room type");
            columnName.add("Price");
            columnName.add("Status");
            Vector data = new Vector();
            for (int i = 1; i < respRoom.length(); i++)
            {
                JSONObject hotel = respRoom.getJSONObject(i);
                String type = hotel.getString("htype");
                double price = hotel.getDouble("price");
                String status = hotel.getString("status");
                Vector v = new Vector();
                v.add(type);
                v.add(price);
                v.add(status);
                data.add(v);
            }
            roomtableModel = new DefaultTableModel(data, columnName);
            roomList.setModel(roomtableModel);
            cards.show(container, "room");
            container.validate();
            hotelNameRoom.setText(hname);
            addRoom.setText(address);
            surburb.setText(sur);
            city.setText(selectedCity);
        }catch (JSONException je){}
        catch(IOException ie){};
            hotelName.setText("");
        }
        
    }
    private void roomMouseClicked(java.awt.event.MouseEvent evt){
        int row = roomList.getSelectedRow();
        roomtype = (roomList.getModel().getValueAt(row, 0).toString());
        roomprice = (roomList.getModel().getValueAt(row, 1).toString());
        roomstatus = (roomList.getModel().getValueAt(row, 2).toString());
        bookTip.setText("roomtype: " + roomtype);
    }

    private void bookRoomActionPerformed(java.awt.event.ActionEvent evt){
        if (isLogged == false){
            bookTip.setText("Please log in first");
        }else{
            if (bookTip.getText().isEmpty()){
                bookTip.setText("Please select a room");
            }else{
                if (roomstatus.equals("full")){
                    bookTip.setText("Sorry, please choose another room");
                }
                else{
                    bookHName.setText(hname);
                    bookAdd.setText(address);
                    bookSur.setText(sur);
                    bookCity.setText(selectedCity);
                    bookIn.setText(inDate);
                    bookOut.setText(outDate);
                    bookRType.setText(roomtype);
                    bookRPrice.setText(roomprice);
                    cards.show(container, "book");
                    container.validate(); 
                }
            }           
        }
    }
       
    private void submitActionPerformed(java.awt.event.ActionEvent evt){
        String cusName = nameField.getText();
        String card = cardField.getText();
        // only support for master card
        final String pattern = "^5[1-5][0-9]{15}";
        
        
        JSONObject obj = new JSONObject();
        if (cusName.isEmpty() || card.isEmpty()){
            bookRes.setText("Please enter the customer information");
        }
        else{
            if(!card.matches(pattern)) {
                bookRes.setText("Invalid credit card number");
        }else{
            try{
                obj.put("behavior","bookroom");
                obj.put("roomtype", roomtype);
                obj.put("cid", selectedCityId);
                obj.put("hid", selectedHotelId);
                obj.put("bookin", inDate);
                obj.put("bookout", outDate);
                obj.put("uid", loggedUid);
                obj.put("cname", cusName);
                String request = obj.toString();
                System.out.println(request);
                sendReq(request);
                String resp = client.getResponse();
                bookRes.setText(resp);
            }catch (JSONException je){}
            catch (IOException je){};
            }
        }
    }

    private void accountActionPerformed(java.awt.event.ActionEvent evt){
        displayBookList();
        cards.show(container, "account");
        container.validate();
        
    }

    private void bookMouseClicked(java.awt.event.MouseEvent evt){
        int row = bookList.getSelectedRow();
        String id = (bookList.getModel().getValueAt(row, 0).toString());
        bookid = Integer.parseInt(id);
    }
    private void displayBookList(){
        JSONObject obj = new JSONObject();
        try{
            obj.put("behavior", "getbook");
            obj.put("uid", loggedUid);
            String request = obj.toString();
            sendReq(request);
            JSONArray book = handleRes();
            Vector columnName = new Vector();
            columnName.add("Booking id");
            columnName.add("City name");
            columnName.add("Hotel name");
            columnName.add("Check-in date");
            columnName.add("Check-out date");
            columnName.add("Booking status");
            columnName.add("Customer name");
            Vector data = new Vector();
            if(book.length()>0){
                for (int i = 0; i < book.length(); i++){
                    JSONObject bookcont = book.getJSONObject(i);
                int bid = bookcont.getInt("bid");
                String cname = bookcont.getString("cname");
                String hname = bookcont.getString("hname");
                String checkin = bookcont.getString("checkin");
                String checkout = bookcont.getString("checkout");
                String status = bookcont.getString("status");
                String custname = bookcont.getString("custname");
                Vector v = new Vector();
                v.add(bid);
                v.add(cname);
                v.add(hname);
                v.add(checkin);
                v.add(checkout);
                v.add(status);
                v.add(custname);
                data.add(v);
                }
                booktableModel = new DefaultTableModel(data, columnName);
                bookList.setModel(booktableModel);
            }
            }catch (JSONException je){}
    }
    private void cancelBookActionPerformed(java.awt.event.ActionEvent evt){        
        JSONObject obj = new JSONObject();
            try{
                obj.put("behavior","cancelbook");
                obj.put("bid", bookid);
                System.out.println(bookid);
                String request = obj.toString();
                sendReq(request);
                
            displayBookList();    
            
            }catch (Exception je){}
    }
    
    @Override
    public void windowOpened(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public void windowClosing(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public void windowClosed(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public void windowIconified(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public void windowDeiconified(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public void windowActivated(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public void windowDeactivated(WindowEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
