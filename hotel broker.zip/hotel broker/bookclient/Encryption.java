/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookclient;
import java.security.MessageDigest;

/**
 *
 * @author juan
 */
public class Encryption {

    Encryption(){
        
    }
    public String hash(String pass){
        String plaintext = pass;
        StringBuffer sb = new StringBuffer();
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(plaintext.getBytes());
            byte byteData[] = md.digest();
            //convert the byte to the hex format
            
            for (int i = 0; i < byteData.length; i++) {
                sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
            }
            
            //System.out.println("Hex format : " + sb.toString());
        }catch (Exception e){};
        String ciper = sb.toString();
        return ciper;
    }
}
