/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookinghotel;

import org.json.JSONObject;

/**
 *
 * @author juan
 */
public class HotelGroup{
    private static ServerConstant constant = new ServerConstant();
    private static String name = null;
    private static int hport = 0;
    public static void main(String argv[]) {
        try{
        System.out.println(constant.SERVER_PORTS);
        for(int i=0; i<constant.SERVER_PORTS.length();i++){
            JSONObject obj = constant.SERVER_PORTS.getJSONObject(i);
            name = obj.getString("hotelname");
            hport = obj.getInt("port");
            System.out.println(obj);
            new Servers(name,hport).start();
        }
        }catch(Exception e){};
    }
    public HotelGroup(){
        
    }
    
}

class Servers extends Thread {
    private String name = null;
    private int port = 0;
    Servers(String name,int port){
        this.name = name;
        this.port = port;
    }
    
    public void run() {
        HotelServer hotSer = new HotelServer(name,port);
    }
}
