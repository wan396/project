/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookinghotel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author juan
 */
public class DefulServer {
private static ServerConstant scon = new ServerConstant();
    public static void main(String argv[]) {
         DefulServer defSer = new DefulServer();
         //defSer.test();
    }
    public DefulServer(){
        ServerSocket s = null;
	try {
	    s = new ServerSocket(scon.PORT);
	} catch(IOException e) {
	    System.out.println(e);
	    System.exit(1);
	}
        System.out.println("This is defualt hotel server");
        while (true) {
	    Socket incoming = null;
	    try {
		incoming = s.accept();
	    } catch(IOException e) {
		System.out.println(e);
		continue;
	    }
        new SocketHandlerDeful(incoming).start();
	}
    }

    class SocketHandlerDeful extends Thread {
        Socket incoming;
        Datalogic db = new Datalogic();

    SocketHandlerDeful(Socket incoming) {
            
        this.incoming = incoming;
    }
    public void run() {
        System.out.println(incoming);
        try {
            // from client to the server
            BufferedReader in = new BufferedReader(new InputStreamReader(incoming.getInputStream()));
            // from this server to client
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(incoming.getOutputStream())),true);
            String server = "Default server connect";
            out.println(server);

            boolean isQuit = false;
            while(isQuit == false){
                String fromClient = in.readLine();
                System.out.println(fromClient);
                JSONObject obj = new JSONObject(fromClient);
                String behavior = obj.getString("behavior");
                String response = null;
                switch (behavior){
                    case "getcity":String serverPort = scon.SERVER_PORTS.toString();
                                   String city = db.getCity();
                                   out.println(city); 
                                   out.println(serverPort);break;
                    case "gethotel": String percity = obj.getString("percname");
                                     response = db.getHotel(percity);
                                     System.out.println(response);
                                     out.println(response);break;
                    case "searchhotel": int perSearchCity = obj.getInt("percid");
                                     String perSearchPattem = obj.getString("perpetten");
                                     response = db.searchHotel(perSearchCity,perSearchPattem);
                                     out.println(response);break;                 
                    case "insertUser": String peruname = obj.getString("peruname");                 
                                       String perpass = obj.getString("perpass");
                                       db.insertUser(peruname, perpass);
                                       out.println("Thank you for your registration");break;
                    case "validateUser":String uname = obj.getString("peruname");
                                        String pass = obj.getString("perpass");
                                        ResultSet result = db.getUser(uname);
                                        Boolean isUE = isUserExist(result);
                                        JSONObject obj2 = new JSONObject();
                                        if (isUE == false){
                                            obj2.put("result", "User not exist, please registration first");
                                            out.println(obj2);
                                        }else{
                                            Boolean isValid = validateUser(pass, result);
                                            if (isValid == false){
                                                obj2.put("result", "Wrong password, please try again");
                                                out.println(obj2);
                                            }else{
                                                int uid = result.getInt(1);
                                                
                                                obj2.put("result", "Succesful logged in");
                                                obj2.put("uid", uid);
                                                String resp = obj2.toString();
                                                out.println(resp);
                                            }
                                        };break;  
                    case "getbook": int uidBook = obj.getInt("uid");    
                                    String bookresult = getBook(uidBook);
                                    out.println(bookresult);break;
                    case "cancelbook": int bidBook = obj.getInt("bid");
                                       db.cancelBook(bidBook);break;                                      
                    case "quit": isQuit = true;break;               
                }
            }
            in.close();
            out.close();
            incoming.close();  
         }catch(Exception e){
            e.printStackTrace();
        }
    }
        
    public boolean isUserExist(ResultSet result){
        
        boolean hasResult = false;
        try{
            if(result.next()){
                hasResult = true;}
        }catch (SQLException sqlExcept){
            sqlExcept.printStackTrace();}
        return hasResult;        
    }
    public boolean validateUser(String pass, ResultSet result){
        boolean isVal = false;
        try{
            String gotPass = result.getString(3);
            if (pass.equals(gotPass)){
                isVal = true;
            }
        }catch(SQLException se){};
        return isVal;
    }
    public String getBook(int uid){
        ResultSet results = db.getBook(uid);
        JSONArray resultset = new JSONArray();
        try{
        while(results.next())
        {
            JSONObject obj = new JSONObject();
            int bid = results.getInt(1);
            int cid = results.getInt(2);
            int hid = results.getInt(3);
            String checkin = results.getString(5);
            String checkout = results.getString(6);
            String status = results.getString(7);
            String custname = results.getString(9);
            ResultSet name = db.getCHName(cid,hid);
            name.absolute(1);
            String cname = name.getString(1);
            String hname = name.getString(2);
            obj.put("bid",bid);
            obj.put("cname",cname);
            obj.put("hname",hname);
            obj.put("checkin",checkin);
            obj.put("checkout",checkout);
            obj.put("status",status);
            obj.put("custname",custname);
            resultset.put(obj);   
        }
        }catch(SQLException sqlExcept){
            sqlExcept.printStackTrace();
        }catch(JSONException je){}
        db.shutdown();
        System.out.println(resultset);
        return resultset.toString();
    }
}
}
