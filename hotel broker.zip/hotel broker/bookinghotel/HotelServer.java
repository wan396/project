/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookinghotel;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author juan
 */
public class HotelServer {
    private static String hotelname = null;
    private int port = 0;
    private static ServerConstant constant = new ServerConstant();
    
    public HotelServer(String hname, int hotelport){
        hotelname = hname;
        port = hotelport;
        ServerSocket s = null;
        System.out.println("This is " + hotelname + " server");
	try {
	    s = new ServerSocket(hotelport);
            System.out.println(s);
	} catch(IOException e) {
	    System.out.println(e);
	    System.exit(1);
	}
        //System.out.println("This is defualt hotel server");
        while (true) {
	    Socket incoming = null;
	    try {
		incoming = s.accept();
	    } catch(IOException e) {
		System.out.println(e);
		continue;
	    }

	    new SocketHandlerHotel(hotelname,incoming).start();
	}
        
    }  
}

 class SocketHandlerHotel extends Thread {
        private Socket incoming;
        String hotelname = null;
        private Datalogic db = new Datalogic();
        private JSONArray avaiableRoom = new  JSONArray();
    SocketHandlerHotel(String hname, Socket incoming) {            
        this.incoming = incoming;
        hotelname = hname;
    }
    public void run() {
        
        try {
            // from client to the server
            BufferedReader in = new BufferedReader(new InputStreamReader(incoming.getInputStream()));
            // from this server to client
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(incoming.getOutputStream())),true);
            String server = hotelname + " connected";
            out.println(server);
            //String result = db.getCity();
            //System.out.println(scon.SERVER_PORTS);
            boolean isQuit = false;
            while(isQuit == false){
                String fromClient = in.readLine();
                System.out.println(fromClient);
                JSONObject obj = new JSONObject(fromClient);
                String behavior = obj.getString("behavior");
                String response = null;
                switch (behavior){
                    case "getroom": int cid = obj.getInt("percid");
                                    String hname = obj.getString("perhname");
                                    String indate = obj.getString("indate");
                                    String outdate = obj.getString("outdate");
                                    String roomdate = getAvaRoom(cid,hname,indate,outdate);
                                    //System.out.println(roomdate);
                                    out.println(roomdate); break;                
                    case "bookroom":String roomtype = obj.getString("roomtype");
                                    int bookcid = obj.getInt("cid");
                                    int bookhid = obj.getInt("hid");
                                    String bookin = obj.getString("bookin");
                                    String bookout = obj.getString("bookout");
                                    int uid = obj.getInt("uid");
                                    String cname = obj.getString("cname");
                                    int bookrid = 0;
                                    System.out.println(avaiableRoom);
                                    for(int i = 0; i < avaiableRoom.length(); i++){
                                        String type = avaiableRoom.getJSONObject(i).getString("htype");
                                        if (type.equals(roomtype))
                                        {
                                            bookrid = avaiableRoom.getJSONObject(i).getInt("rid");
                                            break;
                                        }
                                    }
                                    //System.out.println(obj);
                                    System.out.println(bookcid+" "+bookhid+" "+bookrid+" "+bookin+" "+bookout+" "+uid +" "+cname);
                                    db.insertBook(bookcid, bookhid, bookrid, bookin, bookout, uid, cname);
                                    out.println("Thank you for booking");break; 
                    
                    case "quit": isQuit = true;break;               
            }
            }in.close();
            out.close();
            incoming.close();  
         }catch(Exception e){
            e.printStackTrace();
        }
    }
    public void connectToDe(){
        Socket toDeful = null;
        try{
            InetAddress address = InetAddress.getByName("localhost");
            toDeful = new Socket(address, ServerConstant.PORT);
            }
        catch( Exception e){
            System.out.println("connection fail");
        } 
    }
    public String getAvaRoom(int cid, String hname, String indate, String outdate){
        //int cc = cid;
        //String hh = hname;
        //System.out.println(cc + " "+hname +"\n");
        JSONArray allRoom = db.getRoom(cid, hname);
        //System.out.println(allRoom);
        int hotelid = 0;
        try{
            //db.createConnection();
            hotelid = allRoom.getJSONObject(0).getInt("hid");
            ResultSet avaRoom = db.getAvaiableRoom(cid,hotelid,indate);
            //System.out.println(cid + " "+hotelid +" "+ indate +"\n");
            avaRoom.beforeFirst();
            if(!avaRoom.next()){
                for (int i=1; i<allRoom.length(); i++){
                JSONObject obj = allRoom.getJSONObject(i);
                //System.out.print(obj +"\n");
                obj.accumulate("status", "full");
                //System.out.print(obj+"\n");
                allRoom.put(i, obj);
                }   
            }else{
                avaRoom.beforeFirst();
                while(avaRoom.next()){
                    JSONObject obj = new JSONObject();
                    int rid = avaRoom.getInt(1);
                    String htype = avaRoom.getString(2);
                    String price = avaRoom.getString(3);
                    obj.put("rid",rid);
                    obj.put("htype",htype);
                    obj.put("price",price);
                    avaiableRoom.put(obj);
                    //System.out.println(avaiableRoom);
                }
                //System.out.print(avaiableRoom+"\n");
                ResultSet bookedRoom = db.getBookedRoom(cid,hotelid,indate,outdate);
                if(bookedRoom.next()){
                    bookedRoom.beforeFirst();
                    while(bookedRoom.next()){
                        int bookrid = bookedRoom.getInt(1);
                        //System.out.print("book "+bookrid+"\n");
                        for(int i=0;i<avaiableRoom.length();i++){
                            JSONObject obj2 = avaiableRoom.getJSONObject(i);
                            int avarid = obj2.getInt("rid");
                            //System.out.print("round" +i+"book "+bookrid+"\n");
                            //System.out.print("round" +i+"book "+avarid+"\n");
                            if (avarid == bookrid){
                                avaiableRoom.remove(i);
                            } 
                            //System.out.println(avaiableRoom);
                        }
                    }
                    //System.out.print(avaiableRoom+"\n");
                }
                JSONArray numOfRoom = new JSONArray(); 
                for (int j=1; j<allRoom.length(); j++){
                String type = allRoom.getJSONObject(j).getString("htype");
                    JSONObject obj = new JSONObject();
                    int count = 0;
                    for(int i=0; i<avaiableRoom.length(); i++)
                    {
                        String type2 = avaiableRoom.getJSONObject(i).getString("htype");
                        if (type.equals(type2)) {
                            count++;     
                        }       
                    }
                    obj.put("type", type);
                    obj.put("count", count);
                    numOfRoom.put(obj);
                }
                //System.out.print(numOfRoom+"\n");
                for(int i=1; i<allRoom.length(); i++){
                    JSONObject obj = allRoom.getJSONObject(i);
                    String type2 = obj.getString("htype");
                    int n = 0;
                    for(int j=0; j<numOfRoom.length(); j++){
                        String type = numOfRoom.getJSONObject(j).getString("type");
                        if(type.equals(type2)){
                            n = numOfRoom.getJSONObject(j).getInt("count");
                        }
                    }
                    if(n>0){
                        obj.accumulate("status", "available");
                        allRoom.put(i, obj);
                    }else{
                        obj.accumulate("status", "full");
                        allRoom.put(i, obj);
                    }
                }
            }
            //System.out.print(avaiableRoom+"\n");
            //System.out.print(allRoom);
        }catch (SQLException sqlExcept){
            sqlExcept.printStackTrace();}
        catch(JSONException je){}
        db.shutdown();
        //System.out.print(allRoom+"\n");
        String rooms = allRoom.toString();
        return rooms;
    }
    
 }
