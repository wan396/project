/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookinghotel;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author juan
 */
public class ServerConstant {
    public static final int PORT = 18889;
    public JSONArray SERVER_PORTS = new JSONArray();
    public ServerConstant(){
        try{
            JSONObject obj = new JSONObject();
            obj.put("hotelname", "Crowne Plaza");
            obj.put("port", 18899);
            SERVER_PORTS.put(obj);
            JSONObject obj1 = new JSONObject();
            obj1.put("hotelname", "ibis budget");
            obj1.put("port", 18900);
            SERVER_PORTS.put(obj1);
            JSONObject obj2 = new JSONObject();
            obj2.put("hotelname", "Hilton");
            obj2.put("port", 18980);
            SERVER_PORTS.put(obj2);
            JSONObject obj3 = new JSONObject();
            obj3.put("hotelname", "Travelodge");
            obj3.put("port", 18990);
            SERVER_PORTS.put(obj3);
        }catch(Exception e){
            
        }
    }
}
