/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookinghotel;

import java.sql.*;
import java.util.*;
import net.sf.ezmorph.bean.MorphDynaBean;
import org.json.*;


/**
 *
 * @author juan
 */
public class Datalogic {
    private static String dbURL = "jdbc:derby://localhost:1527/booking;create=true;user=a;password=a";
    private static Statement stmt = null;
    private static PreparedStatement pst = null;
    private static Connection conn = null;
    
    public Datalogic(){
        
    }
    
    public static void createConnection()
    {
        try
        {
            Class.forName("org.apache.derby.jdbc.ClientDriver").newInstance();
            //Get a connection
            conn = DriverManager.getConnection(dbURL); 
            System.out.println("Connected to Derby");
        }
        catch (Exception except)
        {
            except.printStackTrace();
        }
    }
    
     public static void shutdown()
    {
        try
        {
            if (stmt != null)
            {
                stmt.close();
            }
            if (conn != null)
            {
                conn.close();
                System.out.println("Disconnected");
            }           
        }
        catch (SQLException sqlExcept)
        {
            System.out.println(sqlExcept); 
        }
    }
    
    public String getCity() {
    ResultSet results = null;
    JSONArray resultset = new JSONArray();
    try{
        createConnection();
        stmt = conn.createStatement();
        results = stmt.executeQuery("select cname from city");
    while(results.next())
            {
                String cname = results.getString(1);
                JSONObject obj = new JSONObject();
                obj.put("cityname",cname);
                resultset.put(obj);
            }
            results.close();
            stmt.close();
    }catch (SQLException sqlExcept)
        {
            sqlExcept.printStackTrace();
        }
    catch(JSONException je){}
    shutdown();;
    String city = resultset.toString();
    return city;
    }
    
    public String getHotel(String cityName){
        ResultSet results = null;
        JSONArray resultset = new JSONArray();
    try{
        createConnection();
        String query = "select c.cid,h.hname,h.hadd,h.hphone,h.surburb from hotel h, city c where h.cid=c.cid and cname=?";
        pst = conn.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
        pst.setString(1, cityName);
        results = pst.executeQuery();
        
        results.next();
        int cid = results.getInt(1);
        JSONObject obj = new JSONObject();
        obj.put("cid", cid);
        resultset.put(obj);;
        results.beforeFirst();
        while(results.next()){ 
            JSONObject obj2 = new JSONObject();
            String hname = results.getString(2);
            String hadd = results.getString(3);
            String hphone = results.getString(4);
            String surburb = results.getString(5);
            obj2.put("hotelname",hname);
            obj2.put("hadd",hadd);
            obj2.put("hotelphone",hphone);
            obj2.put("surburb",surburb);
            resultset.put(obj2);            
            }
        }
    catch (SQLException sqlExcept){
        sqlExcept.printStackTrace();}
    catch (JSONException je){};
        System.out.println(resultset);
    shutdown();
    String hotel = resultset.toString();
    return hotel;
    }
    
    public String searchHotel(int cid, String partname){
        ResultSet results = null;
        JSONArray resultset = new JSONArray();
    try{
        createConnection();
        String query = "select hname,hadd,hphone,surburb from hotel where cid=? and upper(hname) like upper(?)";
        pst = conn.prepareStatement(query);
        pst.setInt(1, cid);
        pst.setString(2, "%"+partname+"%");
        results = pst.executeQuery();
        while(results.next())
        {
            JSONObject obj = new JSONObject();
            String hname = results.getString(1);
            String hadd = results.getString(2);
            String hphone = results.getString(3);
            String surburb = results.getString(4);
            obj.put("hotelname",hname);
            obj.put("hadd",hadd);
            obj.put("hotelphone",hphone);
            obj.put("surburb",surburb);
            resultset.put(obj);   
        }
        }catch (SQLException sqlExcept){
            sqlExcept.printStackTrace();}
        catch (JSONException je){};
    shutdown();
    String hotel = resultset.toString();
    return hotel;
    }
    
    public JSONArray getRoom(int cid, String hname){
        ResultSet results = null;
        JSONArray resultset = new JSONArray();
        try{
            createConnection();
            String query = "select r.hid,r.rid,r.rtype,r.rrate from room r, hotel h where h.CID=r.CID and h.HID=r.HID and r.CID=? and h.HNAME=?";
            pst = conn.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            pst.setInt(1, cid);
            pst.setString(2, hname);
            results = pst.executeQuery();
            results.next();
            int hid = results.getInt(1);
            JSONObject obj = new JSONObject();
            obj.put("hid", hid);
            resultset.put(obj);
            
            results.beforeFirst();
            while(results.next()){ 
                JSONObject obj2 = new JSONObject();
                int rid = results.getInt(2);
                String htype = results.getString(3);
                String price = results.getString(4);
                obj2.put("rid",rid);
                obj2.put("htype",htype);
                obj2.put("price",price);
                if (resultset.length() == 1){
                    resultset.put(obj2);
                }else{
                    for(int i=1; i < resultset.length(); i++)
                    {
                        JSONObject test = resultset.getJSONObject(i);
                        String compare = test.getString("htype");
                        if (!compare.equals(htype)){
                            resultset.put(obj2);
                        }
                    }
                }
            }
        }catch (SQLException sqlExcept){
            sqlExcept.printStackTrace();}
        catch (JSONException je){};
        return resultset;
    }
    public ResultSet getAvaiableRoom(int cid, int hid, String date){
        ResultSet results = null;
    try{
        createConnection();
        String query = "select rid,rtype,rrate from room where cid=? and hid=? and (checkin is null or CHECKOUT <?)";
        pst = conn.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
        pst.setInt(1, cid);
        pst.setInt(2, hid);
        pst.setString(3, date);
        results = pst.executeQuery();
        }catch (SQLException sqlExcept){
            sqlExcept.printStackTrace();};
    return results;
    }
    public ResultSet getBookedRoom(int cid, int hid, String indate, String outdate){
        ResultSet results = null;
        try{
        createConnection();
        String query = "select rid from booking where status='booking' and cid=? and hid=? and (? between bcheckin and bcheckout) or (? between bcheckin and bcheckout) or (bcheckin > ? and bcheckout< ?)";
        pst = conn.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
        pst.setInt(1, cid);
        pst.setInt(2, hid);
        pst.setString(3, indate);
        pst.setString(4, outdate);
        pst.setString(5, indate);
        pst.setString(6, outdate);
        results = pst.executeQuery();
        }catch (SQLException sqlExcept){
            sqlExcept.printStackTrace();};
        return results;
    }
    
    public void insertBook(int cid, int hid, int rid, String bookin, String bookout, int uid, String cname){
        try{
        createConnection();
        String query = "insert into booking values(next value for BID_SEQ, ?,?,?,?,?,'booking',?,?)";
        pst = conn.prepareStatement(query);
        pst.setInt(1, cid);
        pst.setInt(2, hid);
        pst.setInt(3, rid);
        pst.setString(4, bookin);
        pst.setString(5, bookout);
        pst.setInt(6, uid);
        pst.setString(7, cname);
        pst.execute();
        }catch(SQLException sqlExcept){
            sqlExcept.printStackTrace();
        }
        shutdown();
    }
    
    public void cancelBook(int bid){
        try{
        createConnection();
        String query = "update booking set status='canceled' where bid = ?";
        pst = conn.prepareStatement(query);
        pst.setInt(1, bid);
        pst.execute();
        }catch(SQLException sqlExcept){
            sqlExcept.printStackTrace();
        }
        shutdown();
    }
    public ResultSet getBook(int uid){
        ResultSet results = null;
        try{
        createConnection();
        String query = "select * from booking where uid=?";
        pst = conn.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
        pst.setInt(1, uid);
        results = pst.executeQuery();
        }catch(SQLException sqlExcept){
            sqlExcept.printStackTrace();
        }
        return results;
    }
    
    public ResultSet getCHName(int cid,int hid){
        ResultSet results = null;
        try{
        createConnection();
        String query = "select c.CNAME,h.HNAME from city c,hotel h where c.CID=h.CID and h.CID=? and h.HID=?";
        pst = conn.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
        pst.setInt(1, cid);
        pst.setInt(2, hid);
        results = pst.executeQuery();
        }catch(SQLException sqlExcept){
            sqlExcept.printStackTrace();
        }
        return results;
    }

    
    public void insertUser(String phone, String pass){
        try{
        createConnection();
        String query = "insert into users values(next value for UID_SEQ, ?,?)";
        pst = conn.prepareStatement(query);
        pst.setString(1, phone);
        pst.setString(2, pass);
        pst.execute();
        }catch(SQLException sqlExcept){
            sqlExcept.printStackTrace();
        }
        shutdown();
    }
    
    public ResultSet getUser(String uname){
        ResultSet results = null;
        createConnection();
        try{
            String query = "select uid,uname,pass from users where uname = ?";
            pst = conn.prepareStatement(query);
            pst.setString(1, uname);
            results = pst.executeQuery();
        }catch (SQLException sqlExcept){
            sqlExcept.printStackTrace();};
    return results;
    }

}
